﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIC_Timer_Programming_and_Calibration.ThemeManager
{
    public class clsColorScheme
    {
        public enum ColorScheme
        {
            Primary,
            Secondary,
            PrimaryForeground,
            SecondaryForeground
        }
    }
}
