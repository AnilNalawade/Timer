﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace GIC_Timer_Programming_and_Calibration.helperClasses
{
    public class RelayCommand : ICommand
    {

        private Action<object> execute;
        private Func<object, bool> canExecute;
        private RelayCommand btnOkCalibrationCmd;

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
        /// <summary>
        /// Initializes a new instance of the RelayCommand class
        /// Creates a new command that can always execute.
        /// </summary>
        /// <param name="execute">The execution logic.</param>
        public RelayCommand(Action<object> execute)
            : this(execute, DefaultCanExecute)
        {
        }
        private static bool DefaultCanExecute(object parameter)
        {
            if(clsGlobalVariables.MainWindowVM != null)
            {
                if(clsGlobalVariables.MainWindowVM.IsProcessOn == true){
                    return false;
                }
                else
                {
                    return true;
                }
            }
           
            return true;
        }
        public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        public RelayCommand(RelayCommand btnOkCalibrationCmd)
        {
            this.btnOkCalibrationCmd = btnOkCalibrationCmd;
        }

        public bool CanExecute(object parameter)
        {
            return this.canExecute == null || this.canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            this.execute(parameter);
        }
    }
}
