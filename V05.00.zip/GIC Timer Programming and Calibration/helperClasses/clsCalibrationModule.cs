﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using GIC_Timer_Programming_and_Calibration.model;

namespace GIC_Timer_Programming_and_Calibration.helperClasses
{
    public class clsCalibrationModule
    {
        /// <summary>
        /// Read device info for the calibration 
        /// Create query for device info
        /// Calculate CRC and check if valid or invalid
        /// if valid return valid buffer else return null
        /// </summary>
        /// <returns></returns>
        public byte[] ReadDeviceInfo()
        {
            try
            {
                // byte deviceId = Convert.ToByte(catList.DeviceId); // This byte is for deviceId.
                byte deviceId = 0xF7; //This byte is for deviceId. 
               
                //int DataLength = 0;
                int Status = clsGlobalVariables.FAILURE; //Default status : ErrorCode => SUCCESS = 0 | FAILURE = -1
                                                     // Array created to store parameters required by Device               
                // Make Query to send and store in txBuff
                byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.PotRead, (byte)clsEnumReadWriteCode.Readbyte, null);
                                
                // Send the query to DUT and get response and store in rxBuff
                byte[] rxBuff = clsGlobalVariables.ObjSerialComPort.SendQueryGetResponse(ref Status, txBuff, clsGlobalVariables.SelectedComPort, clsGlobalVariables.SelectedBaudRate);
                               
                // Check if Error code is Success and rxBuffer is not null
                #region DeviceInfo
                if (Status == clsGlobalVariables.SUCCESS && rxBuff != null)
                {                   
                    //Temp buffer to calculate checksum of rxBuff 
                    byte[] rxBuffToValidate = new byte[rxBuff.Length - 1];

                    for (int counter = 0; counter < rxBuff.Length - 1; counter++)
                    {
                        rxBuffToValidate[counter] = rxBuff[counter];
                    }
                    // Calculate checksum of rxBuff
                    byte RxChecksum = clsGlobalVariables.ObjSerialComPort.CalculateChecksum(rxBuffToValidate);

                    // Check Data received exactly match with valid response
                    // Check Device Id, Function Code, ReadWrite code, Checksum
                    if (rxBuff[0] == deviceId && rxBuff[1] == (byte)clsEnumFunctionCode.PotRead && rxBuff[2] == (byte)clsEnumReadWriteCode.Readbyte && rxBuff[rxBuff.Length - 1] == RxChecksum)
                        return rxBuff;
                    else
                    {
                        MyLogWriterDLL.LogWriter.WriteLog("Checksum mismatch : ");
                        return null;
                    }                      
                }
                else
                {
                    //Display error message
                   // MessageBox.Show("No response from Device", "Communication Failed", MessageBoxButton.OK, MessageBoxImage.Error);                    
                    return rxBuff;
                }
                #endregion
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("Checksum mismatch : " + ex.StackTrace);
                return null;
            }
        }
      
        /// <summary>
        /// Function here filled deviceinfo to the buffer
        /// Filled buffer send to the makeframe function
        /// </summary>
        /// <param name="dataParams"></param>
        /// <param name="catList"></param>
        private void DeviceInfo(ref byte[] dataParams)
        {
            int len = 0; // index counter for array           

            //dataParams[len++] = Convert.ToByte(catList.DeviceId);
            // dataParams[len++] = Convert.ToByte(catList.);

            dataParams[len++] = 0x02; // Product Id
            dataParams[len++] = 0x03; // No of pots Code
            dataParams[len++] = 0x01; // Timing 1 Channel No
            dataParams[len++] = 0x02; // Range 1 Channel No
            dataParams[len++] = 0xFF; // Timing 2 Channel No
            dataParams[len++] = 0xFF; // Range 2 Channel No
            dataParams[len++] = 0xFF; // Mode channel No
        }
        /// <summary>
        /// Validate response here Get Response 
        /// check If it is null or filled
        /// Calculate CRC
        /// Validate CRC ,if Ok return ok buffer ,else return null
        /// option parameter pass during ZCD Calibration to keep port on only when relay calibration is in progress,
        /// because  in that function software has to to wait for 2nd response.
        /// </summary>
        /// <param name="txBuff"></param>
        /// <returns></returns>
        public byte[] ValidateResponse(byte[] txBuff,byte Functioncode,byte ReadWriteCode, bool skipcloseport = false)
        {
            byte deviceId = txBuff[0];
            
            int Status = clsGlobalVariables.FAILURE; //Default status : ErrorCode => SUCCESS = 0 | FAILURE = -1
            byte[] rxBuff = null;
            for (int retry = 0; retry < clsGlobalVariables.RetryCount; retry++)
            {
                //Send req. get response
                rxBuff = clsGlobalVariables.ObjSerialComPort.SendQueryGetResponse(ref Status, txBuff, clsGlobalVariables.SelectedComPort, clsGlobalVariables.SelectedBaudRate , skipcloseport);
                if (rxBuff != null && Status == clsGlobalVariables.SUCCESS)
                {
                    byte[] rxBuffToValidate = new byte[rxBuff.Length - 1];

                    for (int counter = 0; counter < rxBuff.Length - 1; counter++)
                    {
                        rxBuffToValidate[counter] = rxBuff[counter];
                    }
                    // Calculate checksum of rxBuff and validation
                    byte RxChecksum = clsGlobalVariables.ObjSerialComPort.CalculateChecksum(rxBuffToValidate);
                    if (rxBuff[0] == deviceId && rxBuff[1] == Functioncode && rxBuff[2] == ReadWriteCode && rxBuff[rxBuff.Length - 1] == RxChecksum)
                    {
                        return rxBuff;
                    }
                    else
                    {
                        if (retry == clsGlobalVariables.RetryCount - 1)
                        {
                            MessageBox.Show("Invalid response or checksum to Functioncode : " + Functioncode + " from Device", "Communication failed", MessageBoxButton.OK, MessageBoxImage.Error);
                            return null;
                        }                        
                    }
                }
                else
                {
                    //Display error message
                    if (retry == clsGlobalVariables.RetryCount - 1)
                    {
                        MessageBox.Show("No response to Functioncode : " + Functioncode + " from Device", "Communication Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        return rxBuff;
                    }                  
                }
            }
            return rxBuff;
            
        }
        /// <summary>
        /// Write data on flash and in hex file also
        /// </summary>
        /// <param name="catID"></param>
        /// <returns></returns>
        public byte WriteAdditionalandRuntimeFeatures(CatIDList catID,string selectedbaudrate)
        {
            int DataLength = 0;
            if (catID.ControllerType == "G10")
                DataLength = 69;
            else if (catID.ControllerType == "G13" ||
                    catID.ControllerType == "G12")
                DataLength = 68;
            byte deviceId = 0xF7;
            byte[] txBuff = null;
            clsGlobalVariables.SelectedBaudRate = selectedbaudrate;
            // Array created to store parameters required by Device                                 
            byte[] dataParams = null;
            //Function to provide data parameters to make deviceinfo query
            if (DataLength != 0)
            {
                dataParams = new byte[DataLength];
                
                FillAdditionalfeatures(ref dataParams, catID);

                txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.Additionalfeatures, (byte)clsEnumReadWriteCode.Writebyte, dataParams);
                byte[] rxBuff = null;
                if (catID.ControllerType == "G13" ||
                    catID.ControllerType == "G12")
                {
                    //temporary message added
                    //MessageBox.Show("Start Calibration, please turn on Calibration mode.");

                    rxBuff = ValidateResponse(txBuff, (byte)clsEnumFunctionCode.Additionalfeatures, (byte)clsEnumReadWriteCode.Writebyte);
                    //Do action on data received from device
                                        
                    if (rxBuff == null)
                    {
                        MessageBox.Show("Communication failed while write additional features");
                        return (byte)EnmModuleName.Stop;
                    }

                    //Additional Constants
                    //Changes added Forward reverse timer
                    //Additional features for timing2 and range2 added
                    //Checked timing1 and timing2 constants difference, also range1 and range2 constants difference, define flag.
                    //Added positions of all available timing and range pots.
                    //Added counts for both timing2 and range2 pots.
                    #region Additional Constants added
                    int foundTwoTimingPots = 0;
                    int foundTwoRangePots = 0;
                    byte[] AdditionalConstant = new byte[54];

                    string[] consts = null;
                    for (int potnum = 0; potnum < catID.Micon175_PotDetail.Count; potnum++)
                    {
                        if (catID.Micon175_PotDetail[potnum].PotName == "Timing1" || catID.Micon175_PotDetail[potnum].PotName == "Timing2")
                        {
                            foundTwoTimingPots++;

                            if (foundTwoTimingPots == 1)
                                consts = new string[catID.Micon175_PotDetail[potnum].NoOfPosition];

                            if (foundTwoTimingPots == 2)
                            {
                                byte difference = 00;
                                if (consts.Length == catID.Micon175_PotDetail[potnum].NoOfPosition)
                                {
                                    string[] const2 = catID.Micon175_PotDetail[potnum].RangeConstants.Split(',');
                                    for (int cnt = 0; cnt < consts.Length; cnt++)
                                    {
                                        if (consts[cnt] != const2[cnt])
                                        {
                                            difference = 01;
                                            break;
                                        }
                                    }
                                }
                                else
                                    difference = 01;

                                AdditionalConstant[0] = difference;
                                AdditionalConstant[2] = Convert.ToByte(catID.Micon175_PotDetail[potnum].NoOfPosition);
                            }
                            else if (potnum == catID.Micon175_PotDetail.Count - 1)
                            {
                                AdditionalConstant[0] = 0;
                                AdditionalConstant[2] = 0;
                            }
                            else
                            {
                                consts = catID.Micon175_PotDetail[potnum].RangeConstants.Split(',');
                                AdditionalConstant[0] = 0;
                                AdditionalConstant[2] = 0;
                            }

                        }
                        if (catID.Micon175_PotDetail[potnum].PotName == "Range1" || catID.Micon175_PotDetail[potnum].PotName == "Range2")
                        {
                            foundTwoRangePots++;

                            if (foundTwoRangePots == 1)
                                consts = new string[catID.Micon175_PotDetail[potnum].NoOfPosition];

                            if (foundTwoRangePots == 2)
                            {
                                byte difference = 00;
                                if (consts.Length == catID.Micon175_PotDetail[potnum].NoOfPosition)
                                {
                                    string[] const2 = catID.Micon175_PotDetail[potnum].RangeConstants.Split(',');
                                    for (int cnt = 0; cnt < consts.Length; cnt++)
                                    {
                                        if (consts[cnt] != const2[cnt])
                                        {
                                            difference = 01;
                                            break;
                                        }
                                    }
                                }
                                else
                                    difference = 01;

                                AdditionalConstant[1] = difference;
                                AdditionalConstant[3] = Convert.ToByte(catID.Micon175_PotDetail[potnum].NoOfPosition);
                            }
                            else if (potnum == catID.Micon175_PotDetail.Count - 1)
                            {
                                AdditionalConstant[1] = 0;
                                AdditionalConstant[3] = 0;
                            }
                            else
                            {
                                consts = catID.Micon175_PotDetail[potnum].RangeConstants.Split(',');
                                AdditionalConstant[1] = 0;
                                AdditionalConstant[3] = 0;
                            }
                        }
                    }
                    //Conditions for 2 timings pots and 2 range pots.
                    if (foundTwoTimingPots == 2 || foundTwoRangePots == 2)
                    {

                        FillAdditionalConstants(ref AdditionalConstant, catID);

                        txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.AdditionalConstants, (byte)clsEnumReadWriteCode.Writebyte, AdditionalConstant);

                        //Log
                        StringBuilder sbtmp = new StringBuilder();
                        sbtmp.Append("Transfer Buffer Data : ");
                        for (int cnt = 0; cnt < txBuff.Length; cnt++)
                        {
                            sbtmp.Append(txBuff[cnt] + ",");
                        }
                        MyLogWriterDLL.LogWriter.WriteLog(sbtmp.ToString());

                        rxBuff = ValidateResponse(txBuff, (byte)clsEnumFunctionCode.AdditionalConstants, (byte)clsEnumReadWriteCode.Writebyte);
                       
                        sbtmp.Clear();
                        sbtmp.Append("Received Buffer Data : ");
                        if (rxBuff != null)
                        {
                            for (int cnt = 0; cnt < rxBuff.Length; cnt++)
                            {
                                sbtmp.Append(rxBuff[cnt] + ",");
                            }
                            MyLogWriterDLL.LogWriter.WriteLog(sbtmp.ToString());
                        }
                        else
                            MyLogWriterDLL.LogWriter.WriteLog("NULL");

                        if (rxBuff == null)
                        {
                            MessageBox.Show("Communication failed while write additional Constants");
                            return (byte)EnmModuleName.Stop;
                        }
                    } 
                    #endregion

                    if (rxBuff == null)
                    {
                        MessageBox.Show("Communication failed while write additional features");
                        return (byte)EnmModuleName.Stop;
                    }                       
                }

                if (catID.ControllerType == "G13" ||
                    catID.ControllerType == "G12")
                {
                    DataLength = 6;
                    dataParams = new byte[DataLength];
                    FillRuntimefeatures(ref dataParams, catID);
                    rxBuff = null;
                    txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.RunTimeChanges, (byte)clsEnumReadWriteCode.Writebyte, dataParams);

                    rxBuff = ValidateResponse(txBuff, (byte)clsEnumFunctionCode.RunTimeChanges, (byte)clsEnumReadWriteCode.Writebyte);

                    //Logger added for debugging
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.Append("txBuff : ");
                    for (int i = 0; i < txBuff.Length; i++)
                    {
                        stringBuilder.Append(txBuff[i].ToString() + ",");
                    }
                    stringBuilder.AppendLine();

                    stringBuilder.Append("rxBuff : ");
                    for (int i = 0; i < rxBuff.Length; i++)
                    {
                        stringBuilder.Append(rxBuff[i].ToString() + " ");
                    }
                    stringBuilder.AppendLine();

                    MyLogWriterDLL.LogWriter.WriteLog("Runtime Changes Data : ");
                    MyLogWriterDLL.LogWriter.WriteLog(stringBuilder.ToString());
                    //logger end

                    //Do action on data received from device
                    if (rxBuff == null)
                    {
                        MessageBox.Show("Communication failed while write Runtime changes features");
                        return (byte)EnmModuleName.Stop;
                    }
                }
            }
            
            if (catID.ControllerType == "G10")
                return (byte)EnmModuleName.Programming;
            else if (catID.ControllerType == "G13" ||
                    catID.ControllerType == "G12")
                return (byte)EnmModuleName.PotCalibration;

            return (byte)EnmModuleName.Stop;
        }
        /// <summary>
        /// Fill additional constants of range and timing pot
        /// 
        /// </summary>
        /// <param name="additionalConstant"></param>
        /// <param name="catID"></param>
        private void FillAdditionalConstants(ref byte[] additionalConstant, CatIDList catID)
        {
            int len = 4;
            bool foundTimingPot = false;
            bool foundRangePot = false;
            for (int potnum = 0; potnum < catID.Micon175_PotDetail.Count; potnum++)
            {
                if (catID.Micon175_PotDetail[potnum].PotName == "Timing2")
                {
                    string[] timepotConstants = new string[catID.Micon175_PotDetail[potnum].NoOfPosition];
                    timepotConstants = catID.Micon175_PotDetail[potnum].RangeConstants.Split(','); 

                    int TimeConstants = 10;
                    if (timepotConstants != null)
                    {
                        for (int timeconst = 0; timeconst < timepotConstants.Length; timeconst++)
                        {
                            additionalConstant[len++] = Convert.ToByte(timepotConstants[timeconst]);
                        }
                        if (TimeConstants - timepotConstants.Length > 0)
                        {
                            for (int remainingbyte = 0; remainingbyte < TimeConstants - timepotConstants.Length; remainingbyte++)
                            {
                                additionalConstant[len++] = 00;
                            }
                        }
                    }
                    else
                    {
                        for (int timeconst = 0; timeconst < TimeConstants; timeconst++)
                        {
                            additionalConstant[len++] = 00;
                        }
                    }
                    foundTimingPot = true;
                }

                if (catID.Micon175_PotDetail[potnum].PotName == "Range2")
                {
                    //Check Timng pot first
                    if (foundTimingPot == false)
                    {
                        for (int timeconst = 0; timeconst < 10; timeconst++)
                        {
                            additionalConstant[len++] = 00;
                        }
                    }

                    string[] potConstants = catID.Micon175_PotDetail[potnum].RangeConstants.Split(',');

                    //if Range pot data is 0
                    int ReservedBytes = 40;
                    if (catID.Micon175_PotDetail[potnum].NoOfPosition > 0)
                    {
                        for (int Potposition = 0; Potposition < catID.Micon175_PotDetail[potnum].NoOfPosition; Potposition++)
                        {                                                    
                            WriteLongToByteArray(Convert.ToUInt64(potConstants[Potposition]), ref additionalConstant, ref len);
                        }

                        for (int Potposition = catID.Micon175_PotDetail[potnum].NoOfPosition; Potposition < ReservedBytes / 4; Potposition++)
                        {
                            Write32(00, ref additionalConstant, ref len);                        
                        }
                    }
                    else
                    {
                        for (int Potposition = 0; Potposition < ReservedBytes / 4; Potposition++)
                        {
                            Write32(00, ref additionalConstant, ref len);                    
                        }
                    }

                    foundRangePot = true;
                }
                else if(potnum == catID.Micon175_PotDetail.Count - 1 && foundRangePot == false)
                {
                    for (int Potposition = 0; Potposition < 10; Potposition++)
                    {
                        Write32(00, ref additionalConstant, ref len);
                    }
                }

            }

        }



        #region Commented Filled method
        /*
        /// <summary>
        /// Fill all pot details into buffer and create query
        /// Created buffer write into hex file step by step
        /// Edit hex file Data
        /// Create new edited hex file
        /// </summary>
        /// <param name="dataParams"></param>
        /// <param name="catID"></param>
        public void FillPotDetails(ref byte[] dataParams, CatIDList catID)
        {
            int len = 0;

            HexEditor.clsHexEditor hex = new HexEditor.clsHexEditor();
            hex.getData("TimerDebug.hex");

            bool stat = false;           
            //stat = hex.EditHexFile("0xCC", "010203");
            
            //Device Id
            dataParams[len++] = (byte)catID.DeviceId;

            stat = hex.EditHexFile(catID.DeviceIdHexLocation, ((byte)catID.DeviceId).ToString());

            //EditHexFile(catID.DeviceIdHexLocation, ((byte)catID.DeviceId).ToString());
            //IsFixedTime

            dataParams[len++] = (byte)(catID.IsFixedTiming ? 1 : 0);
            stat = hex.EditHexFile(catID.IsFixedTimingHexLoc, ((catID.IsFixedTiming ? 1 : 0).ToString()));

            // EditHexFile(catID.IsFixedTimingHexLoc, ((byte)(catID.IsFixedTiming ? 1 : 0)).ToString());
            //Timing value
            
            Write32((ulong)catID.FixedTiming,ref dataParams, ref len);
            len++;
            //Convert and Write Array of Fixed Timing  to hexfile
            byte[] fixedtime = new byte[4];
            int Length = 0;
            Write32((ulong)catID.FixedTiming, ref fixedtime, ref Length);            
            string WriteFixedTiming = ConvertByteArrayToString(fixedtime);
            stat = hex.EditHexFile(((byte)catID.FixedTiming).ToString(), WriteFixedTiming);

            // Number of Pot positions of Timing Pot
            for (int NumOfPot = 0; NumOfPot < catID.Micon175_PotDetail.Count; NumOfPot++)
            {
                if(catID.Micon175_PotDetail[NumOfPot].PotName == "Timing")
                {
                    dataParams[len++] = (byte)catID.Micon175_PotDetail[NumOfPot].NoOfPosition;
                    //Need to change
                    stat = hex.EditHexFile("", ((byte)catID.Micon175_PotDetail[NumOfPot].NoOfPosition).ToString()); //Need to change
                    break;
                }
            }
            //fixed Range
            dataParams[len++] = (byte)(catID.IsFixedRange ? 1 : 0);

            stat = hex.EditHexFile(catID.IsFixedRangeHexLoc, (catID.IsFixedRange ? 1 : 0).ToString());

            //fixed range value
            Write32((ulong)catID.MentionNumber, ref dataParams, ref len);
            len++;

            //Convert and Write Array of Mension Number to hexfile
            byte[] fixedBytes = new byte[4];
            Length = 0;
            Write32((ulong)catID.MentionNumber, ref fixedBytes, ref Length);
            string WriteMensionNum = ConvertByteArrayToString(fixedBytes);
            stat = hex.EditHexFile(((byte)catID.MentionNumber).ToString(), WriteMensionNum);
            
            // Number of Pot positions of Timing Pot
            for (int NumOfPot = 0; NumOfPot < catID.Micon175_PotDetail.Count; NumOfPot++)
            {
                if (catID.Micon175_PotDetail[NumOfPot].PotName == "Range")
                {
                    dataParams[len++] = (byte)catID.Micon175_PotDetail[NumOfPot].NoOfPosition;

                    string[] potlable = catID.Micon175_PotDetail[NumOfPot].PotLables.Split(',');

                    for (int Potposition = 0; Potposition < catID.Micon175_PotDetail[NumOfPot].NoOfPosition; Potposition++)
                    {
                        Write32(Convert.ToUInt64(potlable[Potposition]),ref dataParams,ref len);
                        len++;
                        
                        //Convert and Write Array of Mension Number to hexfile
                        byte[] Potlablebytes = new byte[4];
                        Length = 0;
                        Write32(Convert.ToUInt64(potlable[Potposition]), ref Potlablebytes, ref Length);
                        string WritePotLable = ConvertByteArrayToString(fixedBytes);
                        //Do Change if needed
                        stat = hex.EditHexFile((catID.Micon175_PotDetail[NumOfPot].HexLocation).ToString(), WritePotLable); //Change

                    }
                    break;
                }
            }
            //Create New Hex File
            hex.createNewFile();

        } */ 
        #endregion

        /// <summary>
        /// Fill Additional features
        /// </summary>
        /// <param name="dataParams"></param>
        /// <param name="catID"></param>
        public void FillAdditionalfeatures(ref byte[] dataParams, CatIDList catID)
        {
            int len = 0;

            //Total buffer length
            if (catID.ControllerType == "G10")
                dataParams[len++] = (byte)dataParams.Length;
            //Device Id
            dataParams[len++] = (byte)catID.DeviceId;
                        
            //IsFixedTime
            dataParams[len++] = (byte)(catID.IsFixedTiming ? 1 : 0);

            //Timing value            
           // Write32((ulong)catID.FixedTiming, ref FixedTiming, ref tmplength);
            WriteLongToByteArray(Convert.ToUInt64(Convert.ToDouble(catID.FixedTiming) * 200), ref dataParams, ref len);

            // Number of Pot positions of Timing Pot
            string[] timepotConstants = null;
            if (catID.IsFixedTiming)
            {
                dataParams[len++] = 00;
            }
            else
            {
                for (int NumOfPot = 0; NumOfPot < clsGlobalVariables.NumberOfPots; NumOfPot++)
                {
                    if (catID.Micon175_PotDetail[NumOfPot].PotName == "Timing1" || catID.Micon175_PotDetail[NumOfPot].PotName == "Timing2")
                    {
                        dataParams[len++] = (byte)catID.Micon175_PotDetail[NumOfPot].NoOfPosition;
                        timepotConstants = catID.Micon175_PotDetail[NumOfPot].RangeConstants.Split(',');
                        break;
                    }
                }
            }

            //Write Timing pot constants 
            int TimeConstants = 10;
            if (timepotConstants != null)
            {
                for (int timeconst = 0; timeconst < timepotConstants.Length; timeconst++)
                {
                    dataParams[len++] = Convert.ToByte(timepotConstants[timeconst]);
                }
                if (TimeConstants - timepotConstants.Length > 0)
                {
                    for (int remainingbyte = 0; remainingbyte < TimeConstants - timepotConstants.Length; remainingbyte++)
                    {
                        dataParams[len++] = 00;
                    }
                }
            }
            else
            {
                for (int timeconst = 0; timeconst < TimeConstants; timeconst++)
                {
                    dataParams[len++] = 00;
                }
            }

            //fixed Range
            dataParams[len++] = (byte)(catID.IsFixedRange ? 1 : 0);
            
            //fixed range value

            // Write32((ulong)catID.MentionNumber, ref Fixedrange, ref tmplength);
            WriteLongToByteArray((ulong)catID.MentionNumber, ref dataParams, ref len);
          
            // Number of Pot positions of Timing Pot

            if (catID.IsFixedTiming || catID.IsFixedRange)
            {
                dataParams[len++] = 00;
                int ReservedBytes = 40;

                for (int Potposition = 0; Potposition < ReservedBytes / 4; Potposition++)
                {
                    //Write32(00, ref dataParams, ref len);                  
                    WriteLongToByteArray(00, ref dataParams, ref len);                  
                }
            }
            else
            {
                for (int NumOfPot = 0; NumOfPot < clsGlobalVariables.NumberOfPots; NumOfPot++)
                {
                    int found = 0;
                    if (catID.Micon175_PotDetail[NumOfPot].PotName == "Range1" || catID.Micon175_PotDetail[NumOfPot].PotName == "Range2")
                    {
                        found++;
                        if (catID.Micon175_PotDetail[NumOfPot].MiddleMarkCal)
                            dataParams[len++] = (byte)(catID.Micon175_PotDetail[NumOfPot].NoOfPosition - 1);
                        else
                            dataParams[len++] = (byte)catID.Micon175_PotDetail[NumOfPot].NoOfPosition;
                                                
                        string[] potConstants = catID.Micon175_PotDetail[NumOfPot].RangeConstants.Split(',');

                        //if Range pot data is 0
                        int ReservedBytes = 40;
                        if (catID.Micon175_PotDetail[NumOfPot].NoOfPosition > 0)
                        {
                            for (int Potposition = 0; Potposition < catID.Micon175_PotDetail[NumOfPot].NoOfPosition; Potposition++)
                            {
                                //Write32(Convert.ToUInt64(potConstants[Potposition]), ref dataParams, ref len);                                                     
                                WriteLongToByteArray(Convert.ToUInt64(potConstants[Potposition]), ref dataParams, ref len);
                            }
                            
                            for (int Potposition = catID.Micon175_PotDetail[NumOfPot].NoOfPosition; Potposition < ReservedBytes / 4; Potposition++)
                            {
                                Write32(00, ref dataParams, ref len);
                                // WriteLongToByteArray(00, ref dataParams, ref len);                            
                            }
                        }
                        else
                        {
                            for (int Potposition = 0; Potposition < ReservedBytes / 4; Potposition++)
                            {
                                Write32(00, ref dataParams, ref len);
                                // WriteLongToByteArray(00, ref dataParams, ref len);                            
                            }
                        }

                        break;
                    }
                    else if (clsGlobalVariables.NumberOfPots - 1 == NumOfPot && found == 0)
                    {
                        dataParams[len++] = 0;
                        for (int Potposition = 0; Potposition < 10; Potposition++)
                        {
                            Write32(00, ref dataParams, ref len);

                            // WriteLongToByteArray(00, ref dataParams, ref len);                            
                        }
                    }
                }
                
            }           

            //Fixed mode
            dataParams[len++] = (byte)(catID.IsFixedMode ? 1 : 0);
            //Fixed mode number
            dataParams[len++] = (byte)(catID.MentionMode);

            //Mode Pot Position
            for (int NumOfPot = 0; NumOfPot < catID.Micon175_PotDetail.Count; NumOfPot++)
            {
                if (catID.Micon175_PotDetail[NumOfPot].PotName == "Mode")
                {
                    dataParams[len++] = (byte)catID.Micon175_PotDetail[NumOfPot].NoOfPosition;
                    break;
                }
                else if(NumOfPot == catID.Micon175_PotDetail.Count - 1)
                {
                    dataParams[len++] = 0;
                    break;
                }
            }

            //Relay voltage
            if (catID.RelayVoltage != null && catID.RelayVoltage != "")
                dataParams[len++] = Convert.ToByte(catID.RelayVoltage);
            else
                dataParams[len++] = 00;

            //Relay Number
            dataParams[len++] = (byte)catID.RelayNumber;
            
            //Byte array to string
            string ModifiedData = ConvertByteArrayToString(dataParams);

            //Write Data in Hex file, After write data in hex file create new modified file
            if(catID.ControllerType == "G10")
            {
                clsGlobalVariables.MainWindowVM.StructureToWriteDataInFile();
               
                string WriteTimingPotDataToHex = clsGlobalVariables.clsCalibrationModuleObj.ConvertByteArrayToString(clsGlobalVariables.MainWindowVM.Timing1ReadDatabytes.ToArray());

                string WriteRangePotDataToHex = clsGlobalVariables.clsCalibrationModuleObj.ConvertByteArrayToString(clsGlobalVariables.MainWindowVM.Range1ReadDatabytes.ToArray());

                string WriteModePotDataToHex = clsGlobalVariables.clsCalibrationModuleObj.ConvertByteArrayToString(clsGlobalVariables.MainWindowVM.ModeReadDatabytes.ToArray());

                string WritePot4PotDataToHex = clsGlobalVariables.clsCalibrationModuleObj.ConvertByteArrayToString(clsGlobalVariables.MainWindowVM.Pot4ReadDatabytes.ToArray());

                string WriteCalibrationStatus = "01"; //can vary 

                ModifiedData = ModifiedData + WriteTimingPotDataToHex + WriteRangePotDataToHex + WriteModePotDataToHex + WritePot4PotDataToHex + WriteCalibrationStatus;
                                
                EditHexFile(catID.DeviceIdHexLocation, ModifiedData, catID);
            }
                
        }
        /// <summary>
        /// Fill runtime features
        /// </summary>
        /// <param name="dataParams"></param>
        /// <param name="catID"></param>
        public void FillRuntimefeatures(ref byte[] dataParams, CatIDList catID)
        {
            int len = 0;
                       
            //IsTiming changed
            dataParams[len++] = (byte)(catID.RunTime_TimingChange ? 1 : 0);

            //IsRange changed
            dataParams[len++] = (byte)(catID.RunTime_RangeChange ? 1 : 0);

            //Range adjust or reset
            if (catID.RunTime_RangeChange)
            {
                if (catID.RangeChangeData == "Adjust")
                    dataParams[len++] = 1;
                else if (catID.RangeChangeData == "Reset")
                    dataParams[len++] = 2;
                else
                    dataParams[len++] = 0;
            }
            else
                dataParams[len++] = 0;

            //Mode change adjust or reset
            //if (catID.ModeChangeData == "Reset")
            //    dataParams[len++] = 1;
            //else if (catID.ModeChangeData == "Adjust")
            //    dataParams[len++] = 2;
            //else
            //    dataParams[len++] = 0;

            //IsMode changed
            dataParams[len++] = (byte)(catID.RunTime_ModeChange ? 1 : 0);

            //PWM Status
            dataParams[len++] = (byte)(catID.PWMEnable ? 1 : 0);

            //OnOff Mode
            dataParams[len++] = (byte)(catID.RangeConstOnOffMode ? 1 : 0);
            //Relay voltage    

            //Write32(Convert.ToUInt64(catID.RelayVoltage), ref RalyVtg, ref tmplen);
            //WriteLongToByteArray(Convert.ToUInt64(catID.RelayVoltage), ref dataParams, ref len);

        }
               
        /// <summary>
        /// Byte Array to string
        /// </summary>
        /// <param name="rxBuff"></param>
        /// <returns></returns>
        public string ConvertByteArrayToString(byte[] rxBuff)
        {
            char[] bitchrArray = BitConverter.ToString(rxBuff).ToCharArray();
            string bitString = "";
            foreach (var chr in bitchrArray)
            {
                if (chr != '-')
                    bitString += chr;
            }
            return bitString;
        }
        /// <summary>
        /// Write in hex file
        /// </summary>
        /// <param name="Hexlocation"></param>
        /// <param name="bitString"></param>
        public void EditHexFile(string Hexlocation, string bitString, CatIDList catID)
        {
            HexEditor.clsHexEditor hex = new HexEditor.clsHexEditor();
            hex.getData(clsGlobalVariables.strmLocalMotPath);

            bool stat = false;
            stat = hex.EditHexFile(Hexlocation, bitString);
            //stat = hex.EditHexFile("0D80", "010203");

            string NewfilePath = hex.createNewFile();
            clsGlobalVariables.OriginalMotPath = catID.MotFilePath;
            clsGlobalVariables.SelectedMotPath = NewfilePath;
        }

        /// <summary>
        /// Convert unsigned long value to byte buffer/Array
        /// </summary>
        /// <param name="value"></param>
        /// <param name="buffer"></param>
        /// <param name="offset"></param>
        private void Write32(ulong value,ref byte[] buffer,ref int offset)
        {
            buffer[offset++] = (byte)((value >> 24) & 0xFF);
            buffer[offset++] = (byte)((value >> 16) & 0xFF);
            buffer[offset++] = (byte)((value >> 8) & 0xFF);
            buffer[offset++] = (byte)(value & 0xFF);
        }

        private void WriteLongToByteArray(ulong value, ref byte[] buffer, ref int offset)
        {
            byte[] ConvTobyte = new byte[4];
            int length = 0;
            ConvTobyte[length++] = (byte)((value >> 24) & 0xFF);
            ConvTobyte[length++] = (byte)((value >> 16) & 0xFF);
            ConvTobyte[length++] = (byte)((value >> 8) & 0xFF);
            ConvTobyte[length++] = (byte)(value & 0xFF);

            for (length = ConvTobyte.Length - 1; length >= 0; length--)
            {
                buffer[offset++] = ConvTobyte[length];
            }           
        }

    }
}
