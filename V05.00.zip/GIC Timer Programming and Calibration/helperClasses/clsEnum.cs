﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIC_Timer_Programming_and_Calibration.helperClasses
{
    
    /// <summary>
    /// EnmNumberofpots are the pots present for particular cat id.
    /// According to pots fills the Lists.
    /// </summary>
    public enum EnmNumberofpots : int
    {
        One = 1,
        Two = 2,
        Three = 3,
        Four = 4
    }

    public enum EnmSwitchCalibrationstate : byte
    {
        Stop = 0,
        SwitchCalibStarted,      
        SwitchCalibCompleted,
        SwitchCalibFailed,
    }

    /// <summary>
    /// EnmModuleName is added for flow of functions of software.
    /// All parameters are in byte format
    /// </summary>
    public enum EnmModuleName : byte
    {
        PotCalibration = 0,
        AdditionalandRuntimeFeatures,
        Programming,
        CalibrationData,
        CalibrationStatus,
        ZCDCalibration,
        SwitchCalibration,
        Stop
    }


    /// <summary>
    /// Pot Edit Validation Messages
    /// </summary>
    public enum EditPot : byte
    {
        OK = 0,   //OK
        MinMaxRangeNumeric = 1,      //minmax values should be numeric
        constNumeric = 2,            //Constant should be numeric
        timingExceeded = 3,          //if timing Exceeded on 240,
        minmaxrange = 4,             //If min value is greater than max
        Differencenumeric = 5,       //Difference should be in numeric
    }

    /// <summary>
    /// PLC_OutputOnOff enum used for PLC Sequence
    /// </summary>
    public enum PLC_OutputOnOff : byte
    {
        PLC_ON_SQ1 = 0x01,   //Q0 -ON Q12-ON Q8-ON -------> SQ1
        PLC_ON_SQ2 = 0x02,   //Q0 -ON Q12-ON Q8-OFF -------> SQ2
        PLC_ON_SQ3 = 0x03,   //Q1 -ON Q12-ON Q8-ON -------> SQ3
        PLC_ON_SQ4 = 0x04,   //Q1 -ON Q12-ON Q8-OFF -------> SQ4
        PLC_ON_SQ5 = 0x05,   //Q2 -ON Q12-ON Q8-ON -------> SQ5
        PLC_ON_SQ6 = 0x06,   //Q2 -ON Q12-ON Q8-OFF -------> SQ6
        PLC_ON_SQ7 = 0x07,   //Q4 -ON Q13-ON Q8-ON -------> SQ7
        PLC_ON_SQ8 = 0x08,   //Q4 -ON Q13-ON Q8-OFF -------> SQ8
        PLC_ON_SQ9 = 0x09,   //Q5 -ON Q13-ON Q8-ON -------> SQ9
        PLC_ON_SQ10 = 0x0A,  //Q5 -ON Q13-ON Q8-OFF -------> SQ10
        PLC_ON_SQ11 = 0x0B,  //Q5 -ON Q13-ON Q8-OFF -------> SQ11
        PLC_ON_SQ12 = 0x0C,  //Q3 -ON Q12-ON Q8-ON -------> SQ12
        PLC_ON_SQ13 = 0x0D,  //Q3 -ON Q12-ON Q8-OFF -------> SQ13

        ReadPLCAnalogVoltage = 0x0C
    }
    
    public enum clsEnumFunctionCode : byte
    {
        //PotInfo
        PotInfo = 0x01,
        //PotRead
        PotRead = 0x02,
        //Additional features Changes
        Additionalfeatures = 0x03,
        //Runtime Changes
        RunTimeChanges = 0x04,
        //Calibration Data
        CalibrationData = 0x05,
        //Calibration Status
        CalibrationStatus = 0x06,
        //Version
        FwVersion = 0x07,
        //Voltage
        Voltage = 0x08,
        //Start relay Self Calibration
        ZCD_SelfCalibration = 0x0A,
        //Get relay on Time
        ZCD_GetRelayONTime = 0x0B,
        //Switch checking
        Switch_Checking = 0x0C,
        //Additional features Changes,Added additional constants for two timings pots and two range pots
        AdditionalConstants = 0x1F,
    }
    public enum clsEnumReadWriteCode : byte
    {
        //Read
        Readbyte = 0x01,
        //Write
        Writebyte = 0x02
    }
    public enum clsEnumPotName : byte
    {        
        //Timing1
        Timing1 = 0x01,

        //Timing2
        Timing2 = 0x02,               
      
        //range1
        Range1 = 0x03,

        //range2
        Range2 = 0x04,

        //Mode
        Mode = 0x05,

        //Extra
        Extrapot
    }
    public enum enmPotType : byte
    {
        /// <summary>
        /// LINEAR is used to select Linear Pot Type.
        /// </summary>
        LINEAR = 0x01,
        /// <summary>
        /// DETENT is used to select Detent Pot Type.
        /// </summary>
        DETENT = 0x02
    }
    public enum enmMbExceptionFlag : byte
    {
        /// <summary>
        /// MB_SUCCESS is used to return ModBus Success Status.
        /// </summary>
        MB_SUCCESS = 0x00,

        /// <summary>
        /// MB_FAILED is used to return ModBus Failed Status.
        /// </summary>
        MB_FAILED = 0X01,

        /// <summary>
        /// MB_ERR_HANDLED is used to return ModBus Error Handled Status when an error is occurred during communication.
        /// </summary>
        MB_ERR_HANDLED = 0x02,

        /// <summary>
        /// MB_STOP_FLAG is used to return ModBus Stop Flag Status when communication is stopped.
        /// </summary>
        MB_STOP_FLAG = 0x03,

        /// <summary>
        /// MB_SUCCESS is used to return ModBus Time Out Status when Time Out occurs while communicating.
        /// </summary>
        MB_TIME_OUT = 0x04,

        /// <summary>
        /// MB_NO_CHAR_RECEIVED is used to return ModBus No Character Received Status when no data is received.
        /// </summary>
        MB_NO_CHAR_RECEIVED = 0x05,

        /// <summary>
        /// MB_BUSY is used to return ModBus Busy Status when COM port is busy.
        /// </summary>
        MB_BUSY = 0x06,

        /// <summary>
        /// MB_INVALID_DEVICEID is used to return ModBus Invalid Device Id Status.
        /// </summary>
        MB_INVALID_DEVICEID = 0x07,

        /// <summary>
        /// MB_INVALID_FUNCTION is used to return ModBus Invalid Function Status when wrong function is called.
        /// </summary>
        MB_INVALID_FUNCTION = 0x08,

        /// <summary>
        /// MB_NO_CRC_MATCH is used to return when CRC did not Match.
        /// </summary>
        MB_NO_CRC_MATCH = 0x09,

        /// <summary>
        /// MB_INVALID_BUFF_LEN is used to return during Invalid Buffer length is received.
        /// </summary>
        MB_INVALID_BUFF_LEN = 0x0A
    }
}
