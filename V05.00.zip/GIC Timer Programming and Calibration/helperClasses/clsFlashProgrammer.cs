﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Xml;


namespace GIC_Timer_Programming_and_Calibration.helperClasses
{
    public class clsFlashProgrammer
    {
        bool blnFlag = false; //Flag to check programming verification already exist or not.

        /// <summary>
        /// Clear temp folder while start the process
        /// </summary>
        /// <returns></returns>
        public bool ClearFiles()
        {
            try
            {
                if (Directory.Exists(clsGlobalVariables.TempPath))
                {
                    DeleteDirectory(clsGlobalVariables.TempPath, true);
                    Directory.CreateDirectory(clsGlobalVariables.TempPath);                    
                }
                else
                {
                    Directory.CreateDirectory(clsGlobalVariables.TempPath);
                }

                if (Directory.Exists(clsGlobalVariables.TempPath))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception )
            {
                return false;
            }
        }

        //<MemberName>DeleteDirectory</MemberName>        
        // <summary>
        // This function is used to delete the dirctory which is passed to it as a parameter.
        // </summary>        
        // <ClassName>clsFlashProgrammer</ClassName>
        public void DeleteDirectory(string strmpath, bool blnrecursive)
        {
            try
            {
                if (blnrecursive)
                {
                    var subfolders = Directory.GetDirectories(strmpath);
                    foreach (var s in subfolders)
                    {
                        DeleteDirectory(s, blnrecursive);
                    }
                }
                var files = Directory.GetFiles(strmpath);
                //read only attribute of every file present in the directory is checked.
                foreach (var objfiles in files)
                {
                    //If file which is to be saved is read only then 
                    //Read Only attribute to that file is removed here before saving that file.
                    var attr = File.GetAttributes(objfiles);
                    if ((attr & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                    {
                        File.SetAttributes(objfiles, attr ^ FileAttributes.ReadOnly);
                    }
                    File.Delete(objfiles);
                }
                // At this point, all the files and sub-folders have been deleted.
                // So we delete the empty folder using the OOTB Directory.Delete method.
                Directory.Delete(strmpath);
            }
            catch (Exception )
            {
                
            }
        }
        /// <summary>
        /// Create temporary directory if not exists
        /// Copy files from given path to this temp folder
        /// </summary>
        /// <returns></returns>
        public bool GetFiles()
        {
            try
            {                
                System.IO.File.Copy(clsGlobalVariables.SelectedMotPath,  clsGlobalVariables.TempPath + "\\" + clsGlobalVariables.SelectedDeviceName + ".hex",true);
                System.IO.File.Copy(clsGlobalVariables.SelectedRpjPath, clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".rpj");
                System.IO.File.Copy(clsGlobalVariables.SelectedRwsPath, clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".rws");

                
                clsGlobalVariables.strmLocalRPJ = clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".rpj";
                clsGlobalVariables.strmLocalRscPath = clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".rsc";
                clsGlobalVariables.strmLocalMotPath = clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".hex";
                clsGlobalVariables.strmLocalRwsPath = clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".rws";

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        //blnErrorFlag Check error is present or not.                     

        //<MemberName>getController</MemberName>
        // <summary>
        // Method is used to read the Controller,ProgramFile name(.mot or .hex),Com port from Project file(.rpj) of RFP.
        // </summary>
        // <ModifiedSummary> </ModifiedSummary>
        // <remarks></remarks>
        // <ClassName>clsFlashProgrammer</ClassName>
        public bool PrepareProjectFile()
        {
            try
            {               
                
                string strmDetectOS = System.Environment.OSVersion.ToString();
                XmlDataDocument xmldoc = new XmlDataDocument();
                String strmCommun = "COM";
                XmlNodeList xmlnode;
                int imIterator = 0; //set the defult index for seraching parameter.

                //Default settings present on form            
                   
                xmldoc.Load(clsGlobalVariables.strmLocalRPJ);                      

                //Read Program file path with its name from.rpj(Project file).
                        
                xmlnode = xmldoc.GetElementsByTagName("HexaFileName");                            
                if (xmlnode != null && xmlnode.Count != 0)
                {
                    //set the MOT/HEX file path
                    xmlnode[imIterator].InnerText = clsGlobalVariables.strmLocalMotPath;                                                    
                }
				//Check that "Verify" tag is present or not
                xmlnode = xmldoc.GetElementsByTagName("IsVerifying");
                if (xmlnode != null && xmlnode.Count != 0)
                {
                    String strmVerify = xmlnode[imIterator].InnerText;

                    //Added by Anil N
                    //Added IN RFP V02.5 for check "Verify" Command is present or not
                    //Flag to check programming verification already exist or not.
                    //If programming verification already exist, flag set to true, else false
                    if (strmVerify == "True")
                    {
                        blnFlag = true;
                    }
                    else
                    {
                        blnFlag = false;                        
                    }
                }
                //when user select COM for programming then following changes should be done in .rpj file.
                if (strmCommun == "COM")
                {
                    /* Following changes are done in case of COM Port */
                    imIterator = 0;//This field are only one
                    xmlnode = xmldoc.GetElementsByTagName("SelectToolName");
                    if (xmlnode != null && xmlnode.Count != 0)
                    {
                        xmlnode[imIterator].InnerText = clsGlobalVariables.SelectedComPort;                      
                        xmlnode = xmldoc.GetElementsByTagName("CommunicationSpeed");
                        xmlnode[imIterator].InnerText = "Speed"+clsGlobalVariables.SelectedBaudRate+"Bps";
                        //-------Changes End.
                    }
                }                        
                        
                var attr = File.GetAttributes(clsGlobalVariables.strmLocalRPJ);
                if ((attr & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                {
                    //Files Read only attribute is removed here.
                    File.SetAttributes(clsGlobalVariables.strmLocalRPJ, attr ^ FileAttributes.ReadOnly);
                }
                xmldoc.Save(clsGlobalVariables.strmLocalRPJ);//Save all changes perform in.rpj(Project File of RFP)
                return true;
                
            }
            catch (Exception )
            {
                //MessageBox.Show(ex.Message, clsGLobalVariable.strmProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
               // enDisControls(true);
                return false;
            }
        }

        //<MemberName>WriteBatchFile</MemberName>       
        // <summary>
        // Method used to set RFP software path into .bat file.
        // 1)Check OS accordingly take the path of RFP.
        // 2)Write .bat file for Windows 7 and above.
        // 3)Write .bat,.rsc file for XP .
        // </summary> 
        // <ClassName>clsFlashProgrammer</ClassName>
        public bool WriteBatchFile()
        {
            String strmmReturn;//take data from batch file.                     
            StreamWriter ogStrmWriter;//Writter for batch file.         
            try
            {
                               
                StreamWriter ogRSCWriter = new StreamWriter(clsGlobalVariables.strmLocalRscPath);//Script file for programming the device
                ogRSCWriter.WriteLine("log " + "\"" + clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.strmLogFileName + "\"");//log file after execution
                ogRSCWriter.WriteLine("workspace " + "\"" + clsGlobalVariables.strmLocalRwsPath + "\"");// Project file in RFPV02.5
                ogRSCWriter.WriteLine("programfile " + "\"" + clsGlobalVariables.strmLocalMotPath + "\"");//Mot/Hex file for programming
                ogRSCWriter.WriteLine("ep");//Command erase and program

                //Checked programming verification already exist or not
                //Add command for verify if programming verification already not exist
                if (!blnFlag)                
                    ogRSCWriter.WriteLine("Verify"); //command for verify
                                
                ogRSCWriter.Close();  //close the .rsc file.

                var controller = clsGlobalVariables.SelectedControllerType.Split('/');
                
                StreamWriter ogRWSWriter = new StreamWriter(clsGlobalVariables.strmLocalRwsPath);
                if(controller.Length >= 1)
                    ogRWSWriter.WriteLine("<RfpWorkspace><ProductVersion>2.05.03.00</ProductVersion><FormatVersion>2.0</FormatVersion><WindowMode>0</WindowMode><ActiveProjectName>"+ controller[0] + "</ActiveProjectName><Name project=\""+ controller[0] + "\"><RelativePath>" + clsGlobalVariables.SelectedDeviceName + ".rpj </RelativePath><ActiveProgramName/></Name></RfpWorkspace>");
                else
                    return false;
                ogRWSWriter.Close();//close the .rws file.                              
  

                strmmReturn = GetInstalledPath("Renesas Flash Programmer V2.05");//check RFP software is installed or not.    

                //strmmReturn = GetInstalledPath("Renesas Flash Programmer V3.03");//check RFP software is installed or not.    

                ogStrmWriter = new StreamWriter(clsGlobalVariables.TempPath + @"\" + clsGlobalVariables.SelectedDeviceName + ".bat");
                ogStrmWriter.WriteLine(":START");
                // "/d" is necessary to run software from any directory.
                ogStrmWriter.WriteLine("cd /d " + strmmReturn); //Path of RFP installed on the system.
                ogStrmWriter.WriteLine("RFP.exe " + "\"" + clsGlobalVariables.strmLocalRscPath + "\"");//Project file for execution
                ogStrmWriter.WriteLine(":EXIT");//Exit after executing file
                ogStrmWriter.Close();//close the batch file

                return true;
               

            }
            catch (Exception )
            {
                //MessageBox.Show(ex.Message, clsGLobalVariable.strmProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //enDisControls(true);
                return false;
            }
        }



        //<MemberName>GetInstalledPath</MemberName>        
        // <summary>
        // Method is used to check whether RFP installed in system if yes then take its installed location.
        // </summary>
        // <ClassName>FrmMain</ClassName>
        private String GetInstalledPath(String strmOSName)
        {
            const int BIT64 = 8;//64 bit OS Constant
            RegistryKey parentKey;
            string[] nameList;
            RegistryKey regKey = null;
            //For Windows 32-bit OS
            if (IntPtr.Size != BIT64)
            {
                parentKey = Registry.LocalMachine.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall");
            }
            else
            {  //For Windows 64-bit OS
                parentKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall");
            }
            nameList = parentKey.GetSubKeyNames();//Get the key of software.
            for (int imCount = 0; imCount < nameList.Length; imCount++)
            {
                regKey = parentKey.OpenSubKey(nameList[imCount]);//list of software
                try
                {
                    if (regKey.GetValue("DisplayName") != null)
                    {
                        //Get path of RFP software
                        if (regKey.GetValue("DisplayName").ToString() == strmOSName)
                        {
                            return regKey.GetValue("InstallLocation").ToString();//get installed location of RFP

                        }
                    }
                }
                catch (Exception) { }
            }
            return "";
        }

    }
}
