﻿using GIC_Timer_Programming_and_Calibration.model;
using GIC_Timer_Programming_and_Calibration.view;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIC_Timer_Programming_and_Calibration.helperClasses
{
    public static class clsGlobalVariables
    {
        public static Micon225_CatalogueConfigVM CatalogueConfigVM = null;
        public static Micon175_CatalogueConfigVM One_M_CatalogueConfigVM = null;        
        public static MainWindowVM MainWindowVM = null;
        public static SwitchCalibrationVM SwitchCalibrationVM = null;     
        public static RelayCalibrationRetryVM RelayCalibrationRetryVM = null;
        public static string SelectedDeviceType;
        public static string SelectedDeviceName;
        public static string SelectedDeviceNameOfTreeView;
        public static string SelectedControllerType = "";
        public static string SelectedRFPV = "";
        public static string SelectedComPort = "COM1";
        public static string SelectedBaudRate = "9600";
        public static CatList SelectedCatListObj = null;
        public static CatIDList SelectedCatIdObj = null;
        public static string SelectedPLCComPort = "";
        public static bool EnableBeep;        
        public static bool IsFileChanged = false;
        public static bool IsOkclicked = false;
        public static bool IsRetryclicked = false;
        public static bool IsRestartclicked = false;
        public static int[] TempPotvalidation = null;     
        public static bool Break = false;
        public static int NumberOfPots = 0;
        public static int RetryCount = 3;
        public static int CalibrationStatusflag = FAILURE;
        public static bool IsTimerRunning = false;
        public static bool IsRelayRetrydone = false;
        public static bool IsSwitchCalibFailed = false;

        public static string SelectedRpj = "";
        public static string SelectedRws = "";

        #region const variables      
        public const int SUCCESS = 0;
        public const int FAILURE = -1;
        #endregion

        public static string strmDetectOS = "", strmProjectPath = "", strmOS = "", strmLocalRPJ = "", strmLogFileName = "Summary.log", strmCatalouge = "", strmFail = "Fail", strmNameOfController = "";
        public static string strmXP = "XP", StrmWindows = "Windows", strmINIPath = "", strmLogPath = "", strmdestination_dir = "", strmForwardSlash = @"\", strmRWS = "", strmLocalMotPath = "";
        public static string TempPath = ""; 
        public static string SelectedMotPath = ""; 
        public static string SelectedImagePath = "";
        public static string OriginalMotPath = ""; 
        public static string SelectedRpjPath = ""; 
        public static string SelectedRwsPath = ""; 
        public static string Micon175Jsonpath = ""; 
        public static string Micon225Jsonpath = "";
        public static string strmLocalRwsPath = "";
        public static string strmLocalRscPath = "";
        public static string strMessage = "";
        public static string strMessageStatus = "";
        public static string strCalWindowNm = "";

        //temp
        public static string tempValue = "10";
        public static byte strmModuleCompleteCall = 0;   //Stores completed module's name.
        public static byte strSwitchCalibStatus = 0;   //Stores switch calibration process status.
        public static int strSwitchdata = 0;   //Stores switch calibration process status.
        public static int strSwitchcheckstate = 0;
        public static int switchtestvar = 0;
        public static int switchcasevar = 0;
        public static int SwitchCnt = 0;
        public static ModbusRTU ObjSerialComPort = new ModbusRTU();
        public static clsCalibrationModule clsCalibrationModuleObj = new clsCalibrationModule();

        #region Database details        
        public static string DatabasePath = "";
        #endregion

        #region user credentials
        public static string LoggedInUser = "";
        public static int LoggedInUserId = 0;
        public static bool IsLoggedInUserAdmin = false;        
        #endregion

        #region userValidation enum
        public enum UserStatus
        {
            Valid = 0,
            Invalid = 1,
            DatabaseConectionFailed = 3,
            UserAdded = 4,
            UserAddFailed = 5,
            UserEdited = 6,
            UserEditFailed = 7,
            UserDeleted = 8,
            UserDeleteFailed = 9,
            ExceptionHandeled = 10,
            NoRecordFound = 11,
            UserIsLoggedIn = 12
        }
        #endregion

        #region MessageIcon enum
        public enum MsgIcon
        {
            Message = 1,
            Error = 2,
            Question = 3
        }
        #endregion

        #region Autentication Module Flag
        public static bool EnableAutentication = false;
        #endregion
    }


}
