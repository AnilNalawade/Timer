﻿using System;
using System.IO.Ports;

namespace GIC_Timer_Programming_and_Calibration.helperClasses
{
    public class ModbusRTU
    {

        #region

        byte[] _SendBuffPotInfo = null;
        byte[] _SendBuffPotRead = null;

        #endregion

        MyLogWriterDLL.LogWriter mylog;

        public ModbusRTU()
        {
            mylog = new MyLogWriterDLL.LogWriter();
            mylog.LogWriterStatus();
        }


        #region Private variable declaration
        SerialPort _port = new SerialPort();
        byte[] _SendBuff;
        #endregion

        

        /// <summary>
        /// <param name="Reg_No">Modbus registers</param>
        /// <param name="ErrorCode">Used to check that respance is valid or not </param>
        /// <param name="entity">To  check Run Or Edit</param>
        /// <returns></returns>
        public byte[] SendQueryGetResponse(ref int ErrorCode, byte[] txBuff, string portName, string baudrate, bool skipcloseport= false)
        {
            byte[] _ReciveBuff = null;
            try
            {
                //Open Com port
                Serial_Port_Open(portName, baudrate);

                _port.Write(txBuff, 0, txBuff.Length);

                int TotalSizeofBuff = 0;

                int DataToRead = 0;

                //For pot reading delay between 2 counts reduced to 40ms.
                //For Other function codes its 300ms
                if (txBuff[1] == (byte)clsEnumFunctionCode.PotRead)
                    System.Threading.Thread.Sleep(20);
                else
                    System.Threading.Thread.Sleep(300);
                DataToRead = _port.BytesToRead;
                //MyLogWriterDLL.LogWriter.WriteLog("Port.BytesToRead : " + DataToRead.ToString());
                if (DataToRead == 0)
                {
                    ErrorCode = clsGlobalVariables.FAILURE;

                    if (skipcloseport == false)
                        Serial_Port_Close(portName);

                    return _ReciveBuff;
                }

                while (DataToRead != TotalSizeofBuff)
                {
                    DataToRead = TotalSizeofBuff;
                    System.Threading.Thread.Sleep(15);
                    TotalSizeofBuff = _port.BytesToRead;
                    if (TotalSizeofBuff == DataToRead || TotalSizeofBuff > 200)
                        break;
                }

                _ReciveBuff = new byte[TotalSizeofBuff];
                _port.Read(_ReciveBuff, 0, TotalSizeofBuff);

                if (_ReciveBuff.Length != 0)
                {
                    ErrorCode = clsGlobalVariables.SUCCESS;
                }
                else
                {
                    ErrorCode = clsGlobalVariables.FAILURE;
                }
                //Close Com port
                if (skipcloseport == false)
                    Serial_Port_Close(portName);

                return _ReciveBuff;
                
            }
            catch (Exception)
            {
                Serial_Port_Close(portName);
                return _ReciveBuff;
            }



        }



        /// <summary>
        /// <param name="Reg_No">Modbus registers</param>
        /// <param name="ErrorCode">Used to check that respance is valid or not </param>
        /// <param name="entity">To  check Run Or Edit</param>
        /// <returns></returns>
        public byte[] GetResponseOfSelfCalibration(ref int ErrorCode, string portName, string baudrate, bool skipcloseport= false)
        {
            byte[] _ReciveBuff = null;
            try
            {
                //Open Com port
                //Serial_Port_Open(portName, baudrate);

                int TotalSizeofBuff = 0;

                int DataToRead = 0;

                DataToRead = _port.BytesToRead;

                if (DataToRead == 0)
                {
                    ErrorCode = clsGlobalVariables.FAILURE;

                    if(skipcloseport == false)
                        Serial_Port_Close(portName);

                    return _ReciveBuff;
                }

                while (DataToRead != TotalSizeofBuff)
                {
                    DataToRead = TotalSizeofBuff;
                    System.Threading.Thread.Sleep(15);
                    TotalSizeofBuff = _port.BytesToRead;
                    if (TotalSizeofBuff == DataToRead || TotalSizeofBuff > 200)
                        break;
                }

                _ReciveBuff = new byte[TotalSizeofBuff];
                _port.Read(_ReciveBuff, 0, TotalSizeofBuff);

                if (_ReciveBuff.Length != 0)
                {
                    ErrorCode = clsGlobalVariables.SUCCESS;
                }
                else
                {
                    ErrorCode = clsGlobalVariables.FAILURE;
                }
                //Close Com port
                if (skipcloseport == false)
                    Serial_Port_Close(portName);

                return _ReciveBuff;

            }
             catch (Exception)
            {
                if (skipcloseport == false)
                    Serial_Port_Close(portName);
                return _ReciveBuff;
            }



        }

        /// <summary>
        /// Closing port
        /// </summary>
        /// <param name="portName"></param>
        public void Serial_Port_Close(string portName)
        {
            if (_port.IsOpen)
                _port.Close();

        }
        /// <summary>
        /// Opening Port
        /// </summary>
        /// <param name="portName"></param>
        public void Serial_Port_Open(string portName, string buadrate)
        {
            try
            {
                _port.PortName = portName;
                _port.BaudRate = Convert.ToInt32(buadrate);

                _port.Parity = Parity.None;
                _port.DataBits = 8;
                _port.StopBits = StopBits.One;
                _port.ReadTimeout = 1000;
                _port.WriteTimeout = 1000;

                _port.DtrEnable = true;
                _port.RtsEnable = true;
                if (!_port.IsOpen)
                    _port.Open();
                
            }
            catch (Exception)
            {
                //MessageBox.Show(err.Message);
                Serial_Port_Close(portName);
            }
        }
        /// <summary>
        /// To check is port open or close
        /// </summary>
        /// <returns></returns>
        public bool IsSerialPortOpen()
        {
            if (_port.IsOpen)
                return true;
            else
                return false;
        }

        public void Port_Close()
        {
            if (_port != null)
            {
                if (_port.IsOpen)
                {
                    _port.Close();
                }
            }
        }

        /// <summary>
        /// Function calculates checksum and returns checksum as byte 
        /// </summary>
        /// <param name="DataBuff"></param>
        /// <returns></returns>
        public byte CalculateChecksum(byte[] DataBuff)
        {

            byte chkSumByte = 0x00;
            try
            {
                for (int i = 0; i < DataBuff.Length; i++)
                {
                    chkSumByte = Convert.ToByte((chkSumByte + DataBuff[i]) & 0xFF);
                }
                chkSumByte = Convert.ToByte((chkSumByte + 0x05) & 0xFF);
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("CalculateChecksum : " + ex.StackTrace + ex.Message);
            }
            return chkSumByte;
        }

        /// <summary>
        /// CRC Calculations
        /// </summary>
        /// <param name="CRC"></param>
        /// <param name="pDataBuff"></param>
        public void CalculateCRC(ref byte[] CRC, byte[] pDataBuff)
        {
            ushort CRCFull = 0xFFFF;
            byte CRCHigh = 0xFF, CRCLow = 0xFF;
            char CRCLSB;

            for (int i = 0; i < (pDataBuff.Length) - 2; i++)
            {
                CRCFull = (ushort)(CRCFull ^ pDataBuff[i]);

                for (int j = 0; j < 8; j++)
                {
                    CRCLSB = (char)(CRCFull & 0x0001);
                    CRCFull = (ushort)((CRCFull >> 1) & 0x7FFF);

                    if (CRCLSB == 1)
                        CRCFull = (ushort)(CRCFull ^ 0xA001);
                }
            }

            CRC[1] = CRCHigh = (byte)((CRCFull >> 8) & 0xFF);
            CRC[0] = CRCLow = (byte)(CRCFull & 0xFF);

        }

        public void BREAKWORD(byte[] pTemparr, ushort pProperty)
        {
            uint uiTemp;
            uiTemp = ((uint)pProperty) & 255;
            pTemparr[0] = Convert.ToByte(uiTemp);
            uiTemp = pProperty;
            uiTemp = uiTemp >> 8;
            pTemparr[1] = Convert.ToByte((uiTemp & 255));
        }

        public void BREAKINT(byte[] pTemparr, int pProperty)
        {
            pTemparr[3] = (byte)((pProperty & 0xff000000) >> 24);
            pTemparr[2] = (byte)((pProperty & 0x00ff0000) >> 16);
            pTemparr[1] = (byte)((pProperty & 0x0000ff00) >> 8);
            pTemparr[0] = (byte)((pProperty & 0x000000ff));
        }


        /// <summary>
        /// This function is used to Make frame to read PotInfo from Device
        /// </summary>
        /// <param name="deviceId"></param>
        /// <param name="functionCode"></param>
        /// <param name="readWrite"></param>
        /// <param name="data"></param>
        /// <returns>Byte array containing query to send with checksum calculated</returns>
        public byte[] MakeFrame(byte deviceId, byte functionCode, byte readWrite, byte[] data)
        {
            if (data != null)
                _SendBuffPotInfo = new byte[5 + data.Length];
            else
                _SendBuffPotInfo = new byte[5];

            int len = 0;
            _SendBuffPotInfo[len++] = deviceId;
            _SendBuffPotInfo[len++] = functionCode;
            _SendBuffPotInfo[len++] = readWrite;
            if (data != null)
            {
                _SendBuffPotInfo[len++] = Convert.ToByte(data.Length);
                foreach (byte item in data)
                {
                    _SendBuffPotInfo[len++] = item;
                }
            }
            else
                _SendBuffPotInfo[len++] = 0;

            _SendBuffPotInfo[len++] = CalculateChecksum(_SendBuffPotInfo);

            return _SendBuffPotInfo;
        }

        /// <summary>
        /// This function is used to Make frame to read Potvalues from Device
        /// </summary>
        /// <param name="deviceId"></param>
        /// <param name="functionCode"></param>
        /// <param name="readWrite"></param>
        /// <param name="data"></param>
        /// <returns>Byte array containing query to send with checksum calculated</returns>
        public void MakeFrame(byte entity, ref byte[] QueryToSend)
        {
            _SendBuff = new byte[10];
            byte[] CRC = new byte[2];
            int len = 0;

            _SendBuff[len++] = 0xFA; //Slave ID
            _SendBuff[len++] = 0x0F; //Function Code
            _SendBuff[len++] = 0x03; //Addr1           
            _SendBuff[len++] = 0xE8; //Addr1  
            _SendBuff[len++] = 0x00; //
            _SendBuff[len++] = 0x07; //
            _SendBuff[len++] = 0x01; //


            if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ1)            
                _SendBuff[len++] = 0x21;                           
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ2)            
                _SendBuff[len++] = 0x01;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ3)            
                _SendBuff[len++] = 0x22;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ4)            
                _SendBuff[len++] = 0x02;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ5)            
                _SendBuff[len++] = 0x24;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ6)            
                _SendBuff[len++] = 0x04;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ7)            
                _SendBuff[len++] = 0x28;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ8)            
                _SendBuff[len++] = 0x08;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ9)            
                _SendBuff[len++] = 0x30;            
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ10)            
                _SendBuff[len++] = 0x10;
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ11)
                _SendBuff[len++] = 0x00;
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ12)
                _SendBuff[len++] = 0x60;
            else if (entity == (byte)PLC_OutputOnOff.PLC_ON_SQ13)
                _SendBuff[len++] = 0x40;

            CalculateCRC(ref CRC, _SendBuff);
            _SendBuff[len++] = CRC[0];
            _SendBuff[len++] = CRC[1];
            QueryToSend = _SendBuff;
        }

        public void MakeFrame(ref byte[] QueryToSend , byte entity)
        {
            switch (entity)
            {                

                case (byte)PLC_OutputOnOff.ReadPLCAnalogVoltage:
                    // _SendBuff = new byte[] { 0XFA, 0X04, 0X00, 0X42, 0X00, 0X01, 0X44, 0X56 };
                    _SendBuff = new byte[8];
                    byte[] CRC = new byte[2];
                    int len = 0;
                    _SendBuff[len++] = 0xFA; //Slave ID
                    _SendBuff[len++] = 0x04; //Function Code
                    _SendBuff[len++] = 0x00; //Addr1
                    _SendBuff[len++] = 0x42; //Addr1
                    _SendBuff[len++] = 0x00; //
                    _SendBuff[len++] = 0x04; //
                    CalculateCRC(ref CRC, _SendBuff);
                    _SendBuff[len++] = CRC[0];
                    _SendBuff[len++] = CRC[1];
                    QueryToSend = _SendBuff;
                    break;

            }
            
        }
    }
}
