﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace GIC_Timer_Programming_and_Calibration.model
{    
    
    public class Micon175PotDetail
    {
        public int PotNumber { get; set; }
        public string PotName { get; set; }
        public int NoOfPosition { get; set; }
        public string DiffBetTwoPosition { get; set; }
        public bool MiddleMarkCal { get; set; }
        public string HexLocation { get; set; }
        public string PotType { get; set; }
        public string Range { get; set; }
        public string RangeConstants { get; set; }
        public string PotLables { get; set; }
        public bool CalibApplicable { get; set; }
    }

    public class Micon175PotItems
    {
        public ObservableCollection<double> readValues { get; set; }
        public ObservableCollection<string> rangeValues { get; set; }
    }

    public class PotValues
    {
        public double ReadValue { get; set; }
        public string RangeValue { get; set; }
        public string Status { get; set; }
    }
    public class CatIDList
    {
        public int DeviceId { get; set; }       
        public string DeviceName { get; set; }
        public string MotFilePath { get; set; }
        public string FirmwareVersion { get; set; }
        public string Description { get; set; }
        public string DeviceIdHexLocation { get; set; } 
        public string DeviceSupplyforCalList { get; set; } 
        public string DeviceSupplyforCal { get; set; }
        public string SupplyType { get; set; }
        public string SupplyTypeList { get; set; }
        public bool IsFixedTiming { get; set; }      
        public string FixedTiming { get; set; }      
        public bool IsFixedRange { get; set; }       
        public int MentionNumber { get; set; }       
        public bool IsFixedMode { get; set; }      
        public int MentionMode { get; set; }     
        public bool HexEdition { get; set; }
        public bool RunTime_TimingChange { get; set; }       
        public bool RunTime_RangeChange { get; set; }        
        public bool RunTime_ModeChange { get; set; }      
        public string TimingChangeData { get; set; }       
        public string RangeChangeData { get; set; }          
        public string ModeChangeData { get; set; }       
        public bool HardwareCheck { get; set; }
        public string VCCRange { get; set; }
        public bool VoltageCalibration { get; set; }
        public string VoltageRange { get; set; }
        public string RFPVersion { get; set; }
        public string ControllerTypeList { get; set; }
        public string ControllerType { get; set; }
        public string RelayVoltageList { get; set; }
        public string RelayVoltage { get; set; }       
        public bool PWMEnable { get; set; }
        public bool RangeConstOnOffMode { get; set; }
        public int RelayNumber { get; set; }
        public int Switchdata { get; set; }
        public bool RangePotRangeValidation { get; set; }
        public bool TimingPotRangeValidation { get; set; }
        public bool ModePotRangeValidation { get; set; }
        public string RwsFilePath { get; set; }
        public string RpjFilePath { get; set; }
        public string ImgPath { get; set; }
        public bool IsZCDEnable { get; set; }
        public bool IsSwitchPresent { get; set; }
        public string[] NodeVoltagesRange { get; set; }
        public IList<Micon175PotDetail> Micon175_PotDetail { get; set; }
    }

    public class Micon175ConfigData
    {
        public string DeviceType { get; set; }
        public IList<CatIDList> CatIDList { get; set; }
    }

    public class Micon175ConfigDataList
    {
        public IList<Micon175ConfigData> Micon175_ConfigData { get; set; }
    }
}
