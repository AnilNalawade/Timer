﻿using System.Collections.ObjectModel;

namespace GIC_Timer_Programming_and_Calibration.model
{
    public class PotDetail
    {
        public int PotNumber { get; set; }
        public int NoOfPosition { get; set; }
        public int NoPosToCal { get; set; }
        public string Range { get; set; }
    }
    
    public class PotItems
    {
        public ObservableCollection<double> readValues { get; set; }
        public ObservableCollection<string> rangeValues { get; set; }
    }     

    public class CatList
    {
        public string DeviceName { get; set; }
        public string MotFilePath { get; set; }
        public int DeviceId { get; set; }
        public int NoOfSwitches { get; set; }
        public bool PWM_Supported { get; set; }
        public bool Switch_Supported { get; set; }
        public ObservableCollection<PotDetail> PotDetails { get; set; }
    }

    public class Micon225ConfigData
    {
        public string DeviceType { get; set; }
        public ObservableCollection<CatList> CatList { get; set; }
    }

    public class Micon225ConfigDataList
    {
        public ObservableCollection<Micon225ConfigData> Micon225ConfigData { get; set; }
    }

}





