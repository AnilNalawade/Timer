﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIC_Timer_Programming_and_Calibration.model
{
    public class clsPotEdit : INotifyPropertyChanged
    {

        private bool edit = false;

        private string _PotName;

        public string PotName
        {
            get { return _PotName; }
            set {
                _PotName = value;
                if (_PotName == "Range1" || _PotName == "Range2")
                {
                    IsModepot = true;
                    IsRangepot = true;
                    ColumnName = "Range Constants";
                }
                else if (_PotName == "Timing1" || _PotName == "Timing2")
                {
                    CalibApplicable = true;
                    IsRangepot = false;
                    IsModepot = true;
                    ColumnName = "Time Constants";
                }
                else
                {
                    IsRangepot = false;
                    IsModepot = false;
                }
                    
                OnPropertyChanged("PotName");
            }
        }
        
        private string _ColumnName = "Constants";

        public string ColumnName
        {
            get { return _ColumnName; }
            set { _ColumnName = value; OnPropertyChanged("ColumnName"); }
        }

        private bool _IsModepot = false;

        public bool IsModepot
        {
            get { return _IsModepot; }
            set { _IsModepot = value; OnPropertyChanged("IsModepot"); }
        }

        private int _PotNumber;

        public int PotNumber
        {
            get { return _PotNumber; }
            set { _PotNumber = value; OnPropertyChanged("PotNumber"); }
        }

        private int _NoOfPos;

        public int NoOfPos
        {
            get { return _NoOfPos; }
            set
            {
                _NoOfPos = value;
                OnPropertyChanged("NoOfPos");
                if(value < 16 && value > 0)
                {
                    if (edit)
                    {
                        potParams.Clear();
                        for (int counter = 0; counter < NoOfPos; counter++)
                        {
                            if (PotName == "Timing1" || PotName == "Timing2")
                            {
                                potParams.Add(new PotParams()
                                {
                                    PositionNo = counter,
                                    Range = "0-0",
                                    RangeConstant = ((counter + 1) * 20).ToString(),
                                    Label = "xx"
                                });
                            }
                            else
                            {
                                potParams.Add(new PotParams()
                                {
                                    PositionNo = counter,
                                    Range = "0-0",
                                    RangeConstant = "0",
                                    Label = "xx"
                                });
                            }
                            
                        }
                        for (int counter = 0; counter < NoOfPos - 1; counter++)
                        {
                            potParams[counter].Difference = "0";
                        }
                    }
                }
                else if(value > 15)
                {
                    NoOfPos = 15;
                }
                else
                {
                    NoOfPos = 1;
                }
                
            }
        }

        private ObservableCollection<PotParams> _potParams = new ObservableCollection<PotParams>();

        public ObservableCollection<PotParams> potParams
        {
            get { return _potParams; }
            set { _potParams = value; OnPropertyChanged("potParams"); }
        }

        private string _RangeString;

        public string RangeString
        {
            get { return _RangeString; }
            set { _RangeString = value; OnPropertyChanged("RangeString"); }
        }

        private string _RangeConstString;

        public string RangeConstString
        {
            get { return _RangeConstString; }
            set { _RangeConstString = value; OnPropertyChanged("RangeConstString"); }
        }


        private string _LabelString;

        public string LabelString
        {
            get { return _LabelString; }
            set { _LabelString = value; OnPropertyChanged("LabelString"); }
        }

        private string _DifferenceString;

        public string DifferenceString
        {
            get { return _DifferenceString; }
            set { _DifferenceString = value; OnPropertyChanged("DifferenceString"); }
        }

        private bool _CalibApplicable;

        public bool CalibApplicable
        {
            get { return _CalibApplicable; }
            set { _CalibApplicable = value; OnPropertyChanged("CalibApplicable"); }
        }

        private bool _IsRangepot;

        public bool IsRangepot
        {
            get { return _IsRangepot; }
            set { _IsRangepot = value; OnPropertyChanged("IsRangepot"); }
        }


        private bool _MiddleMark;

        public bool MiddleMark
        {
            get { return _MiddleMark; }
            set { _MiddleMark = value; OnPropertyChanged("MiddleMark"); }
        }

        private string _HexLocation;

        public string HexLocation
        {
            get { return _HexLocation; }
            set { _HexLocation = value; OnPropertyChanged("HexLocation"); }
        }

        private string _PotType;

        public string PotType
        {
            get { return _PotType; }
            set { _PotType = value; OnPropertyChanged("PotType"); }
        }
        /// <summary>
        /// Find the pot for edit or delete
        /// if user clicked edit, function parse the data of particular pot for edit.
        /// if user clicked delete,function parse the data of particular pot for delete. 
        /// </summary>
        /// <param name="pot"></param>
        public void ParsePotDetails(Micon175PotDetail pot)
        {
            PotName = pot.PotName;
            PotNumber = pot.PotNumber;
            PotType = pot.PotType;
            RangeString = pot.Range;
            RangeConstString = pot.RangeConstants;
            DifferenceString = pot.DiffBetTwoPosition;
            LabelString = pot.PotLables;
            HexLocation = pot.HexLocation;
            MiddleMark = pot.MiddleMarkCal;
            CalibApplicable = pot.CalibApplicable;
            NoOfPos = pot.NoOfPosition;

            if ((RangeString != null && RangeString != "") &&
                (RangeConstString != null && RangeConstString != "") &&
                 (LabelString != null && LabelString != "") &&
                 (DifferenceString != null && DifferenceString != ""))
            {
                var Rangearray = RangeString.Split(',');
                var RangeConstArray = RangeConstString.Split(',');
                var Labelarray = LabelString.Split(',');
                var Differencearray = DifferenceString.Split(',');

                for (int counter = 0; counter < NoOfPos; counter++)
                {
                    potParams.Add(new PotParams()
                    {
                        PositionNo = counter,
                        Label = Labelarray[counter],
                        Range = Rangearray[counter],
                        RangeConstant = RangeConstArray[counter]
                    });
                }

                for (int counter = 0; counter < NoOfPos - 1; counter++)
                {
                    potParams[counter].Difference = Differencearray[counter];
                }                
            }
            edit = true;


        }
        /// <summary>
        /// Save all edited pot details 
        /// Also added validation
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        public Micon175PotDetail SavePotDetails(ref int status)
        {
            try
            {
                Micon175PotDetail pot = new Micon175PotDetail()
                {
                    PotName = PotName,
                    PotNumber = PotNumber,
                    PotType = PotType,
                    HexLocation = HexLocation,
                    MiddleMarkCal = MiddleMark,
                    CalibApplicable = CalibApplicable,
                    NoOfPosition = NoOfPos
                };

                int Timeconstlimit = 240;
                DifferenceString = "";
                RangeString = "";
                RangeConstString = "";
                LabelString = "";
                foreach (var item in potParams)
                {
                    var Rangesvalues = item.Range.Split('-').Select(Int32.Parse).ToList();

                    for (int range = 0; range < Rangesvalues.Count; range++)
                    {
                        if (!IsDigitsOnly(Rangesvalues[range].ToString()))
                        {
                            status = Convert.ToInt32(EditPot.MinMaxRangeNumeric);
                            return null;
                        }                           
                    }                   
                                       
                    if (Rangesvalues[0] > Rangesvalues[1])
                    {
                        status = Convert.ToInt32(EditPot.minmaxrange);
                        return null;
                    }

                    RangeString += item.Range.ToString() + ',';

                    if (!IsDigitsOnly(item.RangeConstant))
                    {
                        status = Convert.ToInt32(EditPot.constNumeric);
                        return null;
                    }                        

                    if (PotName == "Timing1")
                    {
                        if (Convert.ToInt32(item.RangeConstant) > Timeconstlimit)
                        {
                            status = Convert.ToInt32(EditPot.timingExceeded);
                            return null;
                        }
                    }
                    
                    RangeConstString += item.RangeConstant.ToString() + ',';
                    LabelString += item.Label.ToString() + ',';
                }

                for (int counter = 0; counter < NoOfPos - 1; counter++)
                {
                    if (!IsDigitsOnly(potParams[counter].Difference))
                    {
                        status = Convert.ToInt32(EditPot.Differencenumeric);
                        return null;
                    }
                    DifferenceString += potParams[counter].Difference.ToString() + ',';
                }

                if (pot.NoOfPosition > 0)
                {
                    if (DifferenceString.Length > 0)
                        pot.DiffBetTwoPosition = DifferenceString.Remove(DifferenceString.Length - 1, 1);
                    pot.Range = RangeString.Remove(RangeString.Length - 1, 1);
                    pot.RangeConstants = RangeConstString.Remove(RangeConstString.Length - 1, 1);
                    pot.PotLables = LabelString.Remove(LabelString.Length - 1, 1);
                }

                return pot;
            }
            catch (Exception ex)
            {
                status = Convert.ToInt32(EditPot.MinMaxRangeNumeric);
                return null;
            }
        }
        /// <summary>
        ///Function Check entered string is numeric or not 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }

            return true;
        }
        /// <summary>
        /// if user clicked delete,function used to remove pot details. 
        /// </summary>
        /// <returns></returns>
        public Micon175PotDetail RemovePotDetails()
        {
            Micon175PotDetail pot = new Micon175PotDetail()
            {
                PotName = PotName,
                PotNumber = PotNumber,
                PotType = PotType,
                HexLocation = HexLocation,
                MiddleMarkCal = MiddleMark,
                CalibApplicable = CalibApplicable,
                NoOfPosition = NoOfPos
            };
            
            return pot;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    public class PotParams : INotifyPropertyChanged
    {
        private int _PositionNo;

        public int PositionNo
        {
            get { return _PositionNo; }
            set { _PositionNo = value; OnPropertyChanged("PositionNo"); }
        }

        private string _Label;

        public string Label
        {
            get { return _Label; }
            set { _Label = value; OnPropertyChanged("Label"); }
        }

        private string _Range;

        public string Range
        {
            get { return _Range; }
            set { _Range = value; OnPropertyChanged("Range"); }
        }

        private string _RangeConstant;

        public string RangeConstant
        {
            get { return _RangeConstant; }
            set
            {
                _RangeConstant = value;
                           

                OnPropertyChanged("RangeConstant");
            }
        }

        private string _Difference;

        public string Difference
        {
            get { return _Difference; }
            set { _Difference = value; OnPropertyChanged("Difference"); }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
