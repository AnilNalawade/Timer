﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using SQLite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GIC_Timer_Programming_and_Calibration.model
{
    [Table("users")]
    public class clsUserModel 
    {
        [PrimaryKey, NotNull, AutoIncrement]
        public int UserId { get; set; }

        [MaxLength(100), NotNull]
        public string UserName { get; set; }

        [MaxLength(50), NotNull]
        public string Password { get; set; }

        [NotNull]
        public bool IsAdmin { get; set; }

        [NotNull]
        public DateTime LoginTime { get; set; }
            
        public DateTime LastLogin { get; set; }       
       /// <summary>
       /// Validate user while Login
       /// Check entered username and password with username and password in database
       /// Return status that OK or not
       /// </summary>
       /// <param name="userName"></param>
       /// <param name="password"></param>
       /// <returns></returns>
        public static clsGlobalVariables.UserStatus validateUser(string userName, string password)
        {
            try
            {
                if (clsGlobalVariables.DatabasePath != "")
                {
                    string dabasePath = clsGlobalVariables.DatabasePath;
                    using (SQLiteConnection conn = new SQLiteConnection(dabasePath))
                    {
                        conn.CreateTable<clsUserModel>();
                        var user = conn.Table<clsUserModel>().ToList().Where(u => u.UserName == userName && u.Password == password).ToList();
                        if (user.Count > 0)
                        {
                            clsGlobalVariables.LoggedInUser = user[0].UserName;
                            clsGlobalVariables.LoggedInUserId = user[0].UserId;
                            clsGlobalVariables.IsLoggedInUserAdmin = user[0].IsAdmin;                            
                            return clsGlobalVariables.UserStatus.Valid;
                        }
                        else
                        {
                            clsGlobalVariables.LoggedInUser = "";
                            clsGlobalVariables.LoggedInUserId = 0;
                            clsGlobalVariables.IsLoggedInUserAdmin = false;
                            return clsGlobalVariables.UserStatus.Invalid;
                        }
                    }
                }
                else
                {
                    clsGlobalVariables.LoggedInUser = "";
                    clsGlobalVariables.LoggedInUserId = 0;
                    clsGlobalVariables.IsLoggedInUserAdmin = false;
                    return clsGlobalVariables.UserStatus.DatabaseConectionFailed;
                }
            }
            catch (Exception)
            {
                clsGlobalVariables.LoggedInUser = "";
                clsGlobalVariables.LoggedInUserId = 0;
                clsGlobalVariables.IsLoggedInUserAdmin = false;
                return clsGlobalVariables.UserStatus.ExceptionHandeled;
            }
        }

        /// <summary>
        /// Add username and Password to the database
        /// with the class clsUserModel all properties save into database
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static clsGlobalVariables.UserStatus addUser(clsUserModel user)
        {
            try
            {
                if (clsGlobalVariables.DatabasePath != "")
                {
                    string dabasePath = clsGlobalVariables.DatabasePath;
                    using (SQLiteConnection conn = new SQLiteConnection(dabasePath))
                    {
                        conn.CreateTable<clsUserModel>();
                        int rows = conn.Insert(user);

                        if(rows > 0)
                        {
                            return clsGlobalVariables.UserStatus.UserAdded;
                        }
                        else
                        {
                            return clsGlobalVariables.UserStatus.UserAddFailed;
                        }
                    }
                }
                else
                {
                    return clsGlobalVariables.UserStatus.DatabaseConectionFailed;
                }
            }
            catch (Exception)
            {
                return clsGlobalVariables.UserStatus.ExceptionHandeled;
            }
        }

        /// <summary>
        /// Edit the users details, username or password
        /// First select which users details has to change
        /// Return Edited or not
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static clsGlobalVariables.UserStatus editUser(clsUserModel user)
        {
            try
            {
                if (clsGlobalVariables.DatabasePath != "")
                {
                    string dabasePath = clsGlobalVariables.DatabasePath;
                    using (SQLiteConnection conn = new SQLiteConnection(dabasePath))
                    {
                        conn.CreateTable<clsUserModel>();
                        var res = conn.Table<clsUserModel>().ToList().Where(u => u.UserId == user.UserId).ToList();
                        if (res.Count > 0)
                        {
                            var response = conn.Update(user);
                            if(response > 0)
                            {
                                return clsGlobalVariables.UserStatus.UserEdited;
                            }
                            else
                            {
                                return clsGlobalVariables.UserStatus.UserEditFailed;
                            }
                        }
                        else
                        {
                            return clsGlobalVariables.UserStatus.NoRecordFound;
                        }
                    }
                }
                else
                {
                    return clsGlobalVariables.UserStatus.DatabaseConectionFailed;
                }
            }
            catch (Exception)
            {
                return clsGlobalVariables.UserStatus.ExceptionHandeled;
            }
        }
        /// <summary>
        /// Delete the username by pass user as a parameter
        /// Select which user has to delete
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static clsGlobalVariables.UserStatus deleteUser(clsUserModel user)
        {
            try
            {
                if (clsGlobalVariables.DatabasePath != "")
                {
                    string dabasePath = clsGlobalVariables.DatabasePath;
                    using (SQLiteConnection conn = new SQLiteConnection(dabasePath))
                    {
                        conn.CreateTable<clsUserModel>();
                        var res = conn.Table<clsUserModel>().ToList().Where(u => u.UserId == user.UserId).ToList();
                        if (res.Count > 0)
                        {
                            if(user.UserName == clsGlobalVariables.LoggedInUser)
                            {
                                return clsGlobalVariables.UserStatus.UserIsLoggedIn;
                            }
                            var response = conn.Delete(user);
                            if (response > 0)
                            {
                                return clsGlobalVariables.UserStatus.UserDeleted;
                            }
                            else
                            {
                                return clsGlobalVariables.UserStatus.UserDeleteFailed;
                            }
                        }
                        else
                        {
                            return clsGlobalVariables.UserStatus.NoRecordFound;
                        }
                    }
                }
                else
                {
                    return clsGlobalVariables.UserStatus.DatabaseConectionFailed;
                }
            }
            catch (Exception)
            {
                return clsGlobalVariables.UserStatus.ExceptionHandeled;
            }            
        }
        /// <summary>
        /// Get all users List for selection to update
        /// And update it into database
        /// </summary>
        /// <returns></returns>
        public static ObservableCollection<string> getUsersList()
        {
            try
            {                
                if (clsGlobalVariables.DatabasePath != "")
                {
                    ObservableCollection<string> UsersList = new ObservableCollection<string>();

                    string dabasePath = clsGlobalVariables.DatabasePath;
                    using (SQLiteConnection conn = new SQLiteConnection(dabasePath))
                    {
                        conn.CreateTable<clsUserModel>();
                        var res = conn.Query<clsUserModel>("SELECT UserName FROM users");
                        if(res.Count > 0)
                        {
                            foreach (var item in res)
                            {
                                UsersList.Add(item.UserName);
                            }                            
                        }            
                    }
                    return UsersList;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        /// <summary>
        /// Get user which is selected for the edtion or deletion
        /// And update it into database
        /// </summary>
        /// <returns></returns>
        public static clsUserModel getUser(string userName)
        {
            try
            {
                if (clsGlobalVariables.DatabasePath != "")
                {
                    ObservableCollection<string> UsersList = new ObservableCollection<string>();

                    string dabasePath = clsGlobalVariables.DatabasePath;
                    using (SQLiteConnection conn = new SQLiteConnection(dabasePath))
                    {
                        conn.CreateTable<clsUserModel>();
                        var res = conn.Table<clsUserModel>().ToList().Where(u => u.UserName == userName).ToList();
                        if(res.Count > 0)
                        {
                            return (clsUserModel)res[0];
                        }
                    }
                    return new clsUserModel();
                }
                else
                {
                    return new clsUserModel();
                }
            }
            catch (Exception)
            {

                return new clsUserModel();
            }
        }
    }
}
