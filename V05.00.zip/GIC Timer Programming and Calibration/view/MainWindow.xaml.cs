﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace GIC_Timer_Programming_and_Calibration.view
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MainWindowVM vm = null;
        public MainWindow()
        {
            InitializeComponent();
            vm = (MainWindowVM)DataContext;
            clsGlobalVariables.MainWindowVM = vm;
            title.Text = "GIC Timer Programming and Calibration Software - " + "V" + Assembly.GetExecutingAssembly().GetName().Version.Major.ToString("00") + "." + Assembly.GetExecutingAssembly().GetName().Version.Minor.ToString("00") + "";
            this.Width = System.Windows.SystemParameters.WorkArea.Width;
            this.Height = System.Windows.SystemParameters.WorkArea.Height;
            this.Left = 0;
            this.Top = 0;
            this.WindowState = WindowState.Normal;
            clsGlobalVariables.MainWindowVM = (MainWindowVM)DataContext;
            clsGlobalVariables.EnableBeep = Properties.Settings.Default.beep;
            chkBeep.IsChecked = clsGlobalVariables.EnableBeep;
            chkBeep.IsEnabled = false;
            chkBeep.Visibility = Visibility.Collapsed;
            if (Properties.Settings.Default.beep)            
                beeptxt.Text = "Disable Beep Sound";            
            else            
                beeptxt.Text = "Enable Beep Sound";
            
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            chkBeep.IsChecked = !chkBeep.IsChecked;
            if(chkBeep.IsChecked == true)            
                beeptxt.Text = "Disable Beep Sound";            
            else            
                beeptxt.Text = "Enable Beep Sound";
            
            clsGlobalVariables.EnableBeep = (bool)chkBeep.IsChecked;
            Properties.Settings.Default.beep = (bool)chkBeep.IsChecked;
            Properties.Settings.Default.Save();
        }

        private void chkBeep_Checked(object sender, RoutedEventArgs e)
        {
            if (chkBeep.IsChecked == true)
            {               
                System.Console.Beep(2000, 100);
                
            }            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if(vm.ProductSelectionVis == true && vm.IsProductSelected == true && vm.DeviceTypeList.Count == 0)
            {
                if(e.Key == Key.Escape)
                {
                    this.Close();
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Minimized)
            {
                this.Width = System.Windows.SystemParameters.WorkArea.Width;
                this.Height = System.Windows.SystemParameters.WorkArea.Height;
                this.Left = 0;
                this.Top = 0;
                this.WindowState = WindowState.Normal;
            }
            else
            {
                this.Width = System.Windows.SystemParameters.WorkArea.Width;
                this.Height = System.Windows.SystemParameters.WorkArea.Height;
                this.Left = 0;
                this.Top = 0;
                this.WindowState = WindowState.Normal;
                this.WindowState = WindowState.Minimized;
            }
                
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            this.Width = System.Windows.SystemParameters.WorkArea.Width;
            this.Height = System.Windows.SystemParameters.WorkArea.Height;
            this.Left = 0;
            this.Top = 0;
            this.WindowState = WindowState.Normal;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            if (chkLog.IsChecked == true)
            {
                chkLog.IsChecked = false;
            }                
            else
            {
                chkLog.IsChecked = true;
            }                
        }

        private void chkLog_Checked(object sender, RoutedEventArgs e)
        {            
            chkLog.IsChecked = true;            
        }
        /// <summary>
        /// Short cut added to start the programming and calibration.
        /// p key is a short cut key for programming.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (vm.IsCatIdSelected == true)
            {
                if (clsGlobalVariables.MainWindowVM.IsProcessOn == false)
                {
                    if (vm.dialog != true)
                    {
                        if (e.Key == Key.M)
                        {
                            vm.ProgramBtnClkAsync(null);
                            this.Focus();
                            this.Activate();
                        }
                    }
                }
            }
        }

        private void gif_MediaEnded(object sender, RoutedEventArgs e)
        {
            gif.Position = new TimeSpan(0, 0, 1);
            gif.Play();
        }

        private void errorgif_MediaEnded(object sender, RoutedEventArgs e)
        {
            errorgif.Position = new TimeSpan(0, 0, 1);
            errorgif.Play();
        }

        private void passgif_MediaEnded(object sender, RoutedEventArgs e)
        {
            passgif.Position = new TimeSpan(0, 0, 1);
            passgif.Play();
        }
    }
}
