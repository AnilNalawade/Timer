﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.model;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIC_Timer_Programming_and_Calibration
{
    /// <summary>
    /// Interaction logic for One_M_CatalogueConfig.xaml
    /// </summary>
    public partial class Micon175_CatalogueConfig : Window
    {
        Micon175_CatalogueConfigVM vm = new Micon175_CatalogueConfigVM();
        public Micon175_CatalogueConfig()
        {
            InitializeComponent();
            vm = (Micon175_CatalogueConfigVM)DataContext;
            clsGlobalVariables.One_M_CatalogueConfigVM = vm;
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }
        //Close
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MainTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (MainTreeView.SelectedItem != null)
            {                
                if (MainTreeView.SelectedItem.GetType() == typeof(CatIDList))
                {
                    CatIDList _catList = new CatIDList();
                    _catList = (CatIDList)MainTreeView.SelectedItem;
                    clsGlobalVariables.SelectedDeviceNameOfTreeView = _catList.DeviceName;
                }
                vm.AssignDataToFields(MainTreeView.SelectedItem, false);
                vm.EditBtnVis = false;
            }
        }
        
    }
}
