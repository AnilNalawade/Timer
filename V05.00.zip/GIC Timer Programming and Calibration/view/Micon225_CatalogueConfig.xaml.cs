﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIC_Timer_Programming_and_Calibration.view
{
    /// <summary>
    /// Interaction logic for ConfigData.xaml
    /// </summary>
    public partial class ConfigDataTreeview : Window
    {
        // CatalogueConfigVM vm = clsGlobalVariables.CatalogueConfigVM;
        Micon225_CatalogueConfigVM vm = new Micon225_CatalogueConfigVM();
        public ConfigDataTreeview()
        {            
            InitializeComponent();
            vm = (Micon225_CatalogueConfigVM)DataContext;
            clsGlobalVariables.CatalogueConfigVM = vm;
        }

        private void MainTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {   
            if(MainTreeView.SelectedItem != null)
            {
                vm.AssignDataToFields(MainTreeView.SelectedItem, false);
            }            
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            //CatalogueConfigVM vm = (CatalogueConfigVM)DataContext;
            //if ((vm != null) && (vm.EditCatIdCmd.CanExecute(null)))
            //    vm.EditCatIdCmd.Execute(null);
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (vm.IsDialogOpen == false)
            {
                if (vm.IsSaveBtnVis == true || vm.IsSaveCatIdBtnVis == true || vm.IsSaveDevicetypeBtnVis == true)
                {
                    vm.Msg = "Do you want to close Catalog Config window?\n\n All unsaved data will be discarded.";
                    vm.MsgVis = true;
                    vm.ErrorMsgVis = false;
                    vm.EventSender = "escBtn";
                    vm.currentWindow = this;
                    vm.IsDialogOpen = true;                    
                    Console.Beep(1000, 100);
                }
                else
                {
                    this.Close();
                }

            }
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Escape)
            {
                if(vm.IsDialogOpen == false)
                {
                    if(vm.IsSaveBtnVis == true || vm.IsSaveCatIdBtnVis == true || vm.IsSaveDevicetypeBtnVis == true)
                    {
                        vm.Msg = "Do you want to close Catalog Config window?\n All unsaved data will be discarded.";
                        vm.MsgVis = true;
                        vm.ErrorMsgVis = false;
                        vm.EventSender = "escBtn";
                        vm.currentWindow = this;
                        vm.IsDialogOpen = true;
                        Console.Beep(1000,100);
                    }
                    else
                    {
                        this.Close();
                    }
                    
                }
            }
        }
    }
}
