﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIC_Timer_Programming_and_Calibration.view
{
    /// <summary>
    /// Interaction logic for RelayCalibrationRetry.xaml
    /// </summary>
    public partial class RelayCalibrationRetry : Window
    {
        RelayCalibrationRetryVM vm = null;
        public RelayCalibrationRetry()
        {
            InitializeComponent();
            vm = (RelayCalibrationRetryVM)DataContext;
            clsGlobalVariables.RelayCalibrationRetryVM = vm;
        }

        private void errorgif_MediaEnded(object sender, RoutedEventArgs e)
        {
            errorgif.Position = new TimeSpan(0, 0, 1);
            errorgif.Play();
        }

        private void StopBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            clsGlobalVariables.MainWindowVM.UpdatedRelayCalibFailure();
        }

        private void RetryBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            clsGlobalVariables.MainWindowVM.StartRelayCalibration();     
        }
    }
}
