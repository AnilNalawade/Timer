﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIC_Timer_Programming_and_Calibration.view
{
    /// <summary>
    /// Interaction logic for ShowMessage.xaml
    /// </summary>
    public partial class ShowMessage : Window
    {
        MainWindowVM vm = new MainWindowVM();       
        public ShowMessage()
        {
            vm = clsGlobalVariables.MainWindowVM;            
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {           
            this.Close();
        }

        private void StackPanel_KeyUp(object sender, KeyEventArgs e)
        {          
            if (e.Key == Key.Z || e.Key == Key.A)
            {
                vm.btnRestart("Restart");
                this.Close();
            }
            else if (e.Key == Key.X || e.Key == Key.S)
            {               
                vm.btnRetry("Retry");
                this.Close();
                
            }
            else if (e.Key == Key.C || e.Key == Key.D)
            {                
                vm.btnOkCalibrationClicked("Ok");
                this.Close();                
               
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            clsGlobalVariables.Break = true;
            this.Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                //var ch = StringInfo.GetNextTextElement(ABC.Text, ABC.Text.Length-1);
                //if (!Char.IsDigit(Convert.ToChar(ch)))
                //{
                //    ABC.Text = ABC.Text.Remove(ABC.Text.Length - 1,1);
                //    return;
                //}
            }
            catch (Exception )
            {

            }
        }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
