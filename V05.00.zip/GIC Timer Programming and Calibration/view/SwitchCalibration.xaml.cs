﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.viewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GIC_Timer_Programming_and_Calibration.view
{
    /// <summary>
    /// Interaction logic for SwitchCalibrationWindow.xaml
    /// </summary>
    public partial class SwitchCalibration : Window
    {
        SwitchCalibrationVM vm = null;

        public string[] Switchmsg =  { "Please Turn On  1st switch and Press 'Ok' button",
                                       "Please Turn On 2nd switch and Press 'Ok' button",
                                       "Please Turn On 3rd switch and Press 'Ok' button",
                                       "Please Turn On 4th switch and Press 'Ok' button",
                                       "Please Turn On 5th switch and Press 'Ok' button",
                                       "Please Turn On 6th switch and Press 'Ok' button",
                                       "Please Turn OFF All switches and Press 'Ok' button"}; // 7 Msg 
        public SwitchCalibration()
        {
            InitializeComponent();
           
            SwitchBtn.Focus();

        }
        public SwitchCalibration(int switchcnt)
        {
            InitializeComponent();
          
            vm = (SwitchCalibrationVM)DataContext;
            clsGlobalVariables.SwitchCalibrationVM = vm;

            if (clsGlobalVariables.IsSwitchCalibFailed == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Switchmessage = "Switch is not working as per requirement, Please check and retry.";                     
            }

            switch (switchcnt)
            {
                case 0:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[6];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
                    break;

                case 1:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[switchcnt - 1];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
                    break;

                case 2:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[switchcnt - 1];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
                    break;

                case 3:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[switchcnt - 1];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
                    break;

                case 4:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[switchcnt - 1];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = false;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
                    break;

                case 5:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[switchcnt - 1];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
                    break;

                case 6:
                    if (clsGlobalVariables.IsSwitchCalibFailed == false)
                    {
                        clsGlobalVariables.SwitchCalibrationVM.Switchmessage = Switchmsg[switchcnt - 1];
                    }

                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = true;
                    clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = true;
                    break;


                default:
                    break;
            }           

            SwitchBtn.Focus();

        }

        private void SwitchBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
     
       //user can not changed switch psition on UI:

        private void ToggleButton1_Click(object sender, RoutedEventArgs e)
        { 
            if (clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = false;
            }
            else
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn1 = true;
            }
        }

        private void ToggleButton2_Click(object sender, RoutedEventArgs e)
        {
            if (clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = false;
            }
            else
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn2 = true;
            }
        }

        private void ToggleButton3_Click(object sender, RoutedEventArgs e)
        {
            if (clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = false;
            }
            else
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn3 = true;
            }
        }

        private void ToggleButton4_Click(object sender, RoutedEventArgs e)
        {
            if (clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = false;
            }
            else
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn4 = true;
            }
        }

        private void ToggleButton5_Click(object sender, RoutedEventArgs e)
        {
            if (clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = false;
            }
            else
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn5 = true;
            }
        }

        private void ToggleButton6_Click(object sender, RoutedEventArgs e)
        {
            if (clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 == true)
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = false;
            }
            else
            {
                clsGlobalVariables.SwitchCalibrationVM.Tglbtn6 = true;
            }
        }
    }
}
