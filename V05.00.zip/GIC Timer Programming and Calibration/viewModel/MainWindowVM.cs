﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.model;
using GIC_Timer_Programming_and_Calibration.view;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;

namespace GIC_Timer_Programming_and_Calibration.viewModel
{
    public class MainWindowVM : INotifyPropertyChanged
    {
        #region Lists
        public List<byte> Timing1ReadDatabytes = new List<byte>();
        public List<byte> Range1ReadDatabytes = new List<byte>();
        public List<byte> ModeReadDatabytes = new List<byte>();
        public List<byte> Timing2ReadDatabytes = new List<byte>();
        public List<byte> Range2ReadDatabytes = new List<byte>();
        public List<byte> Pot4ReadDatabytes = new List<byte>();
        #endregion

        #region variables
        public int SUCCESS = 0;
        public int FAILURE = -1;// ErrorCode => SUCCESS = 0 | FAILURE = -1
        public bool IsStartClicked = false;
        public bool PLCPortDetected = false;
        MyLogWriterDLL.LogWriter log = null;

        private clsUserModel _User = new clsUserModel();


        public clsUserModel User
        {
            get { return _User; }
            set { _User = value; OnPropertyChanged("User"); }
        }


        #endregion

        #region visiblity properties

        private bool _DisplayPathError;

        public bool DisplayPathError
        {
            get { return _DisplayPathError; }
            set { _DisplayPathError = value; OnPropertyChanged("DisplayPathError"); }
        }

        // SelectedIndex of combobox added for device Supply and device name related confirmation and Validation
        private int _SelectedDeviceNameIndex;

        public int SelectedDeviceNameIndex
        {
            get { return _SelectedDeviceNameIndex; }
            set
            {
                _SelectedDeviceNameIndex = value;
                OnPropertyChanged("SelectedDeviceNameIndex");
            }
        }

        //Device supply added on status bar
        private string _DeviceSupplyforCal;

        public string DeviceSupplyforCal
        {
            get { return _DeviceSupplyforCal; }
            set { _DeviceSupplyforCal = value; OnPropertyChanged("DeviceSupplyforCal"); }
        }


        private bool _EnableAutentication;

        public bool EnableAutentication
        {
            get { return _EnableAutentication; }
            set { _EnableAutentication = value; OnPropertyChanged("EnableAutentication"); }
        }


        private bool _IconMsgVis = true;

        public bool IconMsgVis
        {
            get { return _IconMsgVis; }
            set { _IconMsgVis = value; OnPropertyChanged("IconMsgVis"); }
        }

        private bool _IconErrorVis = false;

        public bool IconErrorVis
        {
            get { return _IconErrorVis; }
            set { _IconErrorVis = value; OnPropertyChanged("IconErrorVis"); }
        }

        private bool _IconQuestionVis;

        public bool IconQuestionVis
        {
            get { return _IconQuestionVis; }
            set { _IconQuestionVis = value; OnPropertyChanged("IconQuestionVis"); }
        }


        private bool _IsAdmin = false;

        public bool IsAdmin
        {
            get { return _IsAdmin; }
            set { _IsAdmin = value; OnPropertyChanged("IsAdmin"); }
        }


        private bool _IsPotCardVisible = false;

        public bool IsPotCardVisible
        {
            get { return _IsPotCardVisible; }
            set { _IsPotCardVisible = value; OnPropertyChanged("IsPotCardVisible"); }
        }


        private bool _ProductSelectionVis = false;

        public bool ProductSelectionVis
        {
            get { return _ProductSelectionVis; }
            set { _ProductSelectionVis = value; OnPropertyChanged("ProductSelectionVis"); }
        }

        private bool _ComSelectionVis = false;

        public bool ComSelectionVis
        {
            get { return _ComSelectionVis; }
            set { _ComSelectionVis = value; OnPropertyChanged("ComSelectionVis"); }
        }

        private bool _MesssageVis = false;

        public bool MesssageVis
        {
            get { return _MesssageVis; }
            set { _MesssageVis = value; OnPropertyChanged("MesssageVis"); }
        }

        internal void btnOkCalibrationClicked(string v)
        {
            clsGlobalVariables.IsOkclicked = true;
            clsGlobalVariables.IsRetryclicked = false;
        }

        private bool _IsProductSelected = false;

        public bool IsProductSelected
        {
            get { return _IsProductSelected; }
            set { _IsProductSelected = value; OnPropertyChanged("IsProductSelected"); }
        }

        private int _windowsize;

        public int windowsize
        {
            get { return _windowsize; }
            set { _windowsize = value; OnPropertyChanged("windowsize"); }
        }


        private bool _dialogOpen = true;

        public bool dialog
        {
            get { return _dialogOpen; }
            set { _dialogOpen = value; OnPropertyChanged("dialog"); IsProductSelected = true; }
        }



        private bool _DeviceTypeError = false;

        public bool DeviceTypeError
        {
            get { return _DeviceTypeError; }
            set { _DeviceTypeError = value; OnPropertyChanged("DeviceTypeError"); }
        }

        private bool _ComPortError = false;

        public bool ComPortError
        {
            get { return _ComPortError; }
            set { _ComPortError = value; OnPropertyChanged("ComPortError"); }
        }

        private bool _BaudRateError = false;

        public bool BaudRateError
        {
            get { return _BaudRateError; }
            set { _BaudRateError = value; OnPropertyChanged("BaudRateError"); }
        }

        private bool _RestartBtnVis = false;

        public bool RestartBtnVis
        {
            get { return _RestartBtnVis; }
            set { _RestartBtnVis = value; OnPropertyChanged("RestartBtnVis"); }
        }

        private bool _RetryBtnVis = false;

        public bool RetryBtnVis
        {
            get { return _RetryBtnVis; }
            set { _RetryBtnVis = value; OnPropertyChanged("RetryBtnVis"); }
        }

        private bool _OkBtnVis = false;

        public bool OkbtnVis
        {
            get { return _OkBtnVis; }
            set { _OkBtnVis = value; OnPropertyChanged("OkbtnVis"); }
        }

        private bool _YesNoBtnVis = false;

        public bool YesNoBtnVis
        {
            get { return _YesNoBtnVis; }
            set { _YesNoBtnVis = value; OnPropertyChanged("YesNoBtnVis"); }
        }

        private bool _CancelBtnVis = true;

        public bool CancelBtnVis
        {
            get { return _CancelBtnVis; }
            set { _CancelBtnVis = value; OnPropertyChanged("CancelBtnVis"); }
        }

        private bool _LoginBtnVis = true;

        public bool LoginBtnVis
        {
            get { return _LoginBtnVis; }
            set { _LoginBtnVis = value; OnPropertyChanged("LoginBtnVis"); }
        }


        private bool _LoginVis = true;

        public bool LoginVis
        {
            get { return _LoginVis; }
            set { _LoginVis = value; OnPropertyChanged("LoginVis"); }
        }

        private bool _UserNameError = false;

        public bool UserNameError
        {
            get { return _UserNameError; }
            set { _UserNameError = value; OnPropertyChanged("UserNameError"); }
        }

        private bool _PasswordError = false;

        public bool PasswordError
        {
            get { return _PasswordError; }
            set { _PasswordError = value; OnPropertyChanged("PasswordError"); }
        }


        private bool _IncorrectError = false;

        public bool IncorrectError
        {
            get { return _IncorrectError; }
            set { _IncorrectError = value; OnPropertyChanged("IncorrectError"); }
        }

        private bool _userTick = false;

        public bool userTick
        {
            get { return _userTick; }
            set { _userTick = value; OnPropertyChanged("userTick"); }
        }

        private bool _AdminUserTick = false;

        public bool AdminUserTick
        {
            get { return _AdminUserTick; }
            set { _AdminUserTick = value; OnPropertyChanged("AdminUserTick"); }
        }

        private bool _AddBtnVis;

        public bool AddBtnVis
        {
            get { return _AddBtnVis; }
            set { _AddBtnVis = value; OnPropertyChanged("AddBtnVis"); }
        }

        private bool _AddUserVis;

        public bool AddUserVis
        {
            get { return _AddUserVis; }
            set { _AddUserVis = value; OnPropertyChanged("AddUserVis"); }
        }

        private bool _SaveBtnVis = false;

        public bool SaveBtnVis
        {
            get { return _SaveBtnVis; }
            set { _SaveBtnVis = value; OnPropertyChanged("SaveBtnVis"); }
        }

        private bool _EditUserVis = false;

        public bool EditUserVis
        {
            get { return _EditUserVis; }
            set { _EditUserVis = value; OnPropertyChanged("EditUserVis"); }
        }

        private bool _DeleteBtnVis = false;

        public bool DeleteBtnVis
        {
            get { return _DeleteBtnVis; }
            set { _DeleteBtnVis = value; OnPropertyChanged("DeleteBtnVis"); }
        }

        private string _SelectedPLCComPort;

        public string SelectedPLCComPort
        {
            get { return _SelectedPLCComPort; }
            set { _SelectedPLCComPort = value; OnPropertyChanged("SelectedPLCComPort"); }
        }


        #endregion

        #region Normal properties

        private bool _ErrorStatus;

        public bool ErrorStatus
        {
            get { return _ErrorStatus; }
            set { _ErrorStatus = value; OnPropertyChanged("ErrorStatus"); }
        }

        private bool _SuccessStatus;

        public bool SuccessStatus
        {
            get { return _SuccessStatus; }
            set { _SuccessStatus = value; OnPropertyChanged("SuccessStatus"); }
        }


        private bool _IsCheckedEnableLog;

        public bool IsCheckedEnableLog
        {
            get { return _IsCheckedEnableLog; }
            set
            {
                _IsCheckedEnableLog = value;
                OnPropertyChanged("IsCheckedEnableLog");
            }
        }


        private string _Checkpath;

        public string Checkpath
        {
            get { return _Checkpath; }
            set { _Checkpath = value; OnPropertyChanged("Checkpath"); }
        }


        private string _LoggedInUser = clsGlobalVariables.LoggedInUser;

        public string LoggedInUser
        {
            get { return _LoggedInUser; }
            set { _LoggedInUser = value; OnPropertyChanged("LoggedInUser"); }
        }

        private string _FinalStatus;

        public string FinalStatus
        {
            get { return _FinalStatus; }
            set { _FinalStatus = value; OnPropertyChanged("FinalStatus"); }
        }

        private bool _PassStatus;

        public bool PassStatus
        {
            get { return _PassStatus; }
            set { _PassStatus = value; OnPropertyChanged("PassStatus"); }
        }

        private bool _IsProgEnable;

        public bool IsProgEnable
        {
            get { return _IsProgEnable; }
            set { _IsProgEnable = value; OnPropertyChanged("IsProgEnable"); }
        }


        private string _StopwatchTime;

        public string StopwatchTime
        {
            get { return _StopwatchTime; }
            set { _StopwatchTime = value; OnPropertyChanged("StopwatchTime"); }
        }


        private string _Descrition;

        public string Descrition
        {
            get { return _Descrition; }
            set { _Descrition = value; OnPropertyChanged("Descrition"); }
        }

        private string _FirmwareVersion;

        public string FirmwareVersion
        {
            get { return _FirmwareVersion; }
            set { _FirmwareVersion = value; OnPropertyChanged("FirmwareVersion"); }
        }


        private string _ColorChangeProperty;

        public string ColorChangeProperty
        {
            get
            {
                if (_ColorChangeProperty == null)
                    _ColorChangeProperty = "#ffffff";
                return _ColorChangeProperty;
            }
            set
            {
                _ColorChangeProperty = value;
                OnPropertyChanged("ColorChangeProperty");
            }
        }


        private string JsonFileName1M = "";
        private string JsonFileName225 = "";
        private string LogFilePath = "";

        private string HelpfilePath = "";

        private string _SelectedControllerType = clsGlobalVariables.SelectedControllerType;

        public string SelectedControllerType
        {
            get { return _SelectedControllerType; }
            set
            {
                _SelectedControllerType = value;
                OnPropertyChanged("SelectedControllerType");
            }
        }

        private bool _IsProcessOn = false;

        public bool IsProcessOn
        {
            get { return _IsProcessOn; }
            set { _IsProcessOn = value; OnPropertyChanged("IsProcessOn"); }
        }


        private bool _IsCatIdSelected = false;

        public bool IsCatIdSelected
        {
            get { return _IsCatIdSelected; }
            set { _IsCatIdSelected = value; OnPropertyChanged("IsCatIdSelected"); }
        }


        private bool _IsDone = false;

        public bool IsDone
        {
            get { return _IsDone; }
            set { _IsDone = value; OnPropertyChanged("IsDone"); }
        }

        private bool _IsFail = false;

        public bool IsFail
        {
            get { return _IsFail; }
            set { _IsFail = value; OnPropertyChanged("IsFail"); }
        }


        private bool _IsPrgVis;

        public bool IsPrgVis
        {
            get { return _IsPrgVis; }
            set { _IsPrgVis = value; OnPropertyChanged("IsPrgVis"); }
        }

        private string _Sender = "";

        public string Sender
        {
            get { return _Sender; }
            set { _Sender = value; OnPropertyChanged("Sender"); }
        }


        private bool _IsTimer225Checked;

        public bool IsTimer225Checked
        {
            get { return _IsTimer225Checked; }
            set
            {
                _IsTimer225Checked = value;
                if (value == true)
                {
                    DeviceNameList.Clear();
                    DeviceTypeList.Clear();

                    //Need to added afterward

                    if (value == true && Micon175_CatId.Count > 0)
                    {
                        DeviceNameList.Clear();
                        DeviceTypeList.Clear();

                        for (int j = 0; j < Micon175_CatId[0].Micon175_ConfigData.Count; j++)
                        {
                            DeviceTypeList.Add(Micon175_CatId[0].Micon175_ConfigData[j].DeviceType);
                        }

                    }

                }
                OnPropertyChanged("IsTimer225Checked");
            }
        }

        private bool _IsTimer1MStarDeltaChecked;

        public bool IsTimer1MStarDeltaChecked
        {
            get { return _IsTimer1MStarDeltaChecked; }
            set
            {
                _IsTimer1MStarDeltaChecked = value;
                if (value == true && Micon175_CatId.Count > 0)
                {
                    DeviceNameList.Clear();
                    DeviceTypeList.Clear();

                    for (int j = 0; j < Micon175_CatId[0].Micon175_ConfigData.Count; j++)
                    {
                        DeviceTypeList.Add(Micon175_CatId[0].Micon175_ConfigData[j].DeviceType);
                    }

                }
                OnPropertyChanged("IsTimer1MStarDeltaChecked");
            }
        }

        private string _Msg = "";

        public string Msg
        {
            get { return _Msg; }
            set { _Msg = value; OnPropertyChanged("Msg"); }
        }

        private string _SelectedTimerType;

        public string SelectedTimerType
        {
            get { return _SelectedTimerType; }
            set
            {
                _SelectedTimerType = value;
                OnPropertyChanged("SelectedTimerType");
                if (value.ToString() == "Micon175")
                {
                    refresDataFromMicon175_File();
                    IsTimer1MStarDeltaChecked = true;
                    IsTimer225Checked = false;
                }
                if (value.ToString() == "Micon225")
                {
                    refresDataFromMicon225_File();
                    IsTimer225Checked = true;
                    IsTimer1MStarDeltaChecked = false;
                }
            }
        }

        private string _SelectedDeviceType;

        public string SelectedDeviceType
        {
            get { return _SelectedDeviceType; }
            set
            {
                _SelectedDeviceType = value;
                if (value != null && value != "")
                {
                    CalibrationStatus = "";
                    DeviceTypeError = false;
                    clsGlobalVariables.SelectedDeviceType = value;
                    //PotCounter = 0;
                }
                IsPotCardVisible = false;
                //DeviceNameList.Clear();
                IsActivePot1 = false;
                IsActivePot2 = false;
                IsActivePot3 = false;
                IsActivePot4 = false;
                IsActivePot5 = false;

                OnPropertyChanged("SelectedDeviceType");
            }
        }

        private string _SelectedComPort = clsGlobalVariables.SelectedComPort;

        public string SelectedComPort
        {
            get { return _SelectedComPort; }
            set
            {
                _SelectedComPort = value;
                if (value != null && value != "")
                {
                    ComPortError = false;

                    if (PortList.Contains(value))
                    {
                        clsGlobalVariables.SelectedComPort = value;
                        Properties.Settings.Default.DUTComPort = value;
                        Properties.Settings.Default.Save();
                    }
                    else
                    {
                        clsGlobalVariables.SelectedComPort = "COM1";
                        Properties.Settings.Default.DUTComPort = value;
                        Properties.Settings.Default.Save();
                    }

                }
                OnPropertyChanged("SelectedComPort");
            }
        }

        private string _SelectedBaudRate = clsGlobalVariables.SelectedBaudRate;

        public string SelectedBaudRate
        {
            get { return _SelectedBaudRate; }
            set
            {
                _SelectedBaudRate = value;
                if (value != null && value != "")
                {
                    BaudRateError = false;
                    clsGlobalVariables.SelectedBaudRate = value;
                    Properties.Settings.Default.DUTBaudrate = value;
                    Properties.Settings.Default.Save();
                }
                OnPropertyChanged("SelectedBaudRate");
            }
        }

        private string _strImagefilepath;

        public string strImagefilepath
        {
            get { return _strImagefilepath; }
            set { _strImagefilepath = value; OnPropertyChanged("strImagefilepath"); }
        }


        private string _SelectedDeviceName = "";

        public string SelectedDeviceName
        {
            get { return _SelectedDeviceName; }
            set
            {
                CalibrationStatus = "";
                PassStatus = false;
                IsFail = false;
                FinalStatus = "";
                SuccessStatus = false;
                ErrorStatus = false;
                IsDone = false;
                _SelectedDeviceName = value;
                OnPropertyChanged("SelectedDeviceName");
                ClearPot();
                ClearPotDetails();
                PotitemsList.Clear();
                Micon175_PotitemsList.Clear();

                //Path to log data
                //If directory is not present at given path, create directory.
                if (!Directory.Exists(LogFilePath))
                {
                    Directory.CreateDirectory(LogFilePath);
                }
                FileNameRangeCalData = LogFilePath + "\\" + SelectedDeviceName + ".csv";

                if (value != null && value != "")
                {
                    clsGlobalVariables.SelectedDeviceName = value;
                    //PotCounter = 0;
                    IsPotCardVisible = true;
                    if (IsTimer225Checked)
                    {
                        AssignTimer225DatatoPotListUi();
                    }
                    else if (IsTimer1MStarDeltaChecked)
                    {
                        if (AssignTimer175DatatoPotListUi())
                            IsCatIdSelected = true;
                        else
                            IsCatIdSelected = false;
                    }
                }
                else
                {
                    DeviceSupplyforCal = "";
                    IsPotCardVisible = false;
                    IsCatIdSelected = false;
                    DisplayPathError = false;
                }

            }
        }

        private string _CalibrationStatus;

        public string CalibrationStatus
        {
            get { return _CalibrationStatus; }
            set { _CalibrationStatus = value; OnPropertyChanged("CalibrationStatus"); }
        }

        private string _StatusColorProperty;

        public string StatusColorProperty
        {
            get { return _StatusColorProperty; }
            set { _StatusColorProperty = value; OnPropertyChanged("StatusColorProperty"); }
        }

        private string _UserName = "";

        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; OnPropertyChanged("UserName"); }
        }

        private string _Password = "";

        public string Password
        {
            get { return _Password; }
            set { _Password = value; OnPropertyChanged("Password"); }
        }


        private bool _IsAdminChk = false;

        public bool IsAdminChk
        {
            get { return _IsAdminChk; }
            set { _IsAdminChk = value; OnPropertyChanged("IsAdminChk"); }
        }

        private string _SelectedUserName = "";

        public string SelectedUserName
        {
            get { return _SelectedUserName; }
            set
            {
                _SelectedUserName = value;
                if (value != null && value != "")
                {
                    User = clsUserModel.getUser(value);
                }
                OnPropertyChanged("SelectedUserName");
            }
        }
        #endregion

        #region Observable Collection Properties

        private ObservableCollection<string> _DeviceNameList;

        public ObservableCollection<string> DeviceNameList
        {
            get { return _DeviceNameList; }
            set { _DeviceNameList = value; OnPropertyChanged("DeviceNameList"); }
        }



        private ObservableCollection<PotItems> _PotitemsList = new ObservableCollection<PotItems>();

        public ObservableCollection<PotItems> PotitemsList
        {
            get { return _PotitemsList; }
            set { _PotitemsList = value; OnPropertyChanged("PotitemsList"); }
        }

        private ObservableCollection<Micon175PotItems> _Micon175_PotitemsList = new ObservableCollection<Micon175PotItems>();

        public ObservableCollection<Micon175PotItems> Micon175_PotitemsList
        {
            get { return _Micon175_PotitemsList; }
            set { _Micon175_PotitemsList = value; OnPropertyChanged("Micon175_PotitemsList"); }
        }

        private ObservableCollection<Micon175ConfigDataList> _Micon175_CatId;

        public ObservableCollection<Micon175ConfigDataList> Micon175_CatId
        {
            get { return _Micon175_CatId; }
            set { _Micon175_CatId = value; OnPropertyChanged("Micon175_CatId"); }
        }

        private ObservableCollection<Micon225ConfigDataList> _Micon225CatId;

        public ObservableCollection<Micon225ConfigDataList> Micon225CatId
        {
            get { return _Micon225CatId; }
            set { _Micon225CatId = value; OnPropertyChanged("Micon225CatId"); }
        }

        private ObservableCollection<string> _TimersList;

        public ObservableCollection<string> TimersList
        {
            get { return _TimersList; }
            set { _TimersList = value; OnPropertyChanged("TimersList"); }
        }

        private ObservableCollection<string> _DeviceTypeList;

        public ObservableCollection<string> DeviceTypeList
        {
            get { return _DeviceTypeList; }
            set { _DeviceTypeList = value; OnPropertyChanged("DeviceTypeList"); }
        }

        private ObservableCollection<string> _PortList;

        public ObservableCollection<string> PortList
        {
            get { return _PortList; }
            set { _PortList = value; OnPropertyChanged("PortList"); }
        }

        private ObservableCollection<PotValues> _PotValuesCollection1;
        public ObservableCollection<PotValues> PotValuesCollection1
        {
            get { return _PotValuesCollection1; }
            set { _PotValuesCollection1 = value; OnPropertyChanged("PotValuesCollection1"); }
        }

        private ObservableCollection<PotValues> _PotValuesCollection2;
        public ObservableCollection<PotValues> PotValuesCollection2
        {
            get { return _PotValuesCollection2; }
            set { _PotValuesCollection2 = value; OnPropertyChanged("PotValuesCollection2"); }
        }

        private ObservableCollection<PotValues> _PotValuesCollection3;
        public ObservableCollection<PotValues> PotValuesCollection3
        {
            get { return _PotValuesCollection3; }
            set { _PotValuesCollection3 = value; OnPropertyChanged("PotValuesCollection3"); }
        }
        private ObservableCollection<PotValues> _PotValuesCollection4;
        public ObservableCollection<PotValues> PotValuesCollection4
        {
            get { return _PotValuesCollection4; }
            set { _PotValuesCollection4 = value; OnPropertyChanged("PotValuesCollection4"); }
        }
        private ObservableCollection<PotValues> _PotValuesCollection5;
        public ObservableCollection<PotValues> PotValuesCollection5
        {
            get { return _PotValuesCollection5; }
            set { _PotValuesCollection5 = value; OnPropertyChanged("PotValuesCollection5"); }
        }


        private ObservableCollection<string> _UsersList = new ObservableCollection<string>();

        public ObservableCollection<string> UsersList
        {
            get { return _UsersList; }
            set { _UsersList = value; OnPropertyChanged("UsersList"); }
        }



        #endregion

        #region POT Usercontrol Properties

        #region POT1 Property
        private int _PointsPot1 = 1;

        private bool _MiddlemarkcalPot1;

        public bool MiddlemarkcalPot1
        {
            get { return _MiddlemarkcalPot1; }
            set { _MiddlemarkcalPot1 = value; OnPropertyChanged("MiddlemarkcalPot1"); }
        }

        private string _PotName1 = "";

        public string PotName1
        {
            get { return _PotName1; }
            set { _PotName1 = value; OnPropertyChanged("PotName1"); }
        }

        private string _PotLables1 = "";

        public string PotLables1
        {
            get { return _PotLables1; }
            set { _PotLables1 = value; OnPropertyChanged("PotLables1"); }
        }

        public int PointsPot1
        {
            get { return _PointsPot1; }
            set { _PointsPot1 = value; OnPropertyChanged("PointsPot1"); }
        }

        private int _UpdatePot1 = 0;

        public int UpdatePot1
        {
            get { return _UpdatePot1; }
            set { _UpdatePot1 = value; OnPropertyChanged("UpdatePot1"); }
        }

        private int _SelectedIndexPot1;

        public int SelectedIndexPot1
        {
            get { return _SelectedIndexPot1; }
            set { _SelectedIndexPot1 = value; OnPropertyChanged("SelectedIndexPot1"); }
        }

        private bool _IsActivePot1 = false;

        public bool IsActivePot1
        {
            get { return _IsActivePot1; }
            set { _IsActivePot1 = value; OnPropertyChanged("IsActivePot1"); }
        }

        #endregion

        #region POT2 Property

        private bool _MiddlemarkcalPot2;

        public bool MiddlemarkcalPot2
        {
            get { return _MiddlemarkcalPot2; }
            set { _MiddlemarkcalPot2 = value; OnPropertyChanged("MiddlemarkcalPot2"); }
        }
        private string _PotName2 = "";

        public string PotName2
        {
            get { return _PotName2; }
            set { _PotName2 = value; OnPropertyChanged("PotName2"); }
        }

        private string _PotLables2 = "";

        public string PotLables2
        {
            get { return _PotLables2; }
            set { _PotLables2 = value; OnPropertyChanged("PotLables2"); }
        }
        private int _PointsPot2 = 1;

        public int PointsPot2
        {
            get { return _PointsPot2; }
            set { _PointsPot2 = value; OnPropertyChanged("PointsPot2"); }
        }

        private int _UpdatePot2 = 0;

        public int UpdatePot2
        {
            get { return _UpdatePot2; }
            set { _UpdatePot2 = value; OnPropertyChanged("UpdatePot2"); }
        }

        private int _SelectedIndexPot2;

        public int SelectedIndexPot2
        {
            get { return _SelectedIndexPot2; }
            set { _SelectedIndexPot2 = value; OnPropertyChanged("SelectedIndexPot2"); }
        }

        private bool _IsActivePot2 = false;

        public bool IsActivePot2
        {
            get { return _IsActivePot2; }
            set { _IsActivePot2 = value; OnPropertyChanged("IsActivePot2"); }
        }
        #endregion

        #region POT3 Property

        private bool _MiddlemarkcalPot3;

        public bool MiddlemarkcalPot3
        {
            get { return _MiddlemarkcalPot3; }
            set { _MiddlemarkcalPot3 = value; OnPropertyChanged("MiddlemarkcalPot3"); }
        }
        private string _PotName3 = "";

        public string PotName3
        {
            get { return _PotName3; }
            set { _PotName3 = value; OnPropertyChanged("PotName3"); }
        }

        private string _PotLables3 = "";

        public string PotLables3
        {
            get { return _PotLables3; }
            set { _PotLables3 = value; OnPropertyChanged("PotLables3"); }
        }

        private int _PointsPot3 = 1;

        public int PointsPot3
        {
            get { return _PointsPot3; }
            set { _PointsPot3 = value; OnPropertyChanged("PointsPot3"); }
        }

        private int _UpdatePot3 = 0;

        public int UpdatePot3
        {
            get { return _UpdatePot3; }
            set { _UpdatePot3 = value; OnPropertyChanged("UpdatePot3"); }
        }

        private int _SelectedIndexPot3;

        public int SelectedIndexPot3
        {
            get { return _SelectedIndexPot3; }
            set { _SelectedIndexPot3 = value; OnPropertyChanged("SelectedIndexPot3"); }
        }

        private bool _IsActivePot3 = false;

        public bool IsActivePot3
        {
            get { return _IsActivePot3; }
            set { _IsActivePot3 = value; OnPropertyChanged("IsActivePot3"); }
        }
        #endregion

        #region POT4 Property
        private bool _MiddlemarkcalPot4;

        public bool MiddlemarkcalPot4
        {
            get { return _MiddlemarkcalPot4; }
            set { _MiddlemarkcalPot4 = value; OnPropertyChanged("MiddlemarkcalPot4"); }
        }
        private string _PotName4 = "";

        public string PotName4
        {
            get { return _PotName4; }
            set { _PotName4 = value; OnPropertyChanged("PotName4"); }
        }
        private string _PotLables4 = "";

        public string PotLables4
        {
            get { return _PotLables4; }
            set { _PotLables4 = value; OnPropertyChanged("PotLables4"); }
        }

        private int _PointsPot4 = 1;

        public int PointsPot4
        {
            get { return _PointsPot4; }
            set { _PointsPot4 = value; OnPropertyChanged("PointsPot4"); }
        }

        private int _UpdatePot4 = 0;

        public int UpdatePot4
        {
            get { return _UpdatePot4; }
            set { _UpdatePot4 = value; OnPropertyChanged("UpdatePot4"); }
        }

        private int _SelectedIndexPot4;

        public int SelectedIndexPot4
        {
            get { return _SelectedIndexPot4; }
            set { _SelectedIndexPot4 = value; OnPropertyChanged("SelectedIndexPot4"); }
        }

        private bool _IsActivePot4 = false;

        public bool IsActivePot4
        {
            get { return _IsActivePot4; }
            set { _IsActivePot4 = value; OnPropertyChanged("IsActivePot4"); }
        }
        #endregion

        #region POT5 Property
        private bool _MiddlemarkcalPot5;

        public bool MiddlemarkcalPot5
        {
            get { return _MiddlemarkcalPot5; }
            set { _MiddlemarkcalPot5 = value; OnPropertyChanged("MiddlemarkcalPot5"); }
        }
        private string _PotName5 = "";

        public string PotName5
        {
            get { return _PotName5; }
            set { _PotName5 = value; OnPropertyChanged("PotName5"); }
        }


        private string _PotLables5 = "";

        public string PotLables5
        {
            get { return _PotLables5; }
            set { _PotLables5 = value; OnPropertyChanged("PotLables5"); }
        }

        private int _PointsPot5 = 1;

        public int PointsPot5
        {
            get { return _PointsPot5; }
            set { _PointsPot5 = value; OnPropertyChanged("PointsPot5"); }
        }

        private int _UpdatePot5 = 0;

        public int UpdatePot5
        {
            get { return _UpdatePot5; }
            set { _UpdatePot5 = value; OnPropertyChanged("UpdatePot5"); }
        }

        private int _SelectedIndexPot5;

        public int SelectedIndexPot5
        {
            get { return _SelectedIndexPot5; }
            set { _SelectedIndexPot5 = value; OnPropertyChanged("SelectedIndexPot5"); }
        }

        private bool _IsActivePot5 = false;

        public bool IsActivePot5
        {
            get { return _IsActivePot5; }
            set { _IsActivePot5 = value; OnPropertyChanged("IsActivePot5"); }
        }
        #endregion

        #endregion

        #region Relay Command declaration

        public RelayCommand btnOkCmd { get; set; }
        public RelayCommand btnRestartCmd { get; set; }
        public RelayCommand changeDeviceCmd { get; set; }
        public RelayCommand exitCmd { get; set; }
        public RelayCommand ComSettingCmd { get; set; }
        public RelayCommand OpenHelpfileCmd { get; set; }
        public RelayCommand OpenCatalogueWindow { get; set; }
        public RelayCommand Program { get; set; }
        public RelayCommand btnLoginCmd { get; set; }
        public RelayCommand logoutCmd { get; set; }
        public RelayCommand addUserCmd { get; set; }
        public RelayCommand editUserCmd { get; set; }
        public RelayCommand deleteUserCmd { get; set; }
        public RelayCommand userAddToDbCmd { get; set; }
        public RelayCommand userEditToDbCmd { get; set; }
        public RelayCommand userDeleteToDbCmd { get; set; }
        //public RelayCommand ZCDEnable { get; set; }

        #endregion

        #region Objects
        ModbusRTU modbusRTU = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor 
        /// initialise all relaycommand
        /// read json file , filled object catid
        /// </summary>
        public MainWindowVM()
        {
            try
            {
                //temporary folder path is added for renesas programming files.
                clsGlobalVariables.TempPath = Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Temp");
                addUserCmd = new RelayCommand(addUserBtnClk);
                editUserCmd = new RelayCommand(editUserBtnClk);
                deleteUserCmd = new RelayCommand(deleteUserBtnClk);
                userAddToDbCmd = new RelayCommand(userAddClk);
                userEditToDbCmd = new RelayCommand(userEditClk);
                userDeleteToDbCmd = new RelayCommand(userDeleteClk);
                btnOkCmd = new RelayCommand(btnOkClicked);
                btnLoginCmd = new RelayCommand(btnLoginClicked);
                logoutCmd = new RelayCommand(btnLogoutClicked);
                btnRestartCmd = new RelayCommand(btnRestart);
                changeDeviceCmd = new RelayCommand(changeDevice);
                exitCmd = new RelayCommand(ExitApp);
                ComSettingCmd = new RelayCommand(ComSettingClk);
                OpenHelpfileCmd = new RelayCommand(OpenHelpfileClk);
                OpenCatalogueWindow = new RelayCommand(OpenCatalogueDialog);
                //Start = new RelayCommand(StartBtnClkAsync);
                Program = new RelayCommand(ProgramBtnClkAsync);
                //ZCDEnable = new RelayCommand(RelayCalibBtnClicked);
                _TimersList = new ObservableCollection<string>() { "Micon175" };
                _Micon225CatId = new ObservableCollection<Micon225ConfigDataList>();
                _Micon175_CatId = new ObservableCollection<Micon175ConfigDataList>();
                _DeviceTypeList = new ObservableCollection<string>();
                _PortList = new ObservableCollection<string>();
                _DeviceNameList = new ObservableCollection<string>();
                //This is a class for serial port communication. 
                modbusRTU = new ModbusRTU();
                //Log for range pot calibration
                sbpotData = new StringBuilder();
                FileNameRangeCalData = Directory.GetCurrentDirectory() + "\\" + "CalibratedData.csv";

                PotValuesCollection1 = new ObservableCollection<PotValues>();
                PotValuesCollection2 = new ObservableCollection<PotValues>();
                PotValuesCollection3 = new ObservableCollection<PotValues>();
                PotValuesCollection4 = new ObservableCollection<PotValues>();
                PotValuesCollection5 = new ObservableCollection<PotValues>();

                DisplayPathError = false;
                IsPotCardVisible = false;
                ColorChangeProperty = "#ffffff"; //white color code 
                IsCheckedEnableLog = true;

                StreamReader SR = new StreamReader(File.OpenRead(Path.Combine(Environment.CurrentDirectory, "JsonFilesPath.txt")));
                JsonFileName1M = SR.ReadLine().Trim();
                //JsonFileName225 = SR.ReadLine().Trim();       

                //Help file path
                HelpfilePath = SR.ReadLine().Trim() + "\\Help.pdf";
                //Image file path 
                clsGlobalVariables.SelectedImagePath = SR.ReadLine().Trim();

                //DatabasePath = SR.ReadLine().Trim();                
                // clsGlobalVariables.SelectedRpjPath = SR.ReadLine().Trim();
                // clsGlobalVariables.SelectedRwsPath = SR.ReadLine().Trim();
                clsGlobalVariables.Micon175Jsonpath = JsonFileName1M;
                // clsGlobalVariables.Micon225Jsonpath = JsonFileName225;                
                // clsGlobalVariables.DatabasePath = DatabasePath;
                SR.Close();

                LogFilePath = Directory.GetCurrentDirectory() + "\\Logfiles";

                if (!refresDataFromMicon175_File())
                {
                    //ShowMessageBox("Error while reading data from json, something is wrong in json OR check json file path", false, "", clsGlobalVariables.MsgIcon.Error);
                    //Add message if json file path is invalid, also application will exit after click on ok.
                    MessageBoxResult res = System.Windows.MessageBox.Show("Json file is not found on given path, please check path", "JSON File Path Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    if (res == MessageBoxResult.OK)
                    {
                        ExitApp(this);
                    }
                    return;
                }

                GetPortList();
                SelectedComPort = Properties.Settings.Default.DUTComPort;
                SelectedBaudRate = Properties.Settings.Default.DUTBaudrate;

                Checkpath = "Please check given mot file path, rws file path and rpj file path in database";

                log = new MyLogWriterDLL.LogWriter();
                log.LogWriterStatus();

                if (clsGlobalVariables.EnableAutentication == false)
                {
                    ProductSelectionVis = true;
                    LoginVis = false;
                    clsGlobalVariables.IsLoggedInUserAdmin = true;
                    clsGlobalVariables.LoggedInUser = "Admin";
                    clsGlobalVariables.LoggedInUserId = 0;
                    UserName = "Admin";
                    Password = "";
                    IsAdmin = false;
                    EnableAutentication = false;
                    ShowProductSelectionWindow();
                }
                else
                {
                    EnableAutentication = true;
                    ProductSelectionVis = false;
                    LoginVis = true;
                }
                windowsize = 250;
            }
            catch (Exception ex)
            {
                ShowMessageBox("Main Constructor, please check JsonFilesPath text file and path of json file and log file.", false, "", clsGlobalVariables.MsgIcon.Error);
                MyLogWriterDLL.LogWriter.WriteLog("Exception while reading text file : " + ex.ToString());
            }
        }
        /// <summary>
        /// Help file click event
        /// Open help file after click on menu
        /// </summary>
        /// <param name="obj"></param>
        private void OpenHelpfileClk(object obj)
        {
            try
            {
                System.Diagnostics.Process.Start(HelpfilePath);
            }
            catch (Exception ex)
            {
                ShowMessageBox("Please check path of help file in jsonpathfiles text file", false, "", clsGlobalVariables.MsgIcon.Error);
                //MessageBox.Show("Please check path of help file.\n"+ ex.StackTrace, "Error",MessageBoxButton.OK,MessageBoxImage.Error);
            }

        }

        #endregion

        #region Authentication Module

        private void userAddClk(object obj)
        {
            try
            {
                User = new clsUserModel()
                {
                    UserName = UserName,
                    Password = Password,
                    IsAdmin = IsAdminChk,
                    LoginTime = DateTime.Now.ToLocalTime(),
                    LastLogin = DateTime.Now.ToLocalTime()
                };
                clsGlobalVariables.UserStatus res = clsUserModel.addUser(User);
                if (res == clsGlobalVariables.UserStatus.UserAdded)
                {
                    ShowMessageBox("User Successfully added.", false, "UserAddWindow", clsGlobalVariables.MsgIcon.Message);
                    UsersList.Clear();
                    UsersList = clsUserModel.getUsersList();
                }
                else if (res == clsGlobalVariables.UserStatus.UserAddFailed)
                {
                    ShowMessageBox("Failed to add user.", false, "UserAddWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.DatabaseConectionFailed)
                {
                    ShowMessageBox("Failed to connect to database.", false, "UserAddWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.ExceptionHandeled)
                {
                    ShowMessageBox("Exception during user add", false, "UserAddWindow", clsGlobalVariables.MsgIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox("Exception Message: " + ex.Message, false, "UserAddWindow", clsGlobalVariables.MsgIcon.Error);
            }
        }

        private void userEditClk(object obj)
        {
            try
            {
                clsGlobalVariables.UserStatus res = clsUserModel.editUser(User);
                if (res == clsGlobalVariables.UserStatus.UserEdited)
                {
                    ShowMessageBox("User Successfully edited.", false, "UserEditWindow", clsGlobalVariables.MsgIcon.Message);
                    UsersList.Clear();
                    UsersList = clsUserModel.getUsersList();
                }
                else if (res == clsGlobalVariables.UserStatus.UserEditFailed)
                {
                    ShowMessageBox("Failed to edit user.", false, "UserEditWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.NoRecordFound)
                {
                    ShowMessageBox("Failed to edit user. No record Found in the database", false, "UserEditWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.DatabaseConectionFailed)
                {
                    ShowMessageBox("Failed to connect to database.", false, "UserEditWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.ExceptionHandeled)
                {
                    ShowMessageBox("Exception during user edit", false, "UserEditWindow", clsGlobalVariables.MsgIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox("Exception Message: " + ex.Message, false, "UserEditWindow", clsGlobalVariables.MsgIcon.Error);
            }
        }

        private void userDeleteClk(object obj)
        {
            try
            {
                clsGlobalVariables.UserStatus res = clsUserModel.deleteUser(User);
                if (res == clsGlobalVariables.UserStatus.UserDeleted)
                {
                    ShowMessageBox("User Successfully deleted.", false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Message);
                    UsersList.Clear();
                    UsersList = clsUserModel.getUsersList();
                }
                else if (res == clsGlobalVariables.UserStatus.UserDeleteFailed)
                {
                    ShowMessageBox("Failed to delete user.", false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.NoRecordFound)
                {
                    ShowMessageBox("Failed to delete user. No record Found in the database", false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.DatabaseConectionFailed)
                {
                    ShowMessageBox("Failed to connect to database.", false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.ExceptionHandeled)
                {
                    ShowMessageBox("Exception during user delete", false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Error);
                }
                else if (res == clsGlobalVariables.UserStatus.UserIsLoggedIn)
                {
                    ShowMessageBox("Cannot delete user, User is currently logged in with same credentials", false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Error);
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox("Exception Message: " + ex.Message, false, "UserDeleteWindow", clsGlobalVariables.MsgIcon.Error);
            }
        }

        private void deleteUserBtnClk(object obj)
        {
            UsersList = clsUserModel.getUsersList();
            SelectedUserName = "";
            User = null;
            ShowDeleteUserWindow();
        }

        private void editUserBtnClk(object obj)
        {
            UsersList = clsUserModel.getUsersList();
            SelectedUserName = "";
            User = null;
            ShowEditUserWindow();
        }

        private void addUserBtnClk(object obj)
        {
            User = new clsUserModel();
            UserName = "";
            Password = "";
            ShowAddUserWindow();
        }

        private void btnLogoutClicked(object obj)
        {
            clsGlobalVariables.LoggedInUser = "";
            clsGlobalVariables.LoggedInUserId = 0;
            clsGlobalVariables.IsLoggedInUserAdmin = false;
            IsProductSelected = false;
            LoggedInUser = clsGlobalVariables.LoggedInUser;
            SelectedDeviceName = "";
            userTick = false;
            AdminUserTick = false;
            UserName = "";
            Password = "";
            ShowLoginWindow();
        }

        private void btnLoginClicked(object obj)
        {
            if (UserName != "" && UserName != null && Password != "" && Password != null)
            {
                var res = clsUserModel.validateUser(UserName, Password);
                if (res == clsGlobalVariables.UserStatus.Valid)
                {
                    UserNameError = false;
                    PasswordError = false;
                    IncorrectError = false;
                    if (clsGlobalVariables.IsLoggedInUserAdmin == true)
                    {
                        AdminUserTick = true;
                        IsAdmin = true;
                        userTick = false;
                    }
                    else
                    {
                        IsAdmin = false;
                        AdminUserTick = false;
                        userTick = true;
                    }
                    LoggedInUser = clsGlobalVariables.LoggedInUser;
                    ShowProductSelectionWindow();
                }
                else if (res == clsGlobalVariables.UserStatus.Invalid)
                {
                    UserName = "";
                    Password = "";
                    IncorrectError = true;
                }
            }
            else
            {
                UserName = "";
                Password = "";
                UserNameError = true;
                PasswordError = true;
            }

        }
        #endregion

        /// <summary>
        /// btnRetry()
        /// While calibration process, if retry button is clicked, IsRetryclicked flag is made true
        /// And other buttons flag are made false.
        /// </summary>
        /// <param name="obj"></param>
        public void btnRetry(object obj)
        {
            clsGlobalVariables.IsRetryclicked = true;
            clsGlobalVariables.IsOkclicked = false;
        }
        /// <summary>
        /// btnRestart()
        /// While calibration process, if restart button is clicked, IsRestartclicked flag is made true
        /// And other buttons flag are made false.
        /// </summary>
        public void btnRestart(object obj)
        {
            clsGlobalVariables.IsRestartclicked = true;
            clsGlobalVariables.IsRetryclicked = false;
            clsGlobalVariables.IsOkclicked = false;
        }
        /// <summary>
        /// GetPortList()
        /// This function gets the list of all available COM ports connected to PC
        /// and assigns it to the COM port combobox List. 
        /// </summary>
        private void GetPortList()
        {
            PortList.Clear();
            string[] GetPorts = SerialPort.GetPortNames();
            foreach (string item in GetPorts)
            {
                PortList.Add(item);
            }
        }

        //if only relay calibration is failed then user can retry by using relay calib btn then this function will get called 
        // and this will get disable after relay calib successfully completed. other remain enable till next programming.
        //public  void RelayCalibBtnClicked(object obj)
        //{
        //    StartRelayCalibration();
        //}

        public async void StartRelayCalibration()
        {
            byte strmModuleName;
            IsProgEnable = false;
            FinalStatus = "";
            SuccessStatus = false;
            ErrorStatus = false;
            IsPrgVis = true;
            await Task.Delay(800);

            strmModuleName = ZcdCalibration(clsGlobalVariables.SelectedCatIdObj);
            if (strmModuleName == (byte)EnmModuleName.Stop)
            {
                if (clsGlobalVariables.SelectedCatIdObj.IsSwitchPresent)
                {
                     SwitchHardwareChecking();
                }
                else
                {
                    PLCOffCommand(); //OFF PLC                 
                    System.Windows.Application.Current.Dispatcher.Invoke(delegate
                    {
                        // update UI
                        tmrMbTimer.Dispose();
                    });
                    ShowMessageBox("Programming and calibration completed successfully!!!", false, "", clsGlobalVariables.MsgIcon.Message);
                }

            }
            else
            {
                if (clsGlobalVariables.IsRelayRetrydone == false)
                {
                    try
                    {
                        clsGlobalVariables.IsRelayRetrydone = true;

                        RelayCalibrationRetry RelayCalibration = null;

                        RelayCalibration = new RelayCalibrationRetry();

                        RelayCalibration.ShowDialog();
                    }
                    catch (Exception ex)
                    {
                        IsPrgVis = false;
                        MessageBox.Show("In Relay Retry Module");
                    }

                }
                else
                {
                    PLCOffCommand(); //OFF PLC         
                    System.Windows.Application.Current.Dispatcher.Invoke(delegate
                    {
                        // update UI
                        tmrMbTimer.Dispose();
                    });
                    ShowMessageBox("Relay Calibration Failed!!!", false, "", clsGlobalVariables.MsgIcon.Message);
                }
            }

        }

        /// <summary>
        /// ProgramBtnClkAsync()
        /// This function is invoked when Start button is clicked on UI.
        /// First it will auto detect COM port of PLC.
        /// Second this function will get selected CATID to check supply voltage and supply type.
        /// Third this function will call another function "StartProgramming" to begin the programming process.
        /// </summary>
        /// <param name="obj"></param>
        public async void ProgramBtnClkAsync(object obj)
        {

            try
            {
                //Get Selected catid so that we can check supply voltage and supply type
                CatIDList SelectedcatID = clsGlobalVariables.SelectedCatIdObj;
                //Start
                clsGlobalVariables.strSwitchCalibStatus = (byte)EnmSwitchCalibrationstate.Stop;
                clsGlobalVariables.IsSwitchCalibFailed = false;
                clsGlobalVariables.IsRelayRetrydone = false;
                clsGlobalVariables.switchtestvar = 0;
                clsGlobalVariables.SwitchCnt = 0;
                clsGlobalVariables.switchcasevar = 0;
                DisplayPathError = false;
                IsProgEnable = false;
                IsPrgVis = true;
                StartStopWatch();
                await Task.Delay(800);

                //PLC Port Autodetection and start required relays of PLC 

                if (PLCPortDetected != true)
                {
                    PLCPortDetected = AutoDetectPLCPort();
                    if (!PLCPortDetected)
                    {
                        ShowMessageBox("PLC Port not detected", false, "PortDetect", clsGlobalVariables.MsgIcon.Error);
                        //MessageBox.Show("PLC Port not detected.", "Port Error");
                        IsPrgVis = false;
                        IsProgEnable = true;
                        tmrMbTimer.Dispose();
                        return;
                    }
                }
                else
                {
                    PLCOffCommand(); //Sequence SQ11
                }

                clsGlobalVariables.SelectedMotPath = clsGlobalVariables.OriginalMotPath;
                StopwatchTime = "00:00:00";
                IsDone = false;
                //Clear Firmware version feild for new cat id.
                FirmwareVersion = "";
                //Send query according to that SQ sequence will ON
                bool PLCstatus = SetSupplyVoltageTOPLC(SelectedcatID.DeviceSupplyforCal, "On", SelectedcatID);
                await Task.Delay(500);
                //If PLC not responding to the query of ON relay.
                if (!PLCstatus)
                {
                    IsPrgVis = false;
                    IsProgEnable = true;
                    tmrMbTimer.Dispose();
                    return;
                }

                //Node voltage validation
                if (!ReadNodeVoltage(SelectedcatID))
                {
                    //After failure of node voltages supply of device should be off. 
                    PLCOffCommand();
                    IsPrgVis = false;
                    IsProgEnable = true;
                    tmrMbTimer.Dispose();
                    return;
                }

                StartProgramming(SelectedcatID);

            }
            catch (Exception ex)
            {
                ShowMessageBox("In ProgramBtnClkAsync, " + ex.Message, false, "", clsGlobalVariables.MsgIcon.Error);
                //MessageBox.Show("In ProgramBtnClkAsync, " + ex.Message,"Error",MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }
        /// <summary>
        /// StartProgramming()
        /// This function is used to program DUT.
        /// First proper supply is set in the PLC.
        /// Second a stopwatch is started to display time on UI.
        /// Third it will clear all the previously created temporary files.
        /// Fourth all the required files are copied from NAS to the temporary folder at the installation directory.
        /// Fifth required projects files are created according to selected CATID.
        /// Sixth a batch file is written to run the renesas flash utility.
        /// Seventh created batch file is executed in the background and result is saved into a text file.
        /// Eighth according to result saved in text file PASS or FAIL is displyed on the programming section on UI.
        /// Ninth if result is PASS then another function "StartCalibration" is called to begin calibration process or 
        /// if result is FAIL or any other error occurs another functions "ProgramFailed()" and "PLCOffCommand()" are called 
        /// to cut the supply to DUT for safety of Device ad stop all the processes.
        /// </summary>
        /// <param name="SelectedcatID"></param>
        private async void StartProgramming(CatIDList SelectedcatID)
        {
            try
            {
                //IsCatIdSelected = false;
                //Send query according to that SQ sequence will ON
                bool PLCstatus = SetSupplyVoltageTOPLC(SelectedcatID.DeviceSupplyforCal, "On", SelectedcatID);
                await Task.Delay(500);
                //If PLC not responding to the query of ON relay.
                if (!PLCstatus)
                {
                    tmrMbTimer.Dispose();
                    return;
                }

                //Check Renesas version
                if (SelectedcatID.RFPVersion == "3.03")
                {
                    ShowMessageBox("Renesas 3.03 is not working, please select 2.05", false, "", clsGlobalVariables.MsgIcon.Error);
                    return;
                }

                if (clsGlobalVariables.IsTimerRunning == false)
                {
                    FinalStatus = "";
                    SuccessStatus = false;
                    ErrorStatus = false;
                    PassStatus = false;
                }
                else
                    clsGlobalVariables.IsTimerRunning = false;

                if (clsGlobalVariables.SelectedMotPath == clsGlobalVariables.OriginalMotPath)
                {
                    ClearPot();
                    SelectedIndexPotInitial();
                }

                CalibrationStatus = "";
                IsProcessOn = true;
                IsProgEnable = false;
                IsFail = false;
                IsDone = false;
                IsPrgVis = true;
                clsGlobalVariables.SelectedBaudRate = "115200";

                await Task.Delay(1000);

                var txt = "";
                clsFlashProgrammer fp = new clsFlashProgrammer();
                if (fp.ClearFiles())
                {
                    if (fp.GetFiles())
                    {
                        if (fp.PrepareProjectFile())
                        {
                            if (fp.WriteBatchFile())
                            {

                                Process procRFPProg = new Process();
                                procRFPProg.StartInfo.FileName = clsGlobalVariables.TempPath + "\\" + clsGlobalVariables.SelectedDeviceName + ".bat";//Batch file name for execution.
                                procRFPProg.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;//Hide command prompt window
                                procRFPProg.Start();//start the Programming of device.     
                                await Task.Delay(1000);

                                procRFPProg.WaitForExit(35000); //timeout for renesas software changed from 1min to 45sec.                              

                                await Task.Delay(1000);
                                // waitforprogramming();                 
                                StreamReader sr = new StreamReader(File.OpenRead(clsGlobalVariables.TempPath + "\\" + clsGlobalVariables.strmLogFileName));
                                txt = sr.ReadToEnd();
                                sr.Close();

                                if (txt.Contains("PASS"))
                                {
                                    Console.Beep(1000, 100);
                                    IsFail = false;
                                    //IsDone = true;
                                    if (clsGlobalVariables.SelectedMotPath != clsGlobalVariables.OriginalMotPath)
                                    {
                                        //Dispatcher.Invoke used in multithreading. Background logic and GUI updation
                                        System.Windows.Application.Current.Dispatcher.Invoke(delegate
                                        {
                                            // update UI
                                            tmrMbTimer.Dispose();
                                            //FinalStatus = "PASS";
                                            PassStatus = true;
                                            StatusColorProperty = "#2e7d32";
                                        });
                                    }
                                }
                                else if (txt.Contains("Error") && txt.Contains("communication time out"))
                                {
                                    ProgramFailed();
                                    ShowMessageBox("Please check proper COM port is selected in Communication Settings and Device is powered ON", false, "ComPortSet", clsGlobalVariables.MsgIcon.Error);
                                }
                                else if (txt.Length == 0)
                                {
                                    ProgramFailed();
                                    ShowMessageBox("Please check proper COM port and Baudrate is selected in Communication Settings.", false, "ComPortSet", clsGlobalVariables.MsgIcon.Error);
                                }
                                else
                                {
                                    ProgramFailed();
                                    ShowMessageBox("Please check proper Communication Settings, Device connectivity, Powered ON?", false, "ComPortSet", clsGlobalVariables.MsgIcon.Error);
                                }
                            }
                            else
                            {
                                ProgramFailed();
                                ShowMessageBox("Failed to write Batch file.", false, "", clsGlobalVariables.MsgIcon.Error);
                            }
                        }
                        else
                        {
                            ProgramFailed();
                            ShowMessageBox("Failed to Prepare project file.", false, "", clsGlobalVariables.MsgIcon.Error);
                        }
                    }
                    else
                    {
                        ProgramFailed();
                        ShowMessageBox("Failed to create temp folder, please check given rpj, rws and mot file path.\nPlease try again ", false, "", clsGlobalVariables.MsgIcon.Error);
                    }
                }
                else
                {
                    ProgramFailed();
                    ShowMessageBox("Failed to delete temp files.", false, "", clsGlobalVariables.MsgIcon.Error);
                    //Start.CanExecute("Programdone");
                }

                IsProcessOn = false;

                if (txt.Contains("PASS"))
                {
                    clsGlobalVariables.SelectedBaudRate = SelectedBaudRate;
                    await Task.Delay(500);
                    PLCstatus = SetSupplyVoltageTOPLC(SelectedcatID.DeviceSupplyforCal, "Off", SelectedcatID);
                    await Task.Delay(500);
                    if (!PLCstatus)
                    {
                        MessageBox.Show("PLC did not responding", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    if (clsGlobalVariables.SelectedMotPath == clsGlobalVariables.OriginalMotPath)
                    {
                        StartCalibration();
                    }
                    else
                    {
                        PLCOffCommand(); //Sequence SQ11
                    }
                    IsProgEnable = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In StartProgramming " + ex.ToString());
            }
        }


        /// <summary>
        /// ReadNodeVoltage()
        /// This function is used to read node voltages of device and validate them.
        /// First query to read node voltage is made.
        /// Second this query is then sent to PLC, and response is validated.
        /// Third if response is invalid, respective error message is displayed.
        /// If response is valid then each Node voltage from the response is compared 
        /// with the valid range given in configuration file, and if any node voltage is not in valid range 
        /// respective error message is displayed.
        /// </summary>
        /// <param name="SelectedcatID"></param>
        /// <returns></returns>
        private bool ReadNodeVoltage(CatIDList SelectedcatID)
        {
            byte[] PlcQueryToReadVoltage = null;
            int status = clsGlobalVariables.FAILURE;
            //Read analog voltage
            clsGlobalVariables.ObjSerialComPort.MakeFrame(ref PlcQueryToReadVoltage, (byte)PLC_OutputOnOff.ReadPLCAnalogVoltage);
            //Check PLC Responce
            byte[] PLCResNodevtg = null;
            for (int retry = 0; retry < clsGlobalVariables.RetryCount; retry++)
            {
                //Analog Voltage
                PLCResNodevtg = clsGlobalVariables.ObjSerialComPort.SendQueryGetResponse(ref status, PlcQueryToReadVoltage, SelectedPLCComPort, "9600");
                if (PLCResNodevtg != null && status == clsGlobalVariables.SUCCESS)
                {
                    if (PLCResNodevtg[0] != 0xFA && PLCResNodevtg[1] != 0x04)
                    {
                        // MessageBox.Show("Invalid response from PLC while read analog voltage", "Communication failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ShowMessageBox("Invalid response from PLC while read analog voltage", false, "", clsGlobalVariables.MsgIcon.Error);
                        return false;
                    }
                    else
                        break;
                }
                else
                {
                    //Display error message
                    if (retry == clsGlobalVariables.RetryCount - 1)
                    {
                        //MessageBox.Show("No response from PLC while read analog voltage", "Communication Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                        ShowMessageBox("No response from PLC while read analog voltage", false, "", clsGlobalVariables.MsgIcon.Error);
                        return false;
                    }
                }
            }

            //Node Voltages validation
            bool Invalid = false;
            StringBuilder addstr = new StringBuilder();
            double minvalue = 0;
            double maxvalue = 0;

            //Validation min max issue observed in V2.0
            //Changed datatype from integer to double by changing divisor 400 to 400.0
            //Node 1
            if (SelectedcatID.NodeVoltagesRange[0] != "" && SelectedcatID.NodeVoltagesRange[0] != null)
            {
                var vtgRange = SelectedcatID.NodeVoltagesRange[0].Split('-').Select(Double.Parse).ToList();
                minvalue = vtgRange[0];
                maxvalue = vtgRange[1];
                //Changed datatype from integer to double by changing divisor 400 to 400.0
                if (minvalue >= (((PLCResNodevtg[3] << 8) | PLCResNodevtg[4]) / 400.0) || maxvalue <= (((PLCResNodevtg[3] << 8) | PLCResNodevtg[4]) / 400.0))
                {
                    addstr.Append("DUT NODE1 voltage not in range, " + "Range : " + SelectedcatID.NodeVoltagesRange[0].ToString() + ", DUT Voltage : " + ((PLCResNodevtg[3] << 8) | PLCResNodevtg[4]) / 400.0);
                    //ShowMessageBox("DUT node1 voltage not in range, please verify range of node1 voltage", false, "", clsGlobalVariables.MsgIcon.Error);
                    Invalid = true;
                }
            }
            //Node 2
            if (SelectedcatID.NodeVoltagesRange[1] != "" && SelectedcatID.NodeVoltagesRange[1] != null)
            {
                var vtgRange = SelectedcatID.NodeVoltagesRange[1].Split('-').Select(Double.Parse).ToList();
                minvalue = vtgRange[0];
                maxvalue = vtgRange[1];
                //Changed datatype from integer to double by changing 400 to 400.0
                if (minvalue >= (((PLCResNodevtg[5] << 8) | PLCResNodevtg[6]) / 400.0) || maxvalue <= (((PLCResNodevtg[5] << 8) | PLCResNodevtg[6]) / 400.0))
                {
                    addstr.AppendLine();
                    addstr.Append("\nDUT NODE2 voltage not in range, " + "Range : " + SelectedcatID.NodeVoltagesRange[1].ToString() + ", DUT Voltage : " + ((PLCResNodevtg[5] << 8) | PLCResNodevtg[6]) / 400.0);
                    //ShowMessageBox("DUT node2 voltage not in range, please verify range of node2 voltage", false, "", clsGlobalVariables.MsgIcon.Error);
                    Invalid = true;
                }
            }
            //Node 3
            if (SelectedcatID.NodeVoltagesRange[2] != "" && SelectedcatID.NodeVoltagesRange[2] != null)
            {
                var vtgRange = SelectedcatID.NodeVoltagesRange[2].Split('-').Select(Double.Parse).ToList();
                minvalue = vtgRange[0];
                maxvalue = vtgRange[1];
                //Changed datatype from integer to double by changing 400 to 400.0
                if (minvalue >= (((PLCResNodevtg[7] << 8) | PLCResNodevtg[8]) / 400.0) || maxvalue <= (((PLCResNodevtg[7] << 8) | PLCResNodevtg[8]) / 400.0))
                {
                    addstr.AppendLine();
                    addstr.Append("\nDUT NODE3 voltage not in range, " + "Range : " + SelectedcatID.NodeVoltagesRange[2].ToString() + ", DUT Voltage : " + ((PLCResNodevtg[7] << 8) | PLCResNodevtg[8]) / 400.0);
                    //ShowMessageBox("DUT node3 voltage not in range, please verify range of node3 voltage", false, "", clsGlobalVariables.MsgIcon.Error);
                    Invalid = true;
                }
            }
            //Node 4
            if (SelectedcatID.NodeVoltagesRange[3] != "" && SelectedcatID.NodeVoltagesRange[3] != null)
            {
                var vtgRange = SelectedcatID.NodeVoltagesRange[3].Split('-').Select(Double.Parse).ToList();
                minvalue = vtgRange[0];
                maxvalue = vtgRange[1];
                //Changed datatype from integer to double by changing 400 to 400.0
                if (minvalue >= (((PLCResNodevtg[9] << 8) | PLCResNodevtg[10]) / 400.0) || maxvalue <= (((PLCResNodevtg[9] << 8) | PLCResNodevtg[10]) / 400.0))
                {
                    addstr.AppendLine();
                    addstr.Append("\nDUT NODE4 voltage not in range, " + "Range : " + SelectedcatID.NodeVoltagesRange[3].ToString() + ", DUT Voltage : " + ((PLCResNodevtg[9] << 8) | PLCResNodevtg[10]) / 400.0);
                    //ShowMessageBox("DUT node4 voltage not in range, please verify range of node4 voltage", false, "", clsGlobalVariables.MsgIcon.Error);
                    Invalid = true;
                }
            }
            if (!Invalid)
                return true;
            else
            {
                ShowMessageBox(addstr.ToString(), false, "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// PLCOffCommand()
        /// This function is used to send off command to PLC to turn all the relays OFF.
        /// </summary>
        private void PLCOffCommand()
        {
            int status = clsGlobalVariables.FAILURE;
            byte[] PlcOFFQuery = null;
            clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ11, ref PlcOFFQuery);

            for (int retry = 0; retry < clsGlobalVariables.RetryCount; retry++)
            {
                byte[] PLCResponce = clsGlobalVariables.ObjSerialComPort.SendQueryGetResponse(ref status, PlcOFFQuery, clsGlobalVariables.SelectedPLCComPort, "9600");
                if (PLCResponce != null)
                    break;
                else
                {
                    if (retry == clsGlobalVariables.RetryCount - 1)
                    {
                        MessageBox.Show("PLC did not responding", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }


        /// <summary>
        /// SetSupplyVoltageToPLC()
        /// This function is used to send command to PLC to set proper supply voltage for DUT according
        /// to the parameters passed.
        /// First function receives three parameters supply voltage needed for DUT, 
        /// On/Off state of the supply, Selected CATID
        /// Second according to received parameters a switch case handels which query to send to PLC.
        /// Third if any error occurs respective error message is displayed on UI.
        /// </summary>
        /// <param name="deviceSupplyforCal">Required supply voltage for the calibration </param>
        /// <param name="OnOff">On/OFF query need to sending </param>
        /// <param name="catIDList">Which catid is been selected</param>
        /// <returns></returns>
        private bool SetSupplyVoltageTOPLC(string deviceSupplyforCal, string OnOff, CatIDList catIDList)
        {
            bool PLCStatus = false;
            try
            {
                switch (Convert.ToInt32(deviceSupplyforCal))
                {
                    case 24:
                        switch (OnOff)
                        {
                            case "On":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ1);
                                break;
                            case "Off":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ2);
                                break;
                            default:
                                break;
                        }

                        break;
                    case 12:
                        switch (OnOff)
                        {
                            case "On":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ3);
                                break;
                            case "Off":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ4);
                                break;
                            default:
                                break;
                        }

                        break;
                    case 5:
                        switch (OnOff)
                        {
                            case "On":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ5);
                                break;
                            case "Off":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ6);
                                break;
                            default:
                                break;
                        }

                        break;
                    case 110:
                        switch (OnOff)
                        {
                            case "On":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ7);
                                break;
                            case "Off":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ8);
                                break;
                            default:
                                break;
                        }

                        break;
                    case 240:
                        switch (OnOff)
                        {
                            case "On":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ9);
                                break;
                            case "Off":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ10);
                                break;
                            default:
                                break;
                        }

                        break;
                    case 30:
                        switch (OnOff)
                        {
                            case "On":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ12);
                                break;
                            case "Off":
                                PLCStatus = StartPLCInteraction((byte)PLC_OutputOnOff.PLC_ON_SQ13);
                                break;
                            default:
                                break;
                        }

                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In SetSupplyvoltagaeToPLC : " + ex.ToString());
                return PLCStatus;
            }
            if (!PLCStatus)
            {
                ShowMessageBox("Selected supply voltage or supply type is not valid", false, "", clsGlobalVariables.MsgIcon.Error);
            }
            return PLCStatus;
        }
        /// <summary>
        /// ProgramFailed()
        /// This function is used to stop the running process.
        /// First it enable GUI controls and display fail status on GUI.
        /// Second it will stop the tmrMbTimer timer.
        /// Third it will call PLCOffCommand() method to cut off device supply.
        /// </summary>
        public void ProgramFailed()
        {
            try
            {
                IsProgEnable = true;
                IsFail = true;
                IsDone = false;
                IsPrgVis = false;
                PassStatus = false;
                tmrMbTimer.Dispose();
                PLCOffCommand(); //Issue solved
                FinalStatus = "FAIL";
                FnFinalStatus(false);
                StatusColorProperty = "#c62828";
            }
            catch (Exception)
            {

            }
        }

        /// <summary>
        /// AutoDetectPLCPort()
        /// This function is used to Auto Detection PLC COM port. 
        /// First it will get all available com ports of system.
        /// Second it will get com port one by one from list of com ports and try to get responce from PLC.
        /// Third If valid response recieved from any one of the ports, that port will be assigned as the PLC com port.  
        /// </summary>
        /// <returns></returns>
        private bool AutoDetectPLCPort()
        {
            try
            {
                string[] strCOMPorts = SerialPort.GetPortNames();

                byte[] PlcQueryToPortDetection = null;
                int status = clsGlobalVariables.FAILURE;
                foreach (var port in strCOMPorts)
                {
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ11, ref PlcQueryToPortDetection);

                    byte[] PLCResponce = clsGlobalVariables.ObjSerialComPort.SendQueryGetResponse(ref status, PlcQueryToPortDetection, port, "9600");

                    if (PLCResponce != null && status == clsGlobalVariables.SUCCESS)
                    {
                        if (PLCResponce[0] == 0XFA && PLCResponce[1] == 0X0F && PLCResponce[2] == 0X03 && PLCResponce[3] == 0XE8 && PLCResponce[4] == 0X00 && PLCResponce[5] == 0X07)
                        {
                            SelectedPLCComPort = port;
                            clsGlobalVariables.SelectedPLCComPort = port;
                            return true;
                        }
                        else
                            status = clsGlobalVariables.FAILURE;
                    }
                }
                if (status == clsGlobalVariables.FAILURE)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in setPLC port" + ex.Message);

                return false;
            }

        }
        /// <summary>
        /// StartPLCInteraction()
        /// This function is used to send supply commands to PLC.
        /// First function recieves parameter SQ_Sequence(sequence code to select supply voltages)
        /// Second According to recieved sequence code switch case handles which frame has to implement.
        /// Third It will send implemented frame to PLC and recieve responce from PLC.
        /// Fourth Recieved response is validated, if response is not valid, it will display error message on UI,
        /// if response is valid it will return true. 
        /// </summary>
        /// <param name="SQ_Sequence"></param>
        /// <returns></returns>
        private bool StartPLCInteraction(byte SQ_Sequence)
        {

            byte[] QueryToSend = new byte[10];
            switch (SQ_Sequence)
            {
                case (byte)PLC_OutputOnOff.PLC_ON_SQ1:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ1, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ2:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ2, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ3:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ3, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ4:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ4, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ5:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ5, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ6:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ6, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ7:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ7, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ8:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ8, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ9:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ9, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ10:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ10, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ12:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ12, ref QueryToSend);
                    break;
                case (byte)PLC_OutputOnOff.PLC_ON_SQ13:
                    clsGlobalVariables.ObjSerialComPort.MakeFrame((byte)PLC_OutputOnOff.PLC_ON_SQ13, ref QueryToSend);
                    break;

                default:
                    break;
            }
            int Status = clsGlobalVariables.FAILURE;
            byte[] GetPLCResponce = null;
            for (int retry = 0; retry < clsGlobalVariables.RetryCount; retry++)
            {
                GetPLCResponce = clsGlobalVariables.ObjSerialComPort.SendQueryGetResponse(ref Status, QueryToSend, clsGlobalVariables.SelectedPLCComPort, "9600");
                if (Status == clsGlobalVariables.SUCCESS && GetPLCResponce != null)
                {
                    if (GetPLCResponce[0] == 0xFA)
                    {
                        return true;
                    }
                    if (retry == clsGlobalVariables.RetryCount - 1)
                    {
                        MessageBox.Show("Invalid responce from PLC");
                    }
                }
                if (retry == clsGlobalVariables.RetryCount - 1)
                {
                    MessageBox.Show("No responce from PLC");
                }
            }

            return false;
        }
        /// <summary>
        /// CreateLogRangePotCalibration()
        /// This function is used to create Log file for the range pot calibration
        /// First it will recieve parameter CatIDList object.
        /// Second it will get number of pots assigned to selected cat id.
        /// Third it will check controller type of device, according to either G10 or G12/G13 
        /// mode pot positions are decided. 
        /// Fourth According to number of pots switch case handle how many positions are available according to pot type.
        /// </summary>
        public void CreateLogRangePotCalibration(CatIDList catID)
        {
            try
            {
                string CurrentDate = DateTime.Now.ToString("dd/MM/yyyy");  //
                string CurrentTime = DateTime.Now.ToString("h:mm:ss tt");  //
                sbpotData.Clear();
                sbpotData.AppendLine();

                sbpotData.AppendLine("Product Name : " + SelectedDeviceName);
                sbpotData.AppendLine("Creation Date : " + CurrentDate);
                sbpotData.AppendLine("Creation Time : " + CurrentTime);
                sbpotData.AppendLine();
                int potcount = 0;
                for (int cnt = 0; cnt < catID.Micon175_PotDetail.Count; cnt++)
                {
                    if ((catID.Micon175_PotDetail[cnt].PotName == "Range1" && !catID.Micon175_PotDetail[cnt].CalibApplicable) ||
                        (catID.Micon175_PotDetail[cnt].PotName == "Range2" && !catID.Micon175_PotDetail[cnt].CalibApplicable))
                    { }
                    else
                    {
                        if (catID.Micon175_PotDetail[cnt].PotName != null)
                        {
                            potcount++;
                        }
                    }

                }

                sbpotData.AppendFormat("CurrentDateTime");

                if (catID.ControllerType == "G10")
                {
                    switch (potcount)
                    {
                        case (int)EnmNumberofpots.One:
                            sbpotData.AppendFormat(", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10");
                            break;
                        case (int)EnmNumberofpots.Two:
                            sbpotData.AppendFormat(", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + ", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10");
                            break;
                        case (int)EnmNumberofpots.Three:
                            sbpotData.AppendFormat(", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + ", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + ", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10");
                            break;
                        case (int)EnmNumberofpots.Four:
                            sbpotData.AppendFormat(", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + ", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + ", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + ", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10");
                            break;
                        default:
                            break;
                    }
                }
                else if (catID.ControllerType == "G13" || catID.ControllerType == "G12")
                {
                    for (int cnt = 0; cnt < potcount; cnt++)
                    {
                        if (catID.Micon175_PotDetail[cnt].PotName == "Mode" || catID.Micon175_PotDetail[cnt].PotName == "Timing2")
                        {
                            sbpotData.AppendFormat(", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10" + "," + "Pos11" + "," + "Pos12" + "," + "Pos13" + "," + "Pos14" + "," + "Pos15");
                        }
                        else
                        {
                            sbpotData.AppendFormat(", ," + "Pot Type" + "," + "Pos1" + "," + "Pos2" + "," + "Pos3" + "," + "Pos4" + "," + "Pos5" + "," + "Pos6" + "," + "Pos7" + "," + "Pos8" + "," + "Pos9" + "," + "Pos10");
                        }
                    }
                }

                sbpotData.AppendLine();

                System.IO.File.AppendAllText(FileNameRangeCalData, sbpotData.ToString());
                sbpotData.Clear();
            }
            catch (IOException ex)
            {
                MessageBox.Show("File path not found, please check given path" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception)
            {
                MessageBox.Show("Error occured while saving file.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        StringBuilder sbpotData;
        public string FileNameRangeCalData = "";
        public long FileSize = 10485760; // 10 MB
        /// <summary>
        /// UpdateLogRangePotCalibration()
        /// This function is used to append calibration data of all available pots of selected cat id to the file.
        /// First it will check size of existing file, if size of file is larger than 10MB, it will call another 
        /// function "CreateLogRangePotCalibration()" to create new file.
        /// Second it will append available calibration counts of each pot available in selected cat id to the file in proper format.
        /// If any error occures, respective error message will be displayed on UI.
        /// </summary>
        public void UpdateLogRangePotCalibration(CatIDList catID)
        {
            try
            {
                string CurrentDateTime = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss");  //Current Date Time
                long length = new System.IO.FileInfo(FileNameRangeCalData).Length;

                int posncount = 10;
                if (length >= FileSize)
                {
                    String parentDir = Directory.GetParent(FileNameRangeCalData).ToString();
                    File.Copy(FileNameRangeCalData, parentDir + "\\" + Path.GetFileNameWithoutExtension(FileNameRangeCalData) + "_" + CurrentDateTime + ".csv");
                    File.Delete(FileNameRangeCalData);
                    CreateLogRangePotCalibration(catID);
                }
                //Variable name changed
                var strCalibratededData = "";

                sbpotData.AppendFormat(CurrentDateTime);

                //Timing1 data
                if (Timing1ReadDatabytes.Count > 0)
                {
                    posncount = 10;
                    if (Timing1ReadDatabytes.Count != posncount)
                    {
                        for (int cnt = Timing1ReadDatabytes.Count; cnt < posncount; cnt++)
                        {
                            Timing1ReadDatabytes.Add(0);
                        }
                    }
                    strCalibratededData = String.Join(",", Timing1ReadDatabytes);
                    sbpotData.AppendFormat(", ," + "Timing1" + "," + strCalibratededData);
                }
                //Timing2 data
                if (Timing2ReadDatabytes.Count > 0)
                {
                    posncount = 15;
                    if (Timing2ReadDatabytes.Count != posncount)
                    {
                        for (int cnt = Timing2ReadDatabytes.Count; cnt < posncount; cnt++)
                        {
                            Timing2ReadDatabytes.Add(0);
                        }
                    }
                    strCalibratededData = String.Join(",", Timing2ReadDatabytes);
                    sbpotData.AppendFormat(", ," + "Timing2" + "," + strCalibratededData);

                }

                //Range1 data
                if (Range1ReadDatabytes.Count > 0)
                {
                    posncount = 10;
                    if (Range1ReadDatabytes.Count != posncount)
                    {
                        for (int cnt = Range1ReadDatabytes.Count; cnt < posncount; cnt++)
                        {
                            Range1ReadDatabytes.Add(0);
                        }
                    }
                    strCalibratededData = String.Join(",", Range1ReadDatabytes);
                    sbpotData.AppendFormat(", ," + "Range1" + "," + strCalibratededData);

                }

                //Range2 data
                if (Range2ReadDatabytes.Count > 0)
                {
                    posncount = 10;
                    if (Range2ReadDatabytes.Count != posncount)
                    {
                        for (int cnt = Range2ReadDatabytes.Count; cnt < posncount; cnt++)
                        {
                            Range2ReadDatabytes.Add(0);
                        }
                    }
                    strCalibratededData = String.Join(",", Range2ReadDatabytes);
                    sbpotData.AppendFormat(", ," + "Range2" + "," + strCalibratededData);

                }
                // Mode data
                if (ModeReadDatabytes.Count > 0)
                {
                    if (catID.ControllerType == "G10")
                        posncount = 10;
                    else if (catID.ControllerType == "G12" || catID.ControllerType == "G13")
                        posncount = 15;

                    if (ModeReadDatabytes.Count != posncount)
                    {
                        for (int cnt = ModeReadDatabytes.Count; cnt < posncount; cnt++)
                        {
                            ModeReadDatabytes.Add(0);
                        }
                    }
                    strCalibratededData = String.Join(",", ModeReadDatabytes);
                    sbpotData.AppendFormat(", ," + "Mode" + "," + strCalibratededData);

                }
                // Extra pot data
                if (Pot4ReadDatabytes.Count > 0)
                {
                    posncount = 10;
                    if (Pot4ReadDatabytes.Count != posncount)
                    {
                        for (int cnt = Pot4ReadDatabytes.Count; cnt < posncount; cnt++)
                        {
                            Pot4ReadDatabytes.Add(0);
                        }
                    }
                    strCalibratededData = String.Join(",", Pot4ReadDatabytes);
                    sbpotData.AppendFormat(", ," + "Extra" + "," + strCalibratededData);
                }
                sbpotData.AppendLine();
                if (sbpotData.Length != 0)
                    System.IO.File.AppendAllText(FileNameRangeCalData, sbpotData.ToString());
                sbpotData.Clear();
            }
            catch (IOException ex)
            {
                MessageBox.Show("File not found or if file is open, please close the file /" + ex.Message, "Error");
                sbpotData.Clear();
            }
            catch (Exception)
            {
                sbpotData.Clear();
                MessageBox.Show("Error occured while saving file.", "Error");
            }
        }



        //Stopwatch purpose : Calculate time required for all calibration and programming
        Stopwatch objstpWatch = new Stopwatch(); //Added for Calibration Timer
        public System.Threading.TimerCallback tmrCallback;
        public System.Threading.Timer tmrMbTimer;


        /// <summary>
        /// StartStopWatch()
        /// This function is used to start stopwatch to display time on UI.
        /// Stopwatch is initialised with value 00:00:00
        /// </summary>
        private void StartStopWatch()
        {
            objstpWatch.Reset();
            objstpWatch.Start();
            tmrCallback = new System.Threading.TimerCallback(MbTimerIntr);
            tmrMbTimer = new System.Threading.Timer(tmrCallback, null, 200, 200);
            tmrMbTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);// Stop timer 
            tmrMbTimer.Change(1000, System.Threading.Timeout.Infinite); // 1sec timer is started here.
            StopwatchTime = "00:00:00";
        }


        /// <summary>
        /// MbTimerIntr()
        /// This function is used to start timer thread 
        /// TimeSpan represent time interval in seconds
        /// </summary>
        /// <param name="obj"></param>
        private void MbTimerIntr(object obj)
        {
            try
            {
                //CheckForIllegalCrossThreadCalls = false;
                tmrMbTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);// Stop inter packet timer 
                TimeSpan objtmSpn = objstpWatch.Elapsed;
                // Format and display the TimeSpan value.
                StopwatchTime = String.Format("{0:00}:{1:00}:{2:00}", objtmSpn.Hours, objtmSpn.Minutes, objtmSpn.Seconds);

                tmrMbTimer.Change(1000, System.Threading.Timeout.Infinite); // Start inter packet timer 
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Timer Thread");
                MyLogWriterDLL.LogWriter.WriteLog("ex.Message , ex.StackTrace" + ex.Message + "," + ex.StackTrace);
            }
        }

        /// <summary>
        /// StartCalibration()
        /// This function is used to start calibration process.
        /// First it will get selected cat id.
        /// Second it will send command to DUT to get firmware version.
        /// Third it will validate recieved response from device,if response is valid,
        /// it will display firmware version in proper format on UI.
        /// Fourth it will get controller type from selected cat id and decide either pot calibration start or write Addditional/Runtime features.
        /// Fifth it will call another function FunctionCall() to continue calibration process
        /// </summary>
        /// <param name=""></param>        
        public void StartCalibration()
        {
            try
            {
                CalibrationStatus = "";
                SelectedIndexPotInitial();
                CalibrationStatus = "";
                ClearPot();
                PotValues potValues = new PotValues();
                CatIDList catList = new CatIDList();
                for (int CatId = 0; CatId < Micon175_CatId.Count; CatId++)
                {
                    for (int ConfigData = 0; ConfigData < Micon175_CatId[CatId].Micon175_ConfigData.Count; ConfigData++)
                    {
                        for (int CatIDList = 0; CatIDList < Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList.Count; CatIDList++)
                        {
                            if (Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].DeviceName == SelectedDeviceName)
                            {
                                IsStartClicked = true;

                                //Firmware Version Checking                               
                                byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(0xF7, (byte)clsEnumFunctionCode.FwVersion, (byte)clsEnumReadWriteCode.Readbyte, null);
                                byte[] rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ValidateResponse(txBuff, (byte)clsEnumFunctionCode.FwVersion, (byte)clsEnumReadWriteCode.Readbyte);

                                if (rxBuff == null)
                                {
                                    PLCOffCommand(); //OFF Sequence SQ11
                                    tmrMbTimer.Dispose();
                                    IsProgEnable = true;
                                    IsPrgVis = false;
                                    FinalStatus = "Fail";
                                    FnFinalStatus(false);
                                    return;
                                }
                                else
                                {
                                    if (rxBuff.Length > 4)
                                    {
                                        //Firmware version on GUI
                                        if (Convert.ToInt32(rxBuff[4]) < 10)
                                            FirmwareVersion = "V00" + Convert.ToInt32(rxBuff[4]).ToString();
                                        else if (Convert.ToInt32(rxBuff[4]) > 10 && Convert.ToInt32(rxBuff[4]) < 100)
                                            FirmwareVersion = "V0" + Convert.ToInt32(rxBuff[4]).ToString();
                                        else if (Convert.ToInt32(rxBuff[4]) > 100)
                                            FirmwareVersion = "V" + Convert.ToInt32(rxBuff[4]).ToString();

                                        string firmwareversion = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].FirmwareVersion;
                                        firmwareversion = firmwareversion.Substring(1, firmwareversion.Length - 1);
                                        if (Convert.ToByte(firmwareversion) != rxBuff[4])
                                        {
                                            MessageBox.Show("Firmware version did not match, please verify", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                                            PLCOffCommand(); //OFF Sequence SQ11
                                            tmrMbTimer.Dispose();
                                            StatusColorProperty = "#c62828";
                                            FinalStatus = "Fail";
                                            FnFinalStatus(false);
                                            return;
                                        }
                                    }
                                }

                                if (Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].ControllerType == "G10")
                                    clsGlobalVariables.strmModuleCompleteCall = (byte)EnmModuleName.PotCalibration;
                                else if (Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].ControllerType == "G13" ||
                                        Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].ControllerType == "G12")
                                    clsGlobalVariables.strmModuleCompleteCall = (byte)EnmModuleName.AdditionalandRuntimeFeatures;

                                //The while loop in which all functions called step by step
                                while ((clsGlobalVariables.strmModuleCompleteCall != (byte)EnmModuleName.Stop))
                                {
                                    clsGlobalVariables.strmModuleCompleteCall = FunctionCall(clsGlobalVariables.strmModuleCompleteCall, Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList]);

                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("In StartCalibration " + ex.ToString());
            }
        }

        /// <summary>
        /// CalibrationModule()
        /// This function is used to calibrate pots.
        /// First it clear all the previously set pot values.
        /// Second it will get all the details of pot applicable for calibration for the selected CATID.
        /// 
        /// </summary>
        /// <param name="catIDList"></param>
        private byte CalibrationModule(CatIDList catIDList)
        {
            try
            {
                bool IsBreaking = false;
                bool HasPrevRetryClicked = false;
                int Errorcode = FAILURE;
                clsGlobalVariables.SelectedBaudRate = SelectedBaudRate;

                ShowMessage showMessage; //
                //Clear Potdetails and list of hex data
                ClearPot();
                PotValues potValues = new PotValues();
                CatIDList catList = new CatIDList();
                //For loop for How many pots are available for that particalar catlog ID
                for (int PotNum = 0; PotNum < clsGlobalVariables.NumberOfPots; PotNum++)
                {
                    if ((catIDList.Micon175_PotDetail[PotNum].PotName == "Range1" && !catIDList.Micon175_PotDetail[PotNum].CalibApplicable) ||
                        (catIDList.Micon175_PotDetail[PotNum].PotName == "Range2" && !catIDList.Micon175_PotDetail[PotNum].CalibApplicable))
                        continue;

                    RestartPotNum:
                    ClearCollection(catIDList.Micon175_PotDetail[PotNum].PotName);
                    #region Logical part
                    clsGlobalVariables.strCalWindowNm = "Calibration of " + catIDList.Micon175_PotDetail[PotNum].PotName + " pot";
                    if (catIDList.Micon175_PotDetail[PotNum].Range != null &&
                        catIDList.Micon175_PotDetail[PotNum].Range != "")
                    {
                        //Splits label to show in message
                        string[] labels = catIDList.Micon175_PotDetail[PotNum].PotLables.Split(',');
                        string[] DiffbetweenTwoPos = catIDList.Micon175_PotDetail[PotNum].DiffBetTwoPosition.Split(',');
                        double PrevReadValue = 0;

                        bool Failure = false;
                        bool IsalreadySet = false;
                        //If middle mark calibration flag is true then calibration points are one less than actual number of positions.
                        //So here in for loop added ternary operater to change the limit of for loop.
                        for (int PotPosition = 0; PotPosition < (catIDList.Micon175_PotDetail[PotNum].MiddleMarkCal ?
                            catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 1 :
                            catIDList.Micon175_PotDetail[PotNum].NoOfPosition); PotPosition++)
                        {
                            clsGlobalVariables.IsRetryclicked = false;
                            clsGlobalVariables.IsRestartclicked = false;

                            if (clsGlobalVariables.Break)
                            {
                                clsGlobalVariables.Break = false;
                                return (byte)EnmModuleName.Stop;
                            }

                            // Thread.Sleep(100);
                            string[] data = null;
                            data = catIDList.Micon175_PotDetail[PotNum].Range.Split(',');

                            if ((catIDList.RangePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Range1") ||
                                (catIDList.RangePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Range2") ||
                                (catIDList.TimingPotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Timing1") ||
                                (catIDList.TimingPotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Timing2") ||
                                (catIDList.ModePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Mode"))
                            {
                                if (data.Length != catIDList.Micon175_PotDetail[PotNum].NoOfPosition)
                                {
                                    ShowMessageBox("No. of Position and Range data do not match for Pot details in json file", false, "Error", clsGlobalVariables.MsgIcon.Error);
                                    System.Console.Beep(2000, 100);
                                    return (byte)EnmModuleName.Stop;
                                }
                            }
                            //Given messages to keep pot on particular position
                            if (!Failure && !catIDList.Micon175_PotDetail[PotNum].MiddleMarkCal)
                                clsGlobalVariables.strMessage = "Keep knob on position " + labels[PotPosition];
                            else if (!Failure && catIDList.Micon175_PotDetail[PotNum].MiddleMarkCal)
                                clsGlobalVariables.strMessage = "Keep knob on position " + labels[PotPosition + 1];

                            showMessage = new ShowMessage();
                            showMessage.ShowDialog();

                            if (clsGlobalVariables.Break)
                            {
                                clsGlobalVariables.Break = false;
                                PLCOffCommand(); //Sequence SQ11
                                return (byte)EnmModuleName.Stop;
                            }
                            //Restart Clicked
                            #region Restart Clicked

                            if (clsGlobalVariables.IsRestartclicked == true)
                            {
                                clsGlobalVariables.strMessage = "Keep knob on position " + labels[0];
                                ColorChangeProperty = "#2e7d32"; //green color code
                                clsGlobalVariables.IsRestartclicked = false;
                                if (HasPrevRetryClicked)
                                {
                                    RestartClicked(PotNum);
                                    goto RestartPotNum;
                                }

                                RestartClicked(PotNum);
                                goto RestartPotNum;
                            }
                            #endregion

                            #region Communication Reading Pot Data

                            byte[] rxBuff = null;
                            for (int retry = 0; retry < clsGlobalVariables.RetryCount; retry++)
                            {
                                rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ReadDeviceInfo();
                                if (rxBuff != null)
                                    break;
                                else
                                {
                                    if (retry == clsGlobalVariables.RetryCount - 1)
                                    {
                                        MessageBox.Show("Device not responding Or response is not valid", "Communication failed", MessageBoxButton.OK, MessageBoxImage.Error);
                                        PLCOffCommand(); //Sequence SQ11
                                        return (byte)EnmModuleName.Stop;
                                    }
                                }
                            }
                            if (rxBuff == null)
                            {
                                //MessageBox.Show("Device not responding Or response is not valid", "Communication failed", MessageBoxButton.OK, MessageBoxImage.Error);
                                return (byte)EnmModuleName.Stop;
                            }
                            #endregion

                            //Ok Clicked
                            #region Ok Clicked
                            if (clsGlobalVariables.IsOkclicked)
                            {
                                //In prev case if clicked retry
                                if (HasPrevRetryClicked)
                                {
                                    RemovePot(PotNum, PotPosition);
                                    HasPrevRetryClicked = false;
                                }
                                else if ((Failure && PotNum == 0 && PotValuesCollection1.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                        (Failure && PotNum == 1 && PotValuesCollection2.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                        (Failure && PotNum == 2 && PotValuesCollection3.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                        (Failure && PotNum == 3 && PotValuesCollection4.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                        (Failure && PotNum == 4 && PotValuesCollection5.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition))
                                {
                                    PotPosition = catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 1;
                                }
                                else if (Failure && !HasPrevRetryClicked)
                                {
                                    if (PotPosition > 0 && !IsalreadySet)
                                    {
                                        PotPosition--;
                                    }
                                }

                                if ((PotNum == 0 && PotValuesCollection1.Count > 0) || (PotNum == 1 && PotValuesCollection2.Count > 0) ||
                                    (PotNum == 2 && PotValuesCollection3.Count > 0) || (PotNum == 3 && PotValuesCollection4.Count > 0) || (PotNum == 4 && PotValuesCollection5.Count > 0))
                                    if (Failure && !HasPrevRetryClicked)
                                        RemovePot(PotNum, PotPosition);
                                //Not failure case, suppose running pot 0, and potcollection is equal to no. of position, then 
                                //need to remove that position.
                                if (!Failure)
                                {
                                    if ((PotNum == 0 && PotValuesCollection1.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 1 && PotValuesCollection2.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 2 && PotValuesCollection3.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 3 && PotValuesCollection4.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 4 && PotValuesCollection5.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition))
                                    {
                                        PotPosition = catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 1;
                                        RemovePot(PotNum, PotPosition);
                                    }
                                }
                            }
                            #endregion

                            //Retry Clicked
                            #region Retry Clicked
                            else if (clsGlobalVariables.IsRetryclicked)
                            {
                                //In case failure and last position
                                if ((Failure && PotNum == 0 && PotValuesCollection1.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                    (Failure && PotNum == 1 && PotValuesCollection2.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                    (Failure && PotNum == 2 && PotValuesCollection3.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                    (Failure && PotNum == 3 && PotValuesCollection4.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                    (Failure && PotNum == 4 && PotValuesCollection5.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition))
                                {
                                    PotPosition = catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 1;
                                }
                                //In case failure and not previous retry clicked.
                                else if (Failure && !HasPrevRetryClicked)
                                {
                                    if (PotPosition > 0 && !IsalreadySet)
                                    {
                                        PotPosition--;
                                    }
                                }
                                //Remove Due to Retry case
                                if ((PotNum == 0 && PotValuesCollection1.Count > 0) || (PotNum == 1 && PotValuesCollection2.Count > 0) ||
                                    (PotNum == 2 && PotValuesCollection3.Count > 0) || (PotNum == 3 && PotValuesCollection4.Count > 0) || (PotNum == 4 && PotValuesCollection5.Count > 0))
                                    RemovePot(PotNum, PotPosition);
                                //Not failed but retry case 
                                //Handled last position of pot, 
                                if (!Failure)
                                {
                                    if ((PotNum == 0 && PotValuesCollection1.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 1 && PotValuesCollection2.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 2 && PotValuesCollection3.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 3 && PotValuesCollection4.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition) ||
                                         (PotNum == 4 && PotValuesCollection5.Count == catIDList.Micon175_PotDetail[PotNum].NoOfPosition))
                                    {
                                        PotPosition = catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 1;
                                        RemovePot(PotNum, PotPosition);
                                    }
                                }
                            }
                            #endregion

                            //In case of break the procesure
                            if (clsGlobalVariables.Break)
                            {
                                clsGlobalVariables.Break = false;
                                return (byte)EnmModuleName.Stop;
                            }
                            //Data from Device Read on port
                            potValues.ReadValue = GetPotReading(catIDList.Micon175_PotDetail[PotNum].PotName, rxBuff);
                            int minvalue = 0;
                            int maxvalue = 0;
                            potValues.RangeValue = data[PotPosition];


                            if ((catIDList.RangePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Range1") ||
                                (catIDList.RangePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Range2") ||
                                (catIDList.TimingPotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Timing1") ||
                                (catIDList.TimingPotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Timing2") ||
                                (catIDList.ModePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Mode"))
                            {
                                var Rangesvalues = potValues.RangeValue.Split('-').Select(Int32.Parse).ToList();
                                minvalue = Rangesvalues[0];
                                maxvalue = Rangesvalues[1];
                            }



                            bool IsValidDiff = false;
                            //Check the difference in cur. reading and prev. reading is valid
                            if (PotPosition == 0)
                                IsValidDiff = true;
                            else
                            {
                                //Check that difference between current reading and previous reading should not 0
                                if (DiffbetweenTwoPos.Length > PotPosition - 1)
                                {
                                    if (Convert.ToInt32(potValues.ReadValue - PrevReadValue) == 0)
                                        IsValidDiff = false;
                                    else
                                        IsValidDiff = Convert.ToInt32(potValues.ReadValue - PrevReadValue) >= Convert.ToInt32(DiffbetweenTwoPos[PotPosition - 1]);
                                }

                            }
                            // Range and difference validation
                            if ((catIDList.RangePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Range1") ||
                                (catIDList.RangePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Range2") ||
                                (catIDList.TimingPotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Timing1") ||
                                (catIDList.TimingPotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Timing2") ||
                                (catIDList.ModePotRangeValidation && catIDList.Micon175_PotDetail[PotNum].PotName == "Mode"))
                            {
                                if (((potValues.ReadValue < minvalue) || (potValues.ReadValue > maxvalue)))
                                {
                                    Failure = true;
                                }
                                else
                                {
                                    if (!IsValidDiff)
                                    {
                                        Failure = true;
                                    }
                                    else
                                    {
                                        Failure = false;
                                        //Issue occurs in V01.00
                                        //If user clicked on retry button, count from device will add to collection which software will send to device.
                                        //Software should add counts only on OK button click, if retry clicked by user , count should not add.                                                                       
                                        if (!clsGlobalVariables.IsRetryclicked)
                                        {
                                            AddDataToCollection(catIDList.Micon175_PotDetail[PotNum].PotName, potValues.ReadValue);
                                            PrevReadValue = potValues.ReadValue;
                                        }

                                    }
                                }
                            }
                            else // Only difference validation
                            {
                                if (!IsValidDiff)
                                {
                                    Failure = true;
                                }
                                else
                                {
                                    Failure = false;
                                    //Issue occurs in V01.00
                                    //If user clicked on retry button, count from device will add to collection which software will send to device.
                                    //Software should add counts only on OK button click, if retry clicked by user , count should not add.                                  
                                    if (!clsGlobalVariables.IsRetryclicked)
                                    {
                                        AddDataToCollection(catIDList.Micon175_PotDetail[PotNum].PotName, potValues.ReadValue);
                                        PrevReadValue = potValues.ReadValue;
                                    }
                                }
                            }
                            //The use of a simple lambda statement makes it a relatively lightweight way of updating on the correct thread.
                            //UI updates happen on the UI thread.
                            DispatchService.Invoke(() =>
                            {
                                AddPotCollections(PotNum, potValues);
                            });

                            if (clsGlobalVariables.IsRetryclicked)
                            {
                                PotPosition--;
                                potValues.Status = "Retry";//Retry
                                HasPrevRetryClicked = true;
                            }
                            else if (Failure) //Failed case
                            {
                                clsGlobalVariables.strMessageStatus = "Fail";
                                if (!IsValidDiff)
                                {
                                    clsGlobalVariables.strMessage = "Difference is not valid, " + "difference value : " + Convert.ToInt32(potValues.ReadValue - PrevReadValue).ToString() + "," + "\nRequired difference : " + Convert.ToInt32(DiffbetweenTwoPos[PotPosition - 1]);
                                }
                                else
                                {
                                    if (!catIDList.Micon175_PotDetail[PotNum].MiddleMarkCal)
                                        clsGlobalVariables.strMessage = "Calibration on knob of position " + labels[PotPosition] + " failed.";
                                    else
                                        clsGlobalVariables.strMessage = "Calibration between knob positions " + labels[PotPosition] + " and " + labels[PotPosition + 1] + " failed.";
                                }

                                potValues.Status = "Error"; //failure case
                                ColorChangeProperty = "#c62828"; //Red color code

                                //Beep
                                if (clsGlobalVariables.EnableBeep == true)
                                {
                                    System.Console.Beep(1000, 200);
                                    System.Console.Beep(1000, 200);
                                    System.Console.Beep(1000, 200);
                                }

                                if (PotPosition == (catIDList.Micon175_PotDetail[PotNum].MiddleMarkCal ?
                                    catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 2 :
                                    catIDList.Micon175_PotDetail[PotNum].NoOfPosition - 1))
                                {
                                    PotPosition--;
                                    IsalreadySet = true;
                                }
                                else
                                    IsalreadySet = false;
                            }
                            else //Success case
                            {
                                potValues.Status = "Ok";
                                ColorChangeProperty = "#2e7d32";
                                //Beep
                                //if (clsGlobalVariables.EnableBeep == true)
                                //{                                    
                                //    System.Console.Beep(2000, 100);
                                //}
                                IsBreaking = false;
                                clsGlobalVariables.strMessageStatus = "Pass";
                                if (clsGlobalVariables.IsOkclicked)
                                    PotToNextPosition(PotNum);
                                else if (!Failure && !HasPrevRetryClicked)
                                    PotToNextPosition(PotNum);
                                IsalreadySet = false;
                            }

                            if (IsBreaking)
                                break;
                        }
                    }
                    if (IsBreaking)
                        break;

                    #endregion
                }
                if (catIDList.ControllerType == "G10")
                    return (byte)EnmModuleName.AdditionalandRuntimeFeatures;
                else if (catIDList.ControllerType == "G13" ||
                        catIDList.ControllerType == "G12")
                    return (byte)EnmModuleName.CalibrationData;

                return (byte)EnmModuleName.Stop;
            }
            catch (Exception)
            {
                MessageBox.Show("In CalibrationModule");
                return (byte)EnmModuleName.Stop;
            }
        }
        /// <summary>
        /// StructureToWriteDataInFile()
        /// This function is used to prepare the lists to store calibration data of each available pot.
        /// </summary>
        /// <param name="catID"></param>
        public void StructureToWriteDataInFile()
        {
            int CollectionCount = 10;
            for (int Listcnt = Timing1ReadDatabytes.Count; Listcnt < CollectionCount; Listcnt++)
            {
                Timing1ReadDatabytes.Add(0x00);
            }
            for (int Listcnt = Range1ReadDatabytes.Count; Listcnt < CollectionCount; Listcnt++)
            {
                Range1ReadDatabytes.Add(0x00);
            }
            for (int Listcnt = ModeReadDatabytes.Count; Listcnt < CollectionCount; Listcnt++)
            {
                ModeReadDatabytes.Add(0x00);
            }
            for (int Listcnt = Pot4ReadDatabytes.Count; Listcnt < CollectionCount; Listcnt++)
            {
                Pot4ReadDatabytes.Add(0x00);
            }

        }
        /// <summary>
        /// GetPotAddress()
        /// This function is used to get hex address of the pot with reference to received 
        /// Potname as parameter into the received catIdList object.
        /// </summary>
        /// <param name="PotName"></param>
        /// <param name="catID"></param>
        /// <returns></returns>
        private string GetPotAddress(string PotName, CatIDList catID)
        {
            string HexLocation = "";
            foreach (var item in catID.Micon175_PotDetail)
            {
                if (item.PotName == PotName)
                {
                    HexLocation = item.HexLocation;
                    break;
                }
            }
            return HexLocation;
        }


        /// <summary>
        /// ClearCollection()
        /// This function is used to clear all previous calibration data of the potName, 
        /// which is received as a parameter. 
        /// </summary>
        /// <param name="potName"></param>
        private void ClearCollection(string potName)
        {
            switch (potName)
            {
                case "Timing1":
                    Timing1ReadDatabytes.Clear();
                    break;
                case "Timing2":
                    Timing2ReadDatabytes.Clear();
                    break;
                case "Range1":
                    Range1ReadDatabytes.Clear();
                    break;
                case "Range2":
                    Range2ReadDatabytes.Clear();
                    break;
                case "Mode":
                    ModeReadDatabytes.Clear();
                    break;
                case "Pot4":
                    Pot4ReadDatabytes.Clear();
                    break;

                default:
                    break;
            }
        }
        /// <summary>
        /// AddDataToCollection()
        /// This function is used to add the calibration data to their respective Calibration data list.
        /// First the function receives 'potName', 'readValue' as parameters.
        /// Second a switch case handels in which list of pot should the readValue need to be added.
        /// </summary>
        /// <param name="potName"></param>
        /// <param name="readValue"></param>
        private void AddDataToCollection(string potName, double readValue)
        {
            switch (potName)
            {
                case "Timing1":
                    Timing1ReadDatabytes.Add(Convert.ToByte(readValue));
                    break;
                case "Timing2":
                    Timing2ReadDatabytes.Add(Convert.ToByte(readValue));
                    break;
                case "Range1":
                    Range1ReadDatabytes.Add(Convert.ToByte(readValue));
                    break;
                case "Range2":
                    Range2ReadDatabytes.Add(Convert.ToByte(readValue));
                    break;
                case "Mode":
                    ModeReadDatabytes.Add(Convert.ToByte(readValue));
                    break;
                case "Pot4":
                    Pot4ReadDatabytes.Add(Convert.ToByte(readValue));
                    break;
                default:
                    break;
            }
        }


        /// <summary>
        /// GetPotReading()
        /// This function is used to extract pot reading from provided buffer.
        /// First function receives 'potName', 'rxBuff' as parameters.
        /// Second according to potName switch case handels what values to return from rxBuff. 
        /// </summary>
        /// <param name="potName"></param>
        /// <param name="rxBuff"></param>
        /// <returns></returns>
        private int GetPotReading(string potName, byte[] rxBuff)
        {
            switch (potName)
            {
                case "Timing1":
                    return Convert.ToInt32(rxBuff[4]);
                case "Range1":
                    return Convert.ToInt32(rxBuff[5]);
                case "Mode":
                    return Convert.ToInt32(rxBuff[6]);
                case "Timing2":
                    return Convert.ToInt32(rxBuff[6]);
                case "Range2":
                    return Convert.ToInt32(rxBuff[7]);
                case "Pot4":
                    return Convert.ToInt32(rxBuff[7]);
                default:
                    return 0;
            }
        }


        /// <summary>
        /// FunctionCall()
        /// Main function is used to call every module implemented in software step by step.
        /// First it will decide which module will start the process according to controller type.
        /// If controller type is G10, Sequence will be PotCalibration ----> AdditionalandRuntimeFeatures -----> Programming(Modified file)
        /// If controller type is G12/G13, Sequence will be AdditionalandRuntimeFeatures -----> PotCalibration -----> CalibrationData -----> CalibrationStatus
        /// In case of failure within any module process, strmModuleName will contain "stop", after all stop the process
        /// If any exception occures, it will display the error message regarding error.
        /// </summary>
        /// <param name="strmModuleName"> This parameter will decide which module function has to call,
        /// paramter will update after completion of one module</param>
        /// <param name="catID">CatID object is used for each module as per their requirement from object</param>
        /// <returns></returns>
        public byte FunctionCall(byte strmModuleName, CatIDList catID)
        {
            try
            {
                switch (strmModuleName)
                {
                    //Potentiometer calibration module
                    case (byte)EnmModuleName.PotCalibration:

                        IsPrgVis = false;
                        strmModuleName = CalibrationModule(catID);
                        IsPrgVis = true;


                        if (strmModuleName == (byte)EnmModuleName.Stop)
                        {
                            IsPrgVis = false;
                            FinalStatus = "Cancelled";
                            FnFinalStatus(false);
                            StatusColorProperty = "#c62828";
                            System.Windows.Application.Current.Dispatcher.Invoke(delegate
                            {
                                // update UI
                                tmrMbTimer.Dispose();
                            });
                        }
                        else
                        {
                            //Verify calibrated datas count after getting calibrated counts 
                            //In failure case software will stop the process, also added validation message  
                            if (!VerifyCalibratedDataCount(catID))
                            {
                                strmModuleName = (byte)EnmModuleName.Stop;
                                FinalStatus = "Failed";
                                FnFinalStatus(false);
                                StatusColorProperty = "#c62828";
                                System.Windows.Application.Current.Dispatcher.Invoke(delegate
                                {
                                    // update UI
                                    tmrMbTimer.Dispose();
                                });
                            }

                            if (IsCheckedEnableLog)
                            {
                                GetCalibratedLog(catID);
                            }
                        }
                        break;
                    //Additional features / Runtime features
                    case (byte)EnmModuleName.AdditionalandRuntimeFeatures:
                        strmModuleName = clsGlobalVariables.clsCalibrationModuleObj.WriteAdditionalandRuntimeFeatures(catID, SelectedBaudRate);
                        if (strmModuleName == (byte)EnmModuleName.Stop)
                        {
                            FinalStatus = "FAIL";
                            FnFinalStatus(false);
                            System.Windows.Application.Current.Dispatcher.Invoke(delegate
                            {
                                // update UI
                                tmrMbTimer.Dispose();
                            });
                        }
                        else if (strmModuleName == (byte)EnmModuleName.Programming)
                        {
                            //Query to convert port in programming mode                            
                            //MessageBox.Show("Start Programming, please turn on programming mode.");
                        }
                        break;
                    //Programming module 
                    case (byte)EnmModuleName.Programming:
                        clsGlobalVariables.IsTimerRunning = true;
                        StartProgramming(catID);

                        strmModuleName = (byte)EnmModuleName.Stop;
                        break;
                    //Write Calibration data
                    case (byte)EnmModuleName.CalibrationData:
                        strmModuleName = WriteCalibrationData(catID);

                        if (strmModuleName == (byte)EnmModuleName.Stop)
                        {
                            FinalStatus = "FAIL";
                            FnFinalStatus(false);
                            System.Windows.Application.Current.Dispatcher.Invoke(delegate
                            {
                                // update UI
                                tmrMbTimer.Dispose();
                                PLCOffCommand(); //OFF PLC after G13 calibration

                            });
                        }

                        break;

                    //Write/validate Calibration status
                    case (byte)EnmModuleName.CalibrationStatus:
                        strmModuleName = WriteCalibrationStatus(catID);


                        if (catID.IsZCDEnable)
                        {
                            PLCOffCommand(); //OFF PLC after G13 calibration
                        }

                        if (FinalStatus == "FAIL")
                        {
                            strmModuleName = (byte)EnmModuleName.Stop;
                            PLCOffCommand(); //OFF PLC after G13 calibration  
                            IsPrgVis = false;
                            //Dispatcher.Invoke used in multithreading. Background logic and GUI updation
                            System.Windows.Application.Current.Dispatcher.Invoke(delegate
                            {
                                // update UI
                                tmrMbTimer.Dispose();
                                IsProgEnable = true;
                            });

                        }

                        break;


                    //Write/validate Calibration status
                    case (byte)EnmModuleName.ZCDCalibration:

                        int Plcretry = 0;
                        FinalStatus = "";
                        SuccessStatus = false;
                        ErrorStatus = false;

                        while (Plcretry < 2)
                        {
                            //Send query according to that SQ sequence will ON
                            bool PLCstatus = SetSupplyVoltageTOPLC("30", "Off", catID);
                            Thread.Sleep(500);

                            //If PLC not responding to the query of ON relay.
                            if (!PLCstatus)
                            {
                                Plcretry++;

                                if (Plcretry >= 2)
                                {
                                    MessageBox.Show("PLC did not responding", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                            else
                            {
                                Plcretry = 2;
                                StartRelayCalibration();
                            }
                        }
                        System.Windows.Application.Current.Dispatcher.Invoke(delegate
                        {
                            // update UI
                            tmrMbTimer.Dispose();
                            IsProgEnable = true;
                        });
                        strmModuleName = (byte)EnmModuleName.Stop;

                        break;

                    //switch Calibration 
                    case (byte)EnmModuleName.SwitchCalibration:
                        {
                           SwitchHardwareChecking();
                        }
                        break;


                    //Stop the process          
                    case (byte)EnmModuleName.Stop:
                        strmModuleName = (byte)EnmModuleName.Stop;
                        break;

                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox(ex.Message, false, "", clsGlobalVariables.MsgIcon.Error);
                System.Windows.Application.Current.Dispatcher.Invoke(delegate
                {
                    // update UI
                    tmrMbTimer.Dispose();
                });
                return (byte)EnmModuleName.Stop;
            }
            return strmModuleName;
        }
        /// <summary>
        /// VerifyCalibratedDataCount()
        /// This function is used to verify calibrated datas count after getting calibrated counts. 
        /// Checked each pot type counts and number of positions of that pot in database.
        /// </summary>
        /// <param name="catID">Selected catalog id parameter passed</param>
        /// <returns></returns>
        private bool VerifyCalibratedDataCount(CatIDList catID)
        {
            try
            {
                for (int potnum = 0; potnum < catID.Micon175_PotDetail.Count; potnum++)
                {
                    if (catID.Micon175_PotDetail[potnum].PotName == "Timing1")
                    {
                        if (Timing1ReadDatabytes.Count != catID.Micon175_PotDetail[potnum].NoOfPosition)
                        {
                            ShowMessageBox("Wrong Calibration\n\nTiming1 pot count has exceeded than its actual positions", false, "", clsGlobalVariables.MsgIcon.Error);
                            return false;
                        }
                        continue;
                    }
                    if (catID.Micon175_PotDetail[potnum].PotName == "Range1")
                    {
                        if ((Range1ReadDatabytes.Count != catID.Micon175_PotDetail[potnum].NoOfPosition) && catID.Micon175_PotDetail[potnum].CalibApplicable)
                        {
                            ShowMessageBox("Wrong Calibration\n\nRange1 pot count has exceeded than its actual positions", false, "", clsGlobalVariables.MsgIcon.Error);
                            return false;
                        }
                        continue;
                    }

                    if (catID.Micon175_PotDetail[potnum].PotName == "Mode")
                    {
                        if (ModeReadDatabytes.Count != catID.Micon175_PotDetail[potnum].NoOfPosition)
                        {
                            ShowMessageBox("Wrong Calibration\n\nMode pot count has exceeded than its actual positions", false, "", clsGlobalVariables.MsgIcon.Error);
                            return false;
                        }
                        continue;
                    }

                    if (catID.Micon175_PotDetail[potnum].PotName == "Timing2")
                    {
                        if (Timing2ReadDatabytes.Count != catID.Micon175_PotDetail[potnum].NoOfPosition)
                        {
                            ShowMessageBox("Wrong Calibration\n\nTiming2 pot count has exceeded than its actual positions", false, "", clsGlobalVariables.MsgIcon.Error);
                            return false;
                        }
                        continue;
                    }

                    if ((catID.Micon175_PotDetail[potnum].PotName == "Range2") && catID.Micon175_PotDetail[potnum].CalibApplicable)
                    {
                        if (Range2ReadDatabytes.Count != catID.Micon175_PotDetail[potnum].NoOfPosition)
                        {
                            ShowMessageBox("Wrong Calibration\n\nRange2 pot count has exceeded than its actual positions", false, "", clsGlobalVariables.MsgIcon.Error);
                            return false;
                        }
                        continue;
                    }

                    if (catID.Micon175_PotDetail[potnum].PotName == "Pot4")
                    {
                        if (Pot4ReadDatabytes.Count != catID.Micon175_PotDetail[potnum].NoOfPosition)
                        {
                            ShowMessageBox("Wrong Calibration\n\nPot4 pot count has exceeded than its actual positions", false, "", clsGlobalVariables.MsgIcon.Error);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Wrong Calibration", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }
        /// <summary>
        /// ZCD calibration added
        /// Relay On for zcd calibration, create query for zcd calibation
        ///ZCD calibration new checkbox added in code  data base , whenever relay calibration is present is device 
        ///then that check box need to be checked and  according to that UI will update and when user press
        ///relay calibration button then ZCD calibration will start , if only relay calibration fail then user can retry it 
        ///once relay calibration completed successfully then button visiblity off till next product device calibration.
        ///Device calibration contain programming + Pot calibration+ other device feature query after this relay calib control can 
        ///access.

        private byte ZcdCalibration(CatIDList catID)
        {
            //Relay On
            StartZCDSelfCalibration();
            IsProgEnable = true;
            if (CalibrationStatus == "PASS")
                return (byte)EnmModuleName.Stop;
            else
                return (byte)EnmModuleName.ZCDCalibration;
        }

        private void StartZCDSelfCalibration()
        {
            byte deviceId = 0xF7;

            //Function to provide data parameters to make deviceinfo query        
            byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.ZCD_SelfCalibration, (byte)clsEnumReadWriteCode.Readbyte, null);

            byte[] rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ValidateResponse(txBuff, (byte)clsEnumFunctionCode.ZCD_SelfCalibration, (byte)clsEnumReadWriteCode.Readbyte, true); // option parameter pass in this global function to keep port on only when ZCD calibration is in progress, because need to wait for 2nd response.
            if (rxBuff != null)
            {
                if (rxBuff[1] == (byte)clsEnumFunctionCode.ZCD_SelfCalibration)
                {
                    int Status = clsGlobalVariables.FAILURE; //Default status : ErrorCode => SUCCESS = 0 | FAILURE = -1                  
                    byte[] rxTempBuff = null;

                    Thread.Sleep(5000); // this delay is depend on firmware retry given to take relay on time. this is set 5sec now.

                    rxTempBuff = clsGlobalVariables.ObjSerialComPort.GetResponseOfSelfCalibration(ref Status, clsGlobalVariables.SelectedComPort, clsGlobalVariables.SelectedBaudRate);

                    if (rxTempBuff != null)
                    {
                        if (rxTempBuff[1] == (byte)clsEnumFunctionCode.ZCD_SelfCalibration)
                        {

                            if (Status == clsGlobalVariables.SUCCESS)
                            {
                                if (rxTempBuff[4] == 1)
                                {
                                    RelayONTime();  // get relay on time from firmware and display on UI .                                  
                                }
                                else
                                {
                                    //Failure
                                    CalibrationStatus = "Fail";

                                    if (clsGlobalVariables.IsRelayRetrydone == true)
                                    {
                                        FinalStatus = "FAIL";
                                        FnFinalStatus(false);
                                        PassStatus = false;
                                        IsPrgVis = false;
                                        StatusColorProperty = "#c62828";
                                    }
                                }
                            }

                        }
                    }
                    else
                    {
                        //Failure
                        CalibrationStatus = "Fail";

                        if (clsGlobalVariables.IsRelayRetrydone == true)
                        {
                            FinalStatus = "FAIL";
                            FnFinalStatus(false);
                            PassStatus = false;
                            IsPrgVis = false;
                            StatusColorProperty = "#c62828";
                        }
                    }
                }
                else if (rxBuff[1] == (byte)(clsEnumFunctionCode.ZCD_SelfCalibration + 0x80))
                {
                    //Failure
                    CalibrationStatus = "Fail";

                    if (clsGlobalVariables.IsRelayRetrydone == true)
                    {
                        FinalStatus = "FAIL";
                        FnFinalStatus(false);
                        PassStatus = false;
                        IsPrgVis = false;
                        StatusColorProperty = "#c62828";
                    }
                }
            }
            else
            {
                //Failure
                CalibrationStatus = "Fail";

                if (clsGlobalVariables.IsRelayRetrydone == true)
                {
                    FinalStatus = "FAIL";
                    FnFinalStatus(false);
                    PassStatus = false;
                    IsPrgVis = false;
                    StatusColorProperty = "#c62828";
                }
            }

        }


        private void RelayONTime()
        {
            byte[] TxByteArray = new byte[4];


            byte deviceId = 0xF7;


            byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.ZCD_GetRelayONTime, (byte)clsEnumReadWriteCode.Readbyte, null);

            byte[] rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ValidateResponse(txBuff, (byte)clsEnumFunctionCode.ZCD_GetRelayONTime, (byte)clsEnumReadWriteCode.Readbyte);

            if (rxBuff != null)
            {
                if (rxBuff[1] == (byte)clsEnumFunctionCode.ZCD_GetRelayONTime)
                {
                    //Success
                    float RelayOnTime = BitConverter.ToSingle(rxBuff, 4);
                    MessageBox.Show("Relay On Time = " + Convert.ToString(RelayOnTime) + "ms", "Information Window", MessageBoxButton.OK, MessageBoxImage.Information);
                    CalibrationStatus = "PASS";

                    if (!clsGlobalVariables.SelectedCatIdObj.IsSwitchPresent)
                    {
                        IsPrgVis = false;
                        FinalStatus = "PASS";
                        FnFinalStatus(true);
                        PassStatus = true;
                        StatusColorProperty = "#2e7d32";
                    }
                }
                else if (rxBuff[1] == (byte)(clsEnumFunctionCode.ZCD_GetRelayONTime + 0x80))
                {
                    //Failure
                    CalibrationStatus = "Fail";

                    if (clsGlobalVariables.IsRelayRetrydone == true)
                    {
                        FinalStatus = "FAIL";
                        FnFinalStatus(false);
                        PassStatus = false;
                        IsPrgVis = false;
                        StatusColorProperty = "#c62828";
                    }
                }
            }
            else
            {
                //Failure
                CalibrationStatus = "Fail";

                if (clsGlobalVariables.IsRelayRetrydone == true)
                {
                    FinalStatus = "FAIL";
                    FnFinalStatus(false);
                    PassStatus = false;
                    IsPrgVis = false;
                    StatusColorProperty = "#c62828";
                }

            }

        }

        //when relay retry is stopped then update failure condition.

        public void UpdatedRelayCalibFailure()
        {
            //Failure
            CalibrationStatus = "Fail";
            FinalStatus = "FAIL";
            FnFinalStatus(false);
            PassStatus = false;
            IsPrgVis = false;
            StatusColorProperty = "#c62828";

            PLCOffCommand(); //OFF PLC         
            System.Windows.Application.Current.Dispatcher.Invoke(delegate
            {
                // update UI
                tmrMbTimer.Dispose();
            });
            ShowMessageBox("Relay Calibration Failed!!!", false, "", clsGlobalVariables.MsgIcon.Message);
        }

        // Switch hardware checking.
        public static int switcherrorcnt = 0; // handle switch retry.
        private byte SwitchHardwareChecking()
        {
            try
            {
                if (clsGlobalVariables.strSwitchCalibStatus == (byte)EnmSwitchCalibrationstate.Stop)
                {
                    clsGlobalVariables.strSwitchdata = clsGlobalVariables.SelectedCatIdObj.Switchdata;
                    switcherrorcnt = 0;
                    SwitchCalibration switchCalibration = null;
                    IsPrgVis = false;

                    for (int switchcnt = 0; switchcnt <= (clsGlobalVariables.strSwitchdata + 1); switchcnt++)
                    {

                        if (switchcnt == (clsGlobalVariables.strSwitchdata + 1))
                        {
                            switchCalibration = new SwitchCalibration(0);
                        }
                        else
                        {
                            switchCalibration = new SwitchCalibration(switchcnt);
                        }

                        clsGlobalVariables.strSwitchCalibStatus = (byte)EnmSwitchCalibrationstate.SwitchCalibStarted;
                        switchCalibration.ShowDialog();

                        if (clsGlobalVariables.IsSwitchCalibFailed == true)
                        {
                            --switchcnt;

                            if (switcherrorcnt >= 2)
                            {
                                clsGlobalVariables.strSwitchCalibStatus = (byte)EnmSwitchCalibrationstate.SwitchCalibFailed;
                                clsGlobalVariables.switchcasevar = 0;
                                clsGlobalVariables.switchtestvar = 0;
                                clsGlobalVariables.SwitchCnt = 0;
                                switcherrorcnt = 0;
                                break;
                            }

                            switcherrorcnt++;
                        }
                        else
                        {
                            switcherrorcnt = 0;
                        }


                    }

                    if (clsGlobalVariables.strSwitchCalibStatus == (byte)EnmSwitchCalibrationstate.SwitchCalibCompleted)
                    {
                       WriteCalibrationStatus(clsGlobalVariables.SelectedCatIdObj);
                    }
                    else if (clsGlobalVariables.strSwitchCalibStatus == (byte)EnmSwitchCalibrationstate.SwitchCalibFailed)
                    {                       
                        FinalStatus = "FAIL";
                        FnFinalStatus(false);
                        CalibrationStatus = "Fail";
                        PassStatus = false;
                        StatusColorProperty = "#c62828";
                    }
                }

                clsGlobalVariables.strSwitchCalibStatus = (byte)EnmSwitchCalibrationstate.Stop;
                return ((byte)EnmModuleName.Stop);
            }
            catch (Exception ex)
            {
                IsPrgVis = false;
                MessageBox.Show("In Switch Hardware Checking");
                return ((byte)EnmModuleName.Stop);
            }
        }


        public void FnFinalStatus(bool status)
        {
            SuccessStatus = status;
            ErrorStatus = !status;
        }


        /// <summary>
        /// GetCalibratedLog()
        /// This function is used to create and update calibration log file.
        /// First it will check if log file exists.
        /// Second if it exist it will call "UpdateLogRangePotCalibration(catID)" to update the file, if it doesnt
        /// exist then it will call "CreateLogRangePotCalibration(catID)" to create log file and then will call 
        /// "UpdateLogRangePotCalibration(catID)" to update its data.
        /// </summary>
        /// <param name="catID"></param>
        public void GetCalibratedLog(CatIDList catID)
        {
            try
            {
                if (File.Exists(FileNameRangeCalData))
                {
                    if (!CanReadFile(FileNameRangeCalData))
                    {
                        MessageBox.Show("File is open, please close the file", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    UpdateLogRangePotCalibration(catID);
                }
                else
                {
                    CreateLogRangePotCalibration(catID);
                    UpdateLogRangePotCalibration(catID);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Log written block : " + ex.Message);
            }
        }

        //Error codes for open file
        const int ERROR_SHARING_VIOLATION = 32;
        const int ERROR_LOCK_VIOLATION = 33;


        /// <summary>
        /// IsFileLocked()
        /// This function is used to know if a file is locked to use.
        /// </summary>
        /// <param name="exception"></param>
        /// <returns></returns>
        private static bool IsFileLocked(Exception exception)
        {
            int errorCode = Marshal.GetHRForException(exception) & ((1 << 16) - 1);
            return errorCode == ERROR_SHARING_VIOLATION || errorCode == ERROR_LOCK_VIOLATION;
        }


        /// <summary>
        /// CanReadFile()
        /// This function is used to check if File is open or closed.
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        internal static bool CanReadFile(string filePath)
        {
            //Try-Catch so we dont crash the program and can check the exception
            try
            {
                //The "using" is important because FileStream implements IDisposable and
                //"using" will avoid a heap exhaustion situation when too many handles  
                //are left undisposed.
                using (FileStream fileStream = File.Open(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {
                    if (fileStream != null) fileStream.Close();  //This line is me being overly cautious, fileStream will never be null unless an exception occurs... and I know the "using" does it but its helpful to be explicit - especially when we encounter errors - at least for me anyway!
                }
            }
            catch (IOException ex)
            {
                //THE FUNKY MAGIC - TO SEE IF THIS FILE REALLY IS LOCKED!!!
                if (IsFileLocked(ex))
                {
                    // do something, eg File.Copy or present the user with a MsgBox - I do not recommend Killing the process that is locking the file
                    return false;
                }
            }
            finally
            { }
            return true;
        }



        /// <summary>
        /// WriteCalibrationStatus()
        /// This function is used to write calibration status onto the device.
        /// First the function makes a query to send calibration status to device.
        /// Second the query is sent to device and response received is validated.
        /// Third if the received response is validated then Success status is displayed on the UI,
        /// if it is invalid then FAILED status is displayed on the UI.
        /// </summary>
        /// <param name="catID"></param>
        /// <returns></returns>
        private byte WriteCalibrationStatus(CatIDList catID)
        {
            byte[] TxByteArray = new byte[1];

            if (clsGlobalVariables.CalibrationStatusflag == clsGlobalVariables.SUCCESS)
                TxByteArray[0] = 1;
            else
                TxByteArray[0] = 0;
            byte deviceId = 0xF7;

            //Function to provide data parameters to make deviceinfo query
            Thread.Sleep(2000);
            byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.CalibrationStatus, (byte)clsEnumReadWriteCode.Writebyte, TxByteArray);

            byte[] rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ValidateResponse(txBuff, (byte)clsEnumFunctionCode.CalibrationStatus, (byte)clsEnumReadWriteCode.Writebyte);
            if (rxBuff != null)
            {
                if (rxBuff[1] == (byte)clsEnumFunctionCode.CalibrationStatus)
                {
                    if ((!catID.IsZCDEnable) || (catID.IsSwitchPresent))
                    {
                        //Success
                        FinalStatus = "PASS";
                        FnFinalStatus(true);
                        PassStatus = true;
                        CalibrationStatus = "PASS";
                        StatusColorProperty = "#2e7d32";
                        ShowMessageBox("Programming and calibration completed successfully!!!", false, "", clsGlobalVariables.MsgIcon.Message);
                    }
                }
                else if (rxBuff[1] == (byte)(clsEnumFunctionCode.CalibrationStatus + 0x80))
                {
                    //Failure
                    FinalStatus = "FAIL";
                    FnFinalStatus(false);
                    CalibrationStatus = "Fail";
                    PassStatus = false;
                    StatusColorProperty = "#c62828";
                }
            }
            else
            {
                //Failure
                FinalStatus = "FAIL";
                FnFinalStatus(false);
                CalibrationStatus = "Fail";
                PassStatus = false;
                StatusColorProperty = "#c62828";
            }
            
            if (!catID.IsSwitchPresent)
            {
                if (catID.IsZCDEnable)
                {
                    return (byte)EnmModuleName.ZCDCalibration;
                }
            }
            
            PLCOffCommand(); //OFF PLC after G13 calibration
            //Dispatcher.Invoke used in multithreading. Background logic and GUI updation
            System.Windows.Application.Current.Dispatcher.Invoke(delegate
            {
                // update UI
                tmrMbTimer.Dispose();
                IsProgEnable = true;
            });
            IsPrgVis = false;
            return (byte)EnmModuleName.Stop;
            

        }
    


        /// <summary>
        /// WriteCalibrationData()
        /// This function is used to write calibration data into device after calibration process.
        /// First all the calibration data lists are padded to their full length.
        /// Second all the calibration data bytes are prepared to send to Device.
        /// Third a query frame is made to send to device.
        /// Fourth this query along with calibration data is sent to device.
        /// Fifth response received from device is validates, if it is valid then PASS status is displayed on UI, but if it is
        /// not valid then FAILED status is diaplayed on the UI.
        /// </summary>
        /// <param name="catID"></param>
        /// <returns></returns>
        private byte WriteCalibrationData(CatIDList catID)
        {
            try
            {
                int MaximumLength = 10;

                for (int Remaining = Timing1ReadDatabytes.Count; Remaining < MaximumLength; Remaining++)
                {
                    Timing1ReadDatabytes.Add(0x00);
                }
                for (int Remaining = Range1ReadDatabytes.Count; Remaining < MaximumLength; Remaining++)
                {
                    Range1ReadDatabytes.Add(0x00);
                }
                for (int Remaining = Timing2ReadDatabytes.Count; Remaining < MaximumLength + 5; Remaining++)
                {
                    Timing2ReadDatabytes.Add(0x00);
                }               
                for (int Remaining = ModeReadDatabytes.Count; Remaining < MaximumLength + 5; Remaining++)
                {
                    ModeReadDatabytes.Add(0x00);
                }
                for (int Remaining = Range2ReadDatabytes.Count; Remaining < MaximumLength; Remaining++)
                {
                    Range2ReadDatabytes.Add(0x00);
                }
                for (int Remaining = Pot4ReadDatabytes.Count; Remaining < MaximumLength; Remaining++)
                {
                    Pot4ReadDatabytes.Add(0x00);
                }

                List<byte[]> ReadDatabytesList = new List<byte[]>();
                ReadDatabytesList.Add(Timing1ReadDatabytes.ToArray());
                ReadDatabytesList.Add(Range1ReadDatabytes.ToArray());
                byte tempDataAdded = 0; 

                for (int NumberofPots = 0; NumberofPots < catID.Micon175_PotDetail.Count; NumberofPots++)
                {
                    // Timing2 or Mode pot
                    if (catID.Micon175_PotDetail[NumberofPots].PotName == "Timing2")
                    {
                        tempDataAdded += 1;
                        ReadDatabytesList.Add(Timing2ReadDatabytes.ToArray());
                    } // Range2 or Extra pot
                    else if (catID.Micon175_PotDetail[NumberofPots].PotName == "Range2")
                    {
                        tempDataAdded += 2;
                        ReadDatabytesList.Add(Range2ReadDatabytes.ToArray());
                    }
                }
                if (tempDataAdded == 1)
                {
                    ReadDatabytesList.Add(Pot4ReadDatabytes.ToArray());
                }
                else if (tempDataAdded == 2)
                {
                    ReadDatabytesList.Add(ModeReadDatabytes.ToArray());
                }
                else if (tempDataAdded == 3)
                {
                    //No need to add anything
                }
                else
                {
                    ReadDatabytesList.Add(ModeReadDatabytes.ToArray());
                    ReadDatabytesList.Add(Pot4ReadDatabytes.ToArray());
                }

                IEnumerable<byte> ReadDatabytesResult = Enumerable.Empty<byte>();

                foreach (byte[] bytes in ReadDatabytesList)
                {
                    ReadDatabytesResult = ReadDatabytesResult.Concat(bytes);
                }
                // Array created to store parameters required by Device      
                byte[] TxCompleteByteArray = ReadDatabytesResult.ToArray();

                byte deviceId = 0xF7;

                //Function to provide data parameters to make deviceinfo query

                byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.CalibrationData, (byte)clsEnumReadWriteCode.Writebyte, TxCompleteByteArray);
                               
                byte[] rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ValidateResponse(txBuff, (byte)clsEnumFunctionCode.CalibrationData, (byte)clsEnumReadWriteCode.Writebyte);


                //Logger added for debugging
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append("txBuff : ");
                for (int i = 0; i < txBuff.Length; i++)
                {
                    stringBuilder.Append(txBuff[i].ToString() + ",");
                }
                stringBuilder.AppendLine();

                stringBuilder.Append("rxBuff : ");
                for (int i = 0; i < rxBuff.Length; i++)
                {
                    stringBuilder.Append(rxBuff[i].ToString() + " ");
                }
                stringBuilder.AppendLine();

                MyLogWriterDLL.LogWriter.WriteLog("Calibration Data : ");
                MyLogWriterDLL.LogWriter.WriteLog(stringBuilder.ToString());
                //logger end

                if (rxBuff != null)
                {
                    clsGlobalVariables.CalibrationStatusflag = clsGlobalVariables.SUCCESS;
                    //FinalStatus = "PASS";

                    if (catID.IsSwitchPresent)
                    {
                        if(catID.IsZCDEnable)
                        {
                            PLCOffCommand(); //OFF PLC after G13 calibration
                            return (byte)EnmModuleName.ZCDCalibration;
                        }                   
                        else
                        {
                            return (byte)EnmModuleName.SwitchCalibration;
                        }
                        
                    }
                    else
                    {
                        return (byte)EnmModuleName.CalibrationStatus;
                    }              
                }
                else
                {
                    //Failure
                    FinalStatus = "FAIL";
                    FnFinalStatus(false);
                    CalibrationStatus = "Fail";
                    StatusColorProperty = "#c62828";
                }
                return (byte)EnmModuleName.Stop;
            }
            catch (Exception)
            {
                clsGlobalVariables.CalibrationStatusflag = clsGlobalVariables.FAILURE;
                //Failure
                FinalStatus = "FAIL";
                FnFinalStatus(false);
                CalibrationStatus = "Fail";
                StatusColorProperty = "#c62828";
                return (byte)EnmModuleName.Stop;
            }
        }


        /// <summary>
        /// AddPotCollections()
        /// This function is used to add potValues in to the pot cillection specified.
        /// First the function receives 'PotNum', 'potValues' as parameters.
        /// Second according to PotNum, switch case handels that in which collection to add potValues.
        /// </summary>
        /// <param name="PotNum"></param>
        /// <param name="potValues"></param>
        private void AddPotCollections(int PotNum, PotValues potValues)
        {
            switch (PotNum)
            {
                case 0:
                    PotValuesCollection1.Add(potValues);
                    break;
                case 1:
                    PotValuesCollection2.Add(potValues);
                    break;
                case 2:
                    PotValuesCollection3.Add(potValues);
                    break;
                case 3:
                    PotValuesCollection4.Add(potValues);
                    break;
                case 4:
                    PotValuesCollection5.Add(potValues);
                    break;
                default:
                    break;
            }
        }


        /// <summary>
        /// SelectedIndexPotInitial()
        /// This function is used to set selected index of all pots at their first index.
        /// </summary>
        private void SelectedIndexPotInitial()
        {
            SelectedIndexPot1 = 0;
            SelectedIndexPot2 = 0;
            SelectedIndexPot3 = 0;
            SelectedIndexPot4 = 0;
            SelectedIndexPot5 = 0;
        }


        /// <summary>
        /// PotToNextPosition()
        /// This function is used to increment the selected index of given pot number by 1 position.
        /// First the function receives 'potNum' as parameter.
        /// Second according to potNum switch case handels selectedIndex of which pot to be incremented.
        /// </summary>
        /// <param name="potNum"></param>
        public void PotToNextPosition(int potNum)
        {
            switch (potNum)
            {
                case 0:
                    SelectedIndexPot1++;
                    break;
                case 1:
                    SelectedIndexPot2++;
                    break;
                case 2:
                    SelectedIndexPot3++;
                    break;
                case 3:
                    SelectedIndexPot4++;
                    break;
                case 4:
                    SelectedIndexPot5++;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// RestartClicked()
        /// This function is used to set selectedIndex to its initial value and also clear collection of calibration data of specified pot.
        /// First the function receives 'potNum' as parameter.
        /// Second according to potNum, switch case handels whose selectedIndex need to be set to its initial value and collection to be cleared.
        /// </summary>
        /// <param name="potNum"></param>
        private void RestartClicked(int potNum)
        {
            switch (potNum)
            {
                case 0:
                    SelectedIndexPot1 = 0;
                    PotValuesCollection1.Clear();
                    break;
                case 1:
                    SelectedIndexPot2 = 0;
                    PotValuesCollection2.Clear();
                    break;
                case 2:
                    SelectedIndexPot3 = 0;
                    PotValuesCollection3.Clear();
                    break;
                case 3:
                    SelectedIndexPot4 = 0;
                    PotValuesCollection4.Clear();
                    break;
                case 4:
                    SelectedIndexPot5 = 0;
                    PotValuesCollection5.Clear();
                    break;
                default:
                    break;
            }
        }


        /// <summary>
        /// Function Added to filled collections of which pot is calibrating
        /// Its shows current and all previous readings on GUI by adding in collection.
        /// In failure case need to remove potvalue at same position from collection.
        /// </summary>
        /// <param name="PotNum"></param>
        /// <param name="PotPosition"></param>
        public void RemovePot(int PotNum,int PotPosition)
        {
            switch (PotNum)
            {
                case 0:   
                    if(PotValuesCollection1.Count > PotPosition)                    
                        PotValuesCollection1.RemoveAt(PotPosition);
                    break;
                case 1:
                    if (PotValuesCollection2.Count > PotPosition)
                        PotValuesCollection2.RemoveAt(PotPosition);
                    break;
                case 2:
                    if (PotValuesCollection3.Count > PotPosition)
                        PotValuesCollection3.RemoveAt(PotPosition);
                    break;
                case 3:
                    if (PotValuesCollection4.Count > PotPosition)
                        PotValuesCollection4.RemoveAt(PotPosition);
                    break;
                case 4:
                    if (PotValuesCollection5.Count > PotPosition)
                        PotValuesCollection5.RemoveAt(PotPosition);
                    break;
                default:
                    break;
            }
        }
        /// <summary>
        /// AssignTimer225DatatoPotListUi()
        /// This function is used to assign timer 225 data from json file to the pot list of selected cat id.
        /// It will assign default values of pot details.
        /// </summary>
        private void AssignTimer225DatatoPotListUi()
        {
            try
            {
                PotitemsList.Clear();
                if (SelectedDeviceName == null || SelectedDeviceName == "")
                {
                    return;
                }
                int found = 0;
                CatList catList = new CatList();
                for (int CatId = 0; CatId < Micon225CatId.Count; CatId++)
                {
                    for (int ConfigData = 0; ConfigData < Micon225CatId[CatId].Micon225ConfigData.Count; ConfigData++)
                    {
                        for (int CatList = 0; CatList < Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList.Count; CatList++)
                        {
                            if (Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList].DeviceName == SelectedDeviceName)
                            {
                                for (int PotNum = 0; PotNum < Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList].PotDetails.Count; PotNum++)
                                {
                                    catList = Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList];

                                    //ShowMessageBox("Programing and calibration voltage for selected product is " + catList.DeviceSupplyforCal + "V, please confirm", false, "", clsGlobalVariables.MsgIcon.Message);

                                    if (Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList].PotDetails[PotNum].Range != null)
                                    {
                                        clsGlobalVariables.SelectedMotPath = Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList].MotFilePath;
                                        //clsGlobalVariables.SelectedControllerType = CatId[i].ConfigData[j].CatList[z].ControllerType;
                                        //clsGlobalVariables.SelectedRFPV = CatId[i].ConfigData[j].CatList[z].RFPVersion;
                                        var data = Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList].PotDetails[PotNum].Range.Split(',');
                                        PotItems pot = new PotItems();
                                        pot.readValues = new ObservableCollection<double>();
                                        pot.rangeValues = new ObservableCollection<string>();
                                        if (data.Length != Micon225CatId[CatId].Micon225ConfigData[ConfigData].CatList[CatList].PotDetails[PotNum].NoOfPosition)
                                        {
                                            ShowMessageBox("No. of Position and Range data do not match for Pot details in json file", false, "Error", clsGlobalVariables.MsgIcon.Error);
                                            SelectedDeviceType = "";
                                            SelectedDeviceType = Micon225CatId[CatId].Micon225ConfigData[ConfigData].DeviceType;
                                            System.Console.Beep(2000, 100);
                                            return;
                                        }
                                        for (int b = 0; b < data.Length; b++)
                                        {
                                            pot.rangeValues.Add(data[b]);
                                        }
                                        PotitemsList.Add(pot);
                                    }
                                }
                                break;
                            }

                        }
                        if (found == 1) { break; }
                    }
                    if (found == 1) { break; }
                }
                int listCount = PotitemsList.Count;
                for (int c = 0; c < (5 - listCount); c++)
                {
                    PotitemsList.Add(new PotItems()
                    {
                        readValues = new ObservableCollection<double>(),
                        rangeValues = new ObservableCollection<string>()
                    });
                }
            
                UpdatePot1 = 0;
                UpdatePot2 = 0;
                UpdatePot3 = 0;
                UpdatePot4 = 0;
                UpdatePot5 = 0;

                AssignPotDetails(catList);
            }
            catch (Exception ex)
            {
                MessageBox.Show("In AssignTimer225DatatoPotListUi " +ex.ToString());
            }
        }
        /// <summary>
        /// AssignTimer175DatatoPotListUi()
        /// This function is used to assign timer 175 data from json file to the pot list of selected cat id.
        /// It will assign default values of pot details.
        /// </summary>
        private bool AssignTimer175DatatoPotListUi()
        {
            try
            {
                Micon175_PotitemsList.Clear();
                // ClearPotDetails();
                if (SelectedDeviceName == null || SelectedDeviceName == "")
                {
                    return false;
                }
                int found = 0;
                CatIDList catList = new CatIDList();
                for (int CatId = 0; CatId < Micon175_CatId.Count; CatId++)
                {
                    for (int ConfigData = 0; ConfigData < Micon175_CatId[CatId].Micon175_ConfigData.Count; ConfigData++)
                    {
                        for (int CatIDList = 0; CatIDList < Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList.Count; CatIDList++)
                        {
                            if (Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].DeviceName == SelectedDeviceName)
                            {
                                if (Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].MotFilePath == null ||
                                    Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].MotFilePath == "")
                                {
                                    DisplayPathError = true;
                                    Checkpath = "Please check given mot file path, rws file path and rpj file path in database";
                                    //ShowMessageBox("Please select mot file for programming", false, "", clsGlobalVariables.MsgIcon.Error);
                                    return false;
                                }
                                
                                clsGlobalVariables.SelectedMotPath = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].MotFilePath;
                                clsGlobalVariables.OriginalMotPath = clsGlobalVariables.SelectedMotPath;
                                clsGlobalVariables.SelectedControllerType = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].ControllerType;
                                clsGlobalVariables.SelectedRFPV = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].RFPVersion;

                                catList = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList];

                                //Desc Added
                                Descrition = catList.Description;                               
                                //if(catList.DeviceSupplyforCal != "")
                                //    ShowMessageBox("Programming and calibration voltage for selected product is "+ catList.DeviceSupplyforCal +"V, please confirm selected voltage.", false, "", clsGlobalVariables.MsgIcon.Message);
                                //else
                                //    ShowMessageBox("Programming and calibration voltage for selected product is not added", false, "", clsGlobalVariables.MsgIcon.Message);

                                //Rpj and Rws file path

                                if (catList.RpjFilePath == null || catList.RwsFilePath == null)
                                {
                                    DisplayPathError = true;
                                    Checkpath = "Please check given mot file path, rws file path and rpj file path in database";
                                    //ShowMessageBox("Please select rpj file and rws file for programing", false, "", clsGlobalVariables.MsgIcon.Error);
                                    return false;
                                }

                                DeviceSupplyforCal = catList.DeviceSupplyforCal + "V"; //Device supply added on status bar
                                DisplayPathError = false;
                                // MessageBox.Show("Please ensure all the given points in CAUTION note", "CAUTION",MessageBoxButton.OK,MessageBoxImage.Warning);
                                ShowMessageBox("CAUTION" + "\n1. Please ensure that selected CATALOG ID is as per production plan" + "   \n2. DeviceSupply : " + catList.DeviceSupplyforCal + "V", true, "SupplyValidation", clsGlobalVariables.MsgIcon.Message);
                               // Checkpath = "CAUTION"+"\n1. Please ensure that selected CATALOG ID is as per production plan"+ "   \n2. DeviceSupply : " + catList.DeviceSupplyforCal + "V";

                                clsGlobalVariables.SelectedRpjPath = catList.RpjFilePath;
                                clsGlobalVariables.SelectedRwsPath = catList.RwsFilePath;

                                //Image file path
                                strImagefilepath = catList.ImgPath;
                                //
                                for (int Pot = 0; Pot < Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].Micon175_PotDetail.Count; Pot++)
                                {
                                    if (Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].Micon175_PotDetail[Pot].Range != null)
                                    {

                                        var data = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].Micon175_PotDetail[Pot].Range.Split(',');
                                        Micon175PotItems pot = new Micon175PotItems();
                                        pot.readValues = new ObservableCollection<double>();
                                        pot.rangeValues = new ObservableCollection<string>();
                                        if (data.Length != Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIDList].Micon175_PotDetail[Pot].NoOfPosition)
                                        {
                                            ShowMessageBox("No. of Position and Range data do not match for Pot details in json file", false, "Error", clsGlobalVariables.MsgIcon.Error);
                                            SelectedDeviceType = "";
                                            SelectedDeviceType = Micon175_CatId[CatId].Micon175_ConfigData[ConfigData].DeviceType;
                                            System.Console.Beep(2000, 100);
                                            return false;
                                        }
                                        for (int Range = 0; Range < data.Length; Range++)
                                        {
                                            pot.rangeValues.Add(data[Range]);
                                        }
                                        Micon175_PotitemsList.Add(pot);
                                    }
                                }
                                
                                break;
                            }

                        }
                        if (found == 1) { break; }
                    }
                    if (found == 1) { break; }
                }
                int listCount = Micon175_PotitemsList.Count;
                for (int c = 0; c < (5 - listCount); c++)
                {
                    Micon175_PotitemsList.Add(new Micon175PotItems()
                    {
                        readValues = new ObservableCollection<double>(),
                        rangeValues = new ObservableCollection<string>()
                    });
                }
                ClearPot();
               
                UpdatePot1 = 0;
                UpdatePot2 = 0;
                UpdatePot3 = 0;
                UpdatePot4 = 0;
                UpdatePot5 = 0;
                AssignPotDetails(catList);
                clsGlobalVariables.SelectedCatIdObj = catList;
            }
            catch (Exception ex)
            {                
                MyLogWriterDLL.LogWriter.WriteLog("AssignTimer175DatatoPotListUi " + ex.ToString() );
                return false;
            }
            return true;
        }
        /// <summary>
        /// AssignPotDetails()
        /// This function is used to assign pot details after selection of cat id.
        /// Display the pot diagram and pot reading template after selection of catid.
        /// </summary>
        /// <param name="catList"></param>
        private void AssignPotDetails(CatList catList)
        {
            try
            {
                var count = catList.PotDetails.Count;
                for (int d = 0; d < (5 - count); d++)
                {
                    catList.PotDetails.Add(new PotDetail()
                    {
                        PotNumber = catList.PotDetails.Count + d,
                        NoOfPosition = 1,
                        NoPosToCal = 0,
                        Range = ""
                    });
                }

                if (catList.PotDetails[0] != null)
                {
                    UpdatePot1 = 2;
                    PointsPot1 = catList.PotDetails[0].NoOfPosition;

                    if (catList.PotDetails[0].NoPosToCal > 0)
                    {
                        IsActivePot1 = true;
                    }
                    else
                    {
                        IsActivePot1 = false;
                    }
                    if (PointsPot1 > 1)
                        UpdatePot1 = 1;
                }
                if (catList.PotDetails[1] != null)
                {
                    PointsPot2 = catList.PotDetails[1].NoOfPosition;
                    if (catList.PotDetails[1].NoPosToCal > 0)
                    {
                        IsActivePot2 = true;
                    }
                    else
                    {
                        IsActivePot2 = false;
                    }
                    if (PointsPot2 > 1)
                        UpdatePot2 = 1;
                }
                if (catList.PotDetails[2] != null)
                {
                    PointsPot3 = catList.PotDetails[2].NoOfPosition;
                    if (catList.PotDetails[2].NoPosToCal > 0)
                    {
                        IsActivePot3 = true;
                    }
                    else
                    {
                        IsActivePot3 = false;
                    }
                    if (PointsPot3 > 1)
                        UpdatePot3 = 1;
                }
                if (catList.PotDetails[3] != null)
                {
                    PointsPot4 = catList.PotDetails[3].NoOfPosition;
                    if (catList.PotDetails[3].NoPosToCal > 0)
                    {
                        IsActivePot4 = true;
                    }
                    else
                    {
                        IsActivePot4 = false;
                    }
                    if (PointsPot4 > 1)
                        UpdatePot4 = 1;
                }
                if (catList.PotDetails[4] != null)
                {
                    PointsPot5 = catList.PotDetails[4].NoOfPosition;

                    if (catList.PotDetails[4].NoPosToCal > 0)
                    {
                        IsActivePot5 = true;
                    }
                    else
                    {
                        IsActivePot5 = false;
                    }
                    if (PointsPot5 > 1)
                        UpdatePot5 = 1;
                }
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("In AssignPotDetails "+ex.ToString());
            }
        }
        /// <summary>
        /// AssignPotDetails()
        /// This function is used to display the pot diagram and pot reading template after selection of catid.
        /// After selection of cat id, it will display the pot details(Total number of pots, total number of position of each pot).
        /// If any pot contains middle mark, it will display all middle mark position on UI.
        /// </summary>
        private void AssignPotDetails(CatIDList catList)
        {
            try
            {
                if (catList.Micon175_PotDetail == null)
                {
                    IsActivePot1 = false;
                    IsActivePot2 = false;
                    IsActivePot3 = false;
                    IsActivePot4 = false;
                    IsActivePot5 = false;
                    UpdatePot1 = 0;
                    return;
                }
                clsGlobalVariables.NumberOfPots = catList.Micon175_PotDetail.Count;
                for (int count = 0; count < (5 - clsGlobalVariables.NumberOfPots); count++)
                {

                    catList.Micon175_PotDetail.Add(new Micon175PotDetail()
                    {
                        PotNumber = catList.Micon175_PotDetail.Count + count,
                        NoOfPosition = 1,
                        HexLocation = "",
                        MiddleMarkCal = false,
                        CalibApplicable = true,
                        PotType = "",
                        PotLables = "",
                        Range = ""
                    });
                }

                if (catList.Micon175_PotDetail[0] != null)
                {
                    PotName1 = catList.Micon175_PotDetail[0].PotName;
                    PointsPot1 = catList.Micon175_PotDetail[0].NoOfPosition;
                    if (catList.Micon175_PotDetail[0].MiddleMarkCal == false)
                        MiddlemarkcalPot1 = false;
                    else
                        MiddlemarkcalPot1 = true;
                    PotLables1 = catList.Micon175_PotDetail[0].PotLables;
                    if ((catList.Micon175_PotDetail[0].PotName == "Range1" && !catList.Micon175_PotDetail[0].CalibApplicable) || 
                        (catList.Micon175_PotDetail[0].PotName == "Range2" && !catList.Micon175_PotDetail[0].CalibApplicable))
                    {
                        PotName1 = "";
                        IsActivePot1 = false;
                    }
                    else
                    {
                        if (catList.Micon175_PotDetail[0].NoOfPosition > 1)
                        {
                            IsActivePot1 = true;
                        }
                        else
                        {
                            IsActivePot1 = false;
                        }
                        if (PointsPot1 > 1)
                            UpdatePot1 = 1;
                    }

                }
                if (catList.Micon175_PotDetail[1] != null)
                {
                    PotName2 = catList.Micon175_PotDetail[1].PotName;
                    PotLables2 = catList.Micon175_PotDetail[1].PotLables;
                    if (catList.Micon175_PotDetail[1].MiddleMarkCal == false)
                        MiddlemarkcalPot2 = false;
                    else
                        MiddlemarkcalPot2 = true;
                    PointsPot2 = catList.Micon175_PotDetail[1].NoOfPosition;
                    if ((catList.Micon175_PotDetail[1].PotName == "Range1" && !catList.Micon175_PotDetail[1].CalibApplicable) ||
                        (catList.Micon175_PotDetail[1].PotName == "Range2" && !catList.Micon175_PotDetail[1].CalibApplicable))
                    {
                        PotName2 = "";
                        IsActivePot2 = false;
                    }
                    else
                    {
                        if (catList.Micon175_PotDetail[1].NoOfPosition > 1)
                        {
                            IsActivePot2 = true;
                        }
                        else
                        {
                            IsActivePot2 = false;
                        }
                        if (PointsPot2 > 1)
                            UpdatePot2 = 1;
                    }
                    
                }
                if (catList.Micon175_PotDetail[2] != null)
                {
                    PotName3 = catList.Micon175_PotDetail[2].PotName;
                    PotLables3 = catList.Micon175_PotDetail[2].PotLables;
                    if (catList.Micon175_PotDetail[2].MiddleMarkCal == false)
                        MiddlemarkcalPot3 = false;
                    else
                        MiddlemarkcalPot3 = true;
                    PointsPot3 = catList.Micon175_PotDetail[2].NoOfPosition;
                    if ((catList.Micon175_PotDetail[2].PotName == "Range1" && !catList.Micon175_PotDetail[2].CalibApplicable) || 
                        (catList.Micon175_PotDetail[2].PotName == "Range2" && !catList.Micon175_PotDetail[2].CalibApplicable))
                    {
                        PotName3 = "";
                        IsActivePot3 = false;
                    }
                    else
                    {
                        if (catList.Micon175_PotDetail[2].NoOfPosition > 1)
                        {
                            IsActivePot3 = true;
                        }
                        else
                        {
                            IsActivePot3 = false;
                        }
                        if (PointsPot3 > 1)
                            UpdatePot3 = 1;
                    }
                   
                }
                if (catList.Micon175_PotDetail[3] != null)
                {
                    PotName4 = catList.Micon175_PotDetail[3].PotName;
                    PotLables4 = catList.Micon175_PotDetail[3].PotLables;
                    if (catList.Micon175_PotDetail[3].MiddleMarkCal == false)
                        MiddlemarkcalPot4 = false;
                    else
                        MiddlemarkcalPot4 = true;
                    PointsPot4 = catList.Micon175_PotDetail[3].NoOfPosition;
                    if ((catList.Micon175_PotDetail[3].PotName == "Range1" && !catList.Micon175_PotDetail[3].CalibApplicable) || 
                        (catList.Micon175_PotDetail[3].PotName == "Range2" && !catList.Micon175_PotDetail[3].CalibApplicable))
                    {
                        PotName4 = "";
                        IsActivePot4 = false;
                    }
                    else
                    {
                        if (catList.Micon175_PotDetail[3].NoOfPosition > 1)
                        {
                            IsActivePot4 = true;
                        }
                        else
                        {
                            IsActivePot4 = false;
                        }
                        if (PointsPot4 > 1)
                            UpdatePot4 = 1;
                    }
                   
                }
                if (catList.Micon175_PotDetail[4] != null)
                {
                    PotName5 = catList.Micon175_PotDetail[4].PotName;
                    PotLables5 = catList.Micon175_PotDetail[4].PotLables;
                    if (catList.Micon175_PotDetail[4].MiddleMarkCal == false)
                        MiddlemarkcalPot5 = false;
                    else
                        MiddlemarkcalPot5 = true;
                    PointsPot5 = catList.Micon175_PotDetail[4].NoOfPosition;
                    if ((catList.Micon175_PotDetail[4].PotName == "Range1" && !catList.Micon175_PotDetail[4].CalibApplicable) ||
                        (catList.Micon175_PotDetail[4].PotName == "Range2" && !catList.Micon175_PotDetail[4].CalibApplicable))
                    {
                        PotName5 = "";
                        IsActivePot5 = false;
                    }
                    else
                    {
                        if (catList.Micon175_PotDetail[4].NoOfPosition > 1)
                        {
                            IsActivePot5 = true;
                        }
                        else
                        {
                            IsActivePot5 = false;
                        }
                        if (PointsPot5 > 1)
                            UpdatePot5 = 1;
                    }
                 
                }
            }
            catch (Exception )
            {
                MyLogWriterDLL.LogWriter.WriteLog("AssignPotDetails");
            }
        }
        /// <summary>
        /// refresDataFromMicon175_File()
        /// This function is used to Read json file while loading the software and get all catid's.
        /// All catid objects will store in one global List of catid object.
        /// If any error occure while reading json file, it will return false.
        /// If json read successfully, it will return true.
        /// Read all catid's and add to devicename combobox
        /// </summary>
        /// <returns></returns>
        private bool refresDataFromMicon175_File()
        {
            try
            {
                Micon175ConfigDataList result = new Micon175ConfigDataList();
                using (StreamReader file = File.OpenText(JsonFileName1M))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                }
                Micon175_CatId.Clear();
                Micon175_CatId.Add(result);
                DeviceTypeList.Clear();
                foreach (Micon175ConfigData item in result.Micon175_ConfigData)
                {
                    DeviceTypeList.Add(item.DeviceType);
                }
                SelectedDeviceType = clsGlobalVariables.SelectedDeviceType;
                return true;
            }
            catch (Exception ex)
            {                
                return false;
            }            
        }
        /// <summary>
        /// refresDataFromMicon225_File()
        /// This function is used to Read json file while loading the software and get all catid's.
        /// All catid objects will store in one global List of catid object.
        /// If any error occure while reading json file, it will return false.
        /// If json read successfully, it will return true.
        /// Read all catid's and add to devicename combobox
        /// </summary>
        /// <returns></returns>
        private bool refresDataFromMicon225_File()
        {
            try
            {
                Micon175ConfigDataList result225 = new Micon175ConfigDataList();
                using (StreamReader file = File.OpenText(JsonFileName225))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    result225 = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                }
                Micon175_CatId.Clear();
                Micon175_CatId.Add(result225);
                DeviceTypeList.Clear();
                foreach (Micon175ConfigData item in result225.Micon175_ConfigData)
                {
                    DeviceTypeList.Add(item.DeviceType);
                }
                SelectedDeviceType = clsGlobalVariables.SelectedDeviceType;
                return true;
            }
            catch (Exception )
            {
                return false;
            }
           
        }

        /// Using this method it converted to bytes for make query and send to device.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="byte1"></param>
        /// <param name="byte2"></param>
        private void FromShortToBytes(short number, out byte byte1, out byte byte2)
        {
            byte2 = (byte)(number >> 8);
            byte1 = (byte)(number & 255);
        }
        /// <summary>
        /// Convert unsigned integer value to bytes array
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] GetBytes(uint value)
        {
            return new byte[4] {
                    (byte)(value & 0xFF),
                    (byte)((value >> 8) & 0xFF),
                    (byte)((value >> 16) & 0xFF),
                    (byte)((value >> 24) & 0xFF) };
        }
        /// <summary>
        /// Get bytes array from float value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static unsafe byte[] GetBytes(float value)
        {
            uint val = *((uint*)&value);
            return GetBytes(val);
        }

        /// <summary>
        /// OpenCatalogueDialog()
        /// This function is used to open the catalog config window, which contains all database parameters
        /// If user wants to add or change any cat id details, then after click on Catalogue config in main menu, database window will display.
        /// </summary>
        /// <param name="obj"></param>        
        private void OpenCatalogueDialog(object obj)
        {
            try
            {
                PasswordWindow passwordWindow = new PasswordWindow();
                var pwdRes = passwordWindow.ShowDialog();
                
                if(pwdRes == false)
                {
                    ShowMessageBox("Incorrect password entered!", false, "", clsGlobalVariables.MsgIcon.Error);
                    return;
                }


                if (clsGlobalVariables.IsLoggedInUserAdmin == true)
                {
                    if (IsTimer1MStarDeltaChecked)
                    {
                        Micon175_CatalogueConfig Micon175_CatalogueConfigTreeview = new Micon175_CatalogueConfig();
                        var res = Micon175_CatalogueConfigTreeview.ShowDialog();
                        if (res == false)
                        {
                            if (clsGlobalVariables.IsFileChanged)
                                ShowMessageBox("It seems you have done some changes to JSON files.\nDo you want to reflect the changes in current window ?\nWarning: All the current data will be discarded!", true, "RefreshData", clsGlobalVariables.MsgIcon.Message);
                            //refresDataFromOne_M_File();
                        }
                    }
                    else if (IsTimer225Checked)
                    {
                        ConfigDataTreeview configDataTreeview = new ConfigDataTreeview();
                        var res = configDataTreeview.ShowDialog();
                        if (res == false)
                        {
                            if (clsGlobalVariables.IsFileChanged)
                                ShowMessageBox("It seems you have done some changes to JSON files.\nDo you want to reflect the changes in current window ?\nWarning: All the current data will be discarded!", true, "RefreshData", clsGlobalVariables.MsgIcon.Message);
                            // refresDataFromTimer225_File();
                        }
                    }
                }
                else
                {
                    ShowMessageBox("You do not have permission to configure catalogue details. Please login with account having admin privileges", false, "Error", clsGlobalVariables.MsgIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("In OpenCatalogueDialog "+ex.ToString());
            }           
        }
        /// <summary>
        /// ComSettingClk()
        /// User can change the communication settings which added in menu
        /// User can select default settings
        /// User can  change com port and baudrate 
        /// </summary>
        /// <param name="obj"></param>
        private void ComSettingClk(object obj)
        {
            switch (obj)
            {
                case "DefaultSettings":
                    SelectedComPort = clsGlobalVariables.SelectedComPort;
                    SelectedBaudRate = "19200";
                    break;
                case "ChangeSettings":
                    IsProductSelected = false;
                    GetPortList();
                    SelectedComPort = clsGlobalVariables.SelectedComPort;
                    SelectedBaudRate = clsGlobalVariables.SelectedBaudRate;                 
                    ShowCommunicationSettingWindow();
                    break;
                default:
                    break;
            }
            
        }
        /// <summary>
        /// Exit the software
        /// </summary>
        /// <param name="obj"></param>
        private void ExitApp(object obj)
        {
            System.Windows.Application.Current.Shutdown();
            Environment.Exit(0);
        }
        //Showing message while change the settings
        private void changeDevice(object obj)
        {            
            ShowMessageBox("Do you want to change device settings?\nAll the settings will be reset!", true, "ChangeDevice", clsGlobalVariables.MsgIcon.Question);
        }

        /// <summary>
        /// btnOkClicked()
        /// This function is used to close dialogue box which opened as a messagebox window.
        /// After click on Ok/yes/cancel, what  action need to do, it will reflect on UI. 
        /// </summary>
        /// <param name="obj"></param>
        public void btnOkClicked(object obj)
        {
            if (obj.ToString() == "Restart")
            {               
                dialog = false;
            }
            else if (obj.ToString() == "Retry")
            {               
                dialog = false;
            }
            else if (obj.ToString() == "Ok")
            {
                if (ProductSelectionVis == true)
                {
                    SelectedDeviceNameIndex = -1;
                    ClearPotDetails();
                    DeviceNameList.Clear();
                    if (IsTimer1MStarDeltaChecked == true)
                    {
                        if (!refresDataFromMicon175_File())
                            ShowMessageBox("JSON file path not found.", false, "JsonFilenotfound", clsGlobalVariables.MsgIcon.Error);
                    }
                    else
                    {
                        if (!refresDataFromMicon225_File())
                            ShowMessageBox("JSON file path not found.", false, "JsonFilenotfound", clsGlobalVariables.MsgIcon.Error);
                    }
                    for (int devtype = 0; devtype < DeviceTypeList.Count; devtype++)
                    {
                        for (int catid = 0; catid < Micon175_CatId[0].Micon175_ConfigData[devtype].CatIDList.Count; catid++)
                        {
                            DeviceNameList.Add(Micon175_CatId[0].Micon175_ConfigData[devtype].CatIDList[catid].DeviceName);
                        }
                    }                   
                    //dialog = false;
                    SelectedDeviceName = "";                    
                    DeviceTypeError = false;
                    IsProgEnable = true;
                    //hide();
                    ShowCommunicationSettingWindow();                   
                }
                else if (ComSelectionVis == true)
                {
                    if (SelectedComPort != null && SelectedComPort != "" && SelectedBaudRate != null && SelectedBaudRate != "")
                    {                        
                        dialog = false;
                        ComPortError = false;
                        BaudRateError = false;
                        hide();
                    }
                    else
                    {
                        if (SelectedComPort == "" || SelectedComPort == null)
                        {
                            ComPortError = true;
                        }
                        if (SelectedBaudRate == "" || SelectedBaudRate == null)
                        {
                            BaudRateError = true;
                        }
                    }
                }
                else if (MesssageVis == true)
                {
                    if(Sender == "ComPortSet") //
                    {
                        dialog = false;
                        hide();
                        
                        //GetPortList();
                        //ShowCommunicationSettingWindow();
                    }  
                    else if (Sender == "JsonFilenotfound") //JsonFilenotfoumd
                    {
                        Environment.Exit(0);
                    }                    
                    else
                    {                        
                        dialog = false;
                        hide();
                    }                    
                }
                
            }
            else if (obj.ToString() == "Yes")
            {
                IsProgEnable = true;
                if(Sender == "ChangeDevice")
                {
                    ShowProductSelectionWindow();
                }
                else if (Sender == "CalibrationDoneMsg")
                {
                    SelectedIndexPot1++;
                    dialog = false;
                }
                else if (Sender == "SupplyValidation") // Device Supply and device name related confirmation and Validation added
                {
                    dialog = false;
                    hide();
                }
                else if(Sender == "RefreshData")
                {
                    if (IsTimer1MStarDeltaChecked == true)
                    {
                        if (!refresDataFromMicon175_File())
                            ShowMessageBox("JSON file path not found.", false, "JsonFilenotfound", clsGlobalVariables.MsgIcon.Error);
                    }
                    else
                    {
                        if (!refresDataFromMicon225_File())
                            ShowMessageBox("JSON file path not found.", false, "JsonFilenotfound", clsGlobalVariables.MsgIcon.Error);
                    }

                    //if (!refresDataFromMicon175_File()/* || !refresDataFromMicon225_File()*/)
                    //    ShowMessageBox("JSON file path not found.", false, "JsonFilenotfound", clsGlobalVariables.MsgIcon.Error);

                    DeviceNameList.Clear();
                    for (int devtype = 0; devtype < DeviceTypeList.Count; devtype++)
                    {
                        for (int catid = 0; catid < Micon175_CatId[0].Micon175_ConfigData[devtype].CatIDList.Count; catid++)
                        {
                            DeviceNameList.Add(Micon175_CatId[0].Micon175_ConfigData[devtype].CatIDList[catid].DeviceName);
                        }
                    }

                    Descrition = "";

                    PotName1 = "";
                    PotName2 = "";
                    PotName3 = "";
                    PotName4 = "";
                    PotName5 = "";
                    clsGlobalVariables.IsFileChanged = false;
                    
                    dialog = false;
                }
                
            }
            else if (obj.ToString() == "Cancel")
            {
                if(LoginVis == true)
                {
                    System.Windows.Application.Current.Shutdown();
                    Environment.Exit(0);
                }
                // Device Supply and device name related confirmation and Validation added
                if (Sender == "SupplyValidation") 
                {
                    SelectedDeviceName = "";
                    SelectedDeviceNameIndex = -1;
                }
                dialog = false;
                hide();
            }
            
        }
        /// <summary>
        /// Clear all pot details which showing on GUI.
        /// </summary>
        private void ClearPotDetails()
        {           
            IsActivePot1 = false;
            IsActivePot2 = false;
            IsActivePot3 = false;
            IsActivePot4 = false;
            IsActivePot5 = false;
            PointsPot1 = 1;
            PointsPot2 = 1;
            PointsPot3 = 1;
            PointsPot4 = 1;
            PointsPot5 = 1;
        }
        /// <summary>
        /// While giving message show the message box,
        /// Background is grayout/hide
        /// </summary>
        private async void hide()
        {            
            await Task.Delay(300);
            windowsize = 380;
            ComSelectionVis = false;
            MesssageVis = false;
            ProductSelectionVis = false;
            OkbtnVis = true;
            YesNoBtnVis = false;
        }
        
        /// <summary>
        /// Clease all pot reading collections which was filled while calibration
        /// This should be called for each new catid.
        /// </summary>
        public void ClearPot()
        {            
            PotValuesCollection1.Clear();
            PotValuesCollection2.Clear();
            PotValuesCollection3.Clear();
            PotValuesCollection4.Clear();
            PotValuesCollection5.Clear();

            Timing1ReadDatabytes.Clear();
            Range1ReadDatabytes.Clear();
            Timing2ReadDatabytes.Clear();
            Range2ReadDatabytes.Clear();
            ModeReadDatabytes.Clear();
            Pot4ReadDatabytes.Clear();
        }
        /// <summary>
        /// ShowMessageBox()
        /// This function is used to show required messagebox in which all messages pass as a parameter.
        /// if message show yesno type button or ok button, also added as a parameter.
        /// Which icon need to show to message
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="yesNo"></param>
        /// <param name="sender"></param>
        /// <param name="icon"></param>
        private void ShowMessageBox(string msg, bool yesNo,string sender, clsGlobalVariables.MsgIcon icon)
        {
            switch (icon)
            {
                case clsGlobalVariables.MsgIcon.Message:
                    IconMsgVis = true;
                    IconErrorVis = false;
                    IconQuestionVis = false;
                    break;
                case clsGlobalVariables.MsgIcon.Error:
                    IconMsgVis = false;
                    IconErrorVis = true;
                    IconQuestionVis = false;
                    break;
                case clsGlobalVariables.MsgIcon.Question:
                    IconMsgVis = false;
                    IconErrorVis = false;
                    IconQuestionVis = true;
                    break;
                default:
                    IconMsgVis = true;
                    IconErrorVis = false;
                    break;
            }
            YesNoBtnVis = yesNo;
            CancelBtnVis = yesNo;
            OkbtnVis = !yesNo;
            RestartBtnVis = false;
            RetryBtnVis = false;
            ComSelectionVis = false;
            MesssageVis = true;
            ProductSelectionVis = false;
            LoginVis = false;
            LoginBtnVis = false;

            AddBtnVis = false;
            AddUserVis = false;
            SaveBtnVis = false;
            EditUserVis = false;
            DeleteBtnVis = false;

            Msg = msg;
            Sender = sender;
            dialog = true;
        }
        private string ShowMessage;
        public string ShowMessage1
        {
            get
            {
                return ShowMessage;
            }
            set
            {
                ShowMessage = value;
                OnPropertyChanged("ShowMessage1");
            }
        }
        /// <summary>
        /// Show required messagebox in which all messages pass as a parameter.
        /// if message show yesno type button or ok button, also added as a parameter.
        /// Which icon need to show to message
        /// </summary>  
        private void ShowProductSelectionWindow()
        {
            YesNoBtnVis = false;
            CancelBtnVis = false;
            OkbtnVis = true;
            RestartBtnVis = false;
            RetryBtnVis = false;
            ComSelectionVis = false;
            MesssageVis = false;
            ProductSelectionVis = true;
            LoginVis = false;
            LoginBtnVis = false;

            AddBtnVis = false;
            AddUserVis = false;
            SaveBtnVis = false;
            EditUserVis = false;
            DeleteBtnVis = false;

            Sender = "ProductSelectionWindow";
            dialog = true;
        }
        /// <summary>
        /// Show Login window in which all required parameters given.
        /// Login window show Login and cancel button.
        /// Which icon need to show to message
        /// </summary>
        private void ShowLoginWindow()
        {            
            YesNoBtnVis = false;
            CancelBtnVis = true;
            OkbtnVis = false;
            RestartBtnVis = false;
            RetryBtnVis = false;
            ComSelectionVis = false;
            MesssageVis = false;
            ProductSelectionVis = false;
            LoginVis = true;
            UserNameError = false;
            PasswordError = false;
            IncorrectError = false;
            LoginBtnVis = true;

            AddBtnVis = false;
            AddUserVis = false;
            SaveBtnVis = false;
            EditUserVis = false;
            DeleteBtnVis = false;

            UserName = "";
            Password = "";
            Sender = "LoginWindow";
            dialog = true;
        }
        /// <summary>
        /// ShowCommunicationSettingWindow()
        /// This function is used to show Coominication settings window in which all required parameters given.
        /// Coominication settings window show Ok and cancel button.
        /// Which icon need to show to message
        /// </summary>
        private void ShowCommunicationSettingWindow()
        {
            YesNoBtnVis = false;
            CancelBtnVis = false;
            OkbtnVis = true;
            MesssageVis = false;
            RestartBtnVis = false;
            RetryBtnVis = false;
            LoginVis = false;
            LoginBtnVis = false;
            ProductSelectionVis = false;
            ComSelectionVis = true;

            AddBtnVis = false;
            AddUserVis = false;
            SaveBtnVis = false;
            EditUserVis = false;
            DeleteBtnVis = false;

            Sender = "CommunicationSettingWindow";
            dialog = true;
        }

        /// <summary>
        /// ShowAddUserWindow()
        /// This function is used to show Add User window in which all required parameters given.
        /// Add User window show Add and cancel button.
        /// Which icon need to show to message
        /// </summary>
        private void ShowAddUserWindow()
        {
            YesNoBtnVis = false;
            CancelBtnVis = true;
            OkbtnVis = false;
            MesssageVis = false;
            RestartBtnVis = false;
            RetryBtnVis = false;
            LoginVis = false;
            LoginBtnVis = false;
            ProductSelectionVis = false;
            ComSelectionVis = false;

            AddBtnVis = true;
            AddUserVis = true;
            SaveBtnVis = false;
            EditUserVis = false;
            DeleteBtnVis = false;

            Sender = "AddUserWindow";
            dialog = true;
        }
        /// <summary>
        /// ShowEditUserWindow()
        /// This function is used to display User Edit window in which all required parameters given.
        /// User Edit window show Edit and cancel button.
        /// Which icon need to show to message
        /// </summary>
        private void ShowEditUserWindow()
        {           
            YesNoBtnVis = false;
            CancelBtnVis = true;
            OkbtnVis = false;
            MesssageVis = false;
            RestartBtnVis = false;
            RetryBtnVis = false;
            LoginVis = false;
            LoginBtnVis = false;
            ProductSelectionVis = false;
            ComSelectionVis = false;

            AddBtnVis = false;
            AddUserVis = false;
            SaveBtnVis = true;
            EditUserVis = true;
            DeleteBtnVis = false;

            SelectedUserName = "";

            Sender = "EditUserWindow";
            dialog = true;
            
        }

        /// <summary>
        /// ShowDeleteUserWindow()
        /// This function is used to show User Delete window in which all required parameters given.
        /// User Delete window show Delete and cancel button.
        /// Which icon need to show to message
        /// </summary>
        private void ShowDeleteUserWindow()
        {
            YesNoBtnVis = false;
            CancelBtnVis = true;
            OkbtnVis = false;
            MesssageVis = false;
            RestartBtnVis = false;
            RetryBtnVis = false;
            LoginVis = false;
            LoginBtnVis = false;
            ProductSelectionVis = false;
            ComSelectionVis = false;

            AddBtnVis = false;
            AddUserVis = false;
            SaveBtnVis = false;
            EditUserVis = true;
            DeleteBtnVis = true;

            SelectedUserName = "";

            Sender = "DeleteUserWindow";
            dialog = true;

        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
      
    }

    /// <summary>
    /// DispatchService Class is used to DispatchService while calibration
    /// means at the time of calibration displaying readings on GUI
    /// Show yellow, red and green colors while calibration
    /// </summary>
    public static class DispatchService
    {
        public static void Invoke(Action action)
        {
            Dispatcher dispatchObject = Application.Current.Dispatcher;
            if (dispatchObject == null || dispatchObject.CheckAccess())
            {
                action();
            }
            else
            {
                dispatchObject.Invoke(action);
            }
        }
    }
    public class BrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string input = value as string;
            switch (input)
            {
                case "Error": return Brushes.Red;
                case "Ok": return Brushes.LightGreen;
                case "Retry":return Brushes.Yellow;
                default: return DependencyProperty.UnsetValue;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
