﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.model;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GIC_Timer_Programming_and_Calibration.viewModel
{
    public class Micon175_CatalogueConfigVM : INotifyPropertyChanged
    {

        #region Device Properties

        private string _SelectedControllerType = clsGlobalVariables.SelectedControllerType;

        public string SelectedControllerType
        {
            get { return _SelectedControllerType; }
            set
            {
                _SelectedControllerType = value;
                clsGlobalVariables.SelectedControllerType = value;

                if (value == "G10")
                {
                    HexEdition = true;
                    PWMEnable = true;
                    DeviceIDHexLocationRead = false;
                    IsRuntimeTimeEnabled = false;
                    IsRuntimeRangeEnabled = false;
                    IsRuntimeModeEnabled = false;
                }                   
                else
                {
                    HexEdition = false;
                    DeviceIDHexLocationRead = true;
                    RuntimeEnabled();
                }
                RuntimeEnabled();
                OnPropertyChanged("SelectedControllerType");
            }
        }
        private bool _HexLocationError;
        public bool HexLocationError
        {
            get { return _HexLocationError; }
            set { _HexLocationError = value; OnPropertyChanged("HexLocationError"); }
        }

        private bool _PotNameError;
        public bool PotNameError
        {
            get { return _PotNameError; }
            set { _PotNameError = value; OnPropertyChanged("PotNameError"); }
        }
        

        private object _SelectedItem;

        public object SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged("SelectedItem"); }
        }

        private string _DeviceType;

        public string DeviceType
        {
            get { return _DeviceType; }
            set { _DeviceType = value; OnPropertyChanged("DeviceType"); }
        }

        private string _SelectedRFPV = clsGlobalVariables.SelectedRFPV;

        public string SelectedRFPV
        {
            get { return _SelectedRFPV; }
            set
            {
                _SelectedRFPV = value;
                clsGlobalVariables.SelectedRFPV = value;
                OnPropertyChanged("SelectedRFPV");
            }
        }

        private string _ControllerTypevalue;

        public string ControllerTypevalue
        {
            get { return _ControllerTypevalue; }
            set
            {
                _ControllerTypevalue = value;
                if (value == "G10" && DeviceIDHexLocation == "")
                    HexLocationError = true;
                else
                    HexLocationError = false;
                OnPropertyChanged("ControllerTypevalue");
            }
        }

        private string _EditedVoltageValue;

        public string EditedVoltageValue
        {
            get { return _EditedVoltageValue; }
            set { _EditedVoltageValue = value; OnPropertyChanged("EditedVoltageValue"); }
        }
        private clsPotEdit _clsPotEdit = null;

        public clsPotEdit clsPotEdit
        {
            get { return _clsPotEdit; }
            set { _clsPotEdit = value; OnPropertyChanged("clsPotEdit"); }
        }


        private int _potNumber;

        public int potNumber
        {
            get { return _potNumber; }
            set { _potNumber = value; OnPropertyChanged("potNumber"); }
        }

        private string _potName;

        public string potName
        {
            get { return _potName; }
            set { _potName = value; OnPropertyChanged("potName"); }
        }

        private bool _IsRangePot;

        public bool IsRangePot
        {
            get { return _IsRangePot; }
            set { _IsRangePot = value; OnPropertyChanged("IsRangePot"); }
        }

        private string _Voltage;

        public string Voltage
        {
            get { return _Voltage; }
            set {
                _Voltage = value;

                if (!IsDigitsOnly(value))
                {
                    _Voltage = "6";
                    ShowMessageBox("Relay voltage should be in integer", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                }
                OnPropertyChanged("Voltage");
            }
        }

        private string _SupplyTypeList;

        public string SupplyTypeList
        {
            get { return _SupplyTypeList; }
            set { _SupplyTypeList = value; OnPropertyChanged("SupplyTypeList"); }
        }
        private string _DeviceName;

        public string DeviceName
        {
            get { return _DeviceName; }
            set
            {
                _DeviceName = value;
                OnPropertyChanged("DeviceName");
            }
        }


        private int _DeviceId;

        public int DeviceId
        {
            get { return _DeviceId; }
            set
            {
                if (value > 255)
                {
                    ShowMessageBox("Device ID should be in one byte (Integer range 0 : 255) !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    
                }
                else
                    _DeviceId = value;

                OnPropertyChanged("DeviceId");
            }
        }

        private string _DeviceIDHexLocation;

        public string DeviceIDHexLocation
        {
            get { return _DeviceIDHexLocation; }
            set
            {
                if (value != null && value != "")
                {
                    if (value.Length > 4)
                    {
                        ShowMessageBox("Device ID Hex Location should be in two bytes (Format should be : 0D80) !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);                        
                    }
                    else
                    {
                        char[] allowedChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
                        foreach (char character in value.ToUpper().ToArray())
                        {
                            if (!allowedChars.Contains(character))
                            {
                                ShowMessageBox(string.Format("'{0}' is not a hexadecimal character", character), false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                                value = value.Remove(value.Length - 1);
                                _DeviceIDHexLocation = value.ToUpper();
                                break;
                            }
                            else
                            {
                                _DeviceIDHexLocation = value.ToUpper();
                            }
                        }
                    }       
                }
                else
                {
                    _DeviceIDHexLocation = "";
                    if (HexEdition)
                        HexLocationError = true;
                    else
                        HexLocationError = false;
                }
                OnPropertyChanged("DeviceIDHexLocation");
            }
        }

        private string _DeviceSupplyforCal;

        public string DeviceSupplyforCal
        {
            get { return _DeviceSupplyforCal; }
            set { _DeviceSupplyforCal = value; OnPropertyChanged("DeviceSupplyforCal"); }
        }

        private string _DeviceSupplyforCalvalue;

        public string DeviceSupplyforCalvalue
        {
            get { return _DeviceSupplyforCalvalue; }
            set { _DeviceSupplyforCalvalue = value; OnPropertyChanged("DeviceSupplyforCalvalue"); }
        }

        private string _DeviceSupplyforCalList;

        public string DeviceSupplyforCalList
        {
            get { return _DeviceSupplyforCalList; }
            set { _DeviceSupplyforCalList = value; OnPropertyChanged("DeviceSupplyforCalList"); }
        }

        private string _VoltageList;

        public string VoltageList
        {
            get { return _VoltageList; }
            set { _VoltageList = value; OnPropertyChanged("VoltageList"); }
        }

        private string _ControllertypeList;

        public string ControllertypeList
        {
            get { return _ControllertypeList; }
            set { _ControllertypeList = value; OnPropertyChanged("ControllertypeList"); }
        }

        private string _SupplyType;

        public string SupplyType
        {
            get { return _SupplyType; }
            set { _SupplyType = value; OnPropertyChanged("SupplyType"); }
        }

        private bool _IsFixedTiming;

        public bool IsFixedTiming
        {
            get { return _IsFixedTiming; }
            set
            {
                _IsFixedTiming = value;
             
                if (value == true)
                {
                    IsFixedRangeEnabled = false;
                    RunTime_TimingChange = false;
                    RunTime_RangeChange = false;
                    IsRuntimeRangeEnabled = false;
                    IsRuntimeTimeEnabled = false;
                    for (int PotNum = 0; PotNum < PotDetails.Count; PotNum++)
                    {
                        if (PotDetails[PotNum].PotName != "Mode" && PotDetails[PotNum].PotName != null)
                        {
                            PotDetails.RemoveAt(PotNum);
                            PotNum--;
                            //NoOfPots--;
                        }
                        else
                        {
                            if(IsFixedMode)
                            {
                                PotDetails.RemoveAt(PotNum);
                                PotNum--;
                                //NoOfPots--;
                            }
                        }
                    }                    
                    IsFixedRange = false;
                    IsRuntimeRangeEnabled = false;
                    NoOfPots = PotDetails.Count;
                    FixedRange = 0;
                }
                else
                {                 
                    if (!HexEdition)
                        IsRuntimeTimeEnabled = true;
                    FixedTiming = "0";
                    object objSelected = new CatIDList();
                   
                    for (int CatId = 0; CatId < ModifiedCatId.Count; CatId++)
                    {
                        for (int ConfigData = 0; ConfigData < ModifiedCatId[CatId].Micon175_ConfigData.Count; ConfigData++)
                        {
                            for (int CatIdList = 0; CatIdList < ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList.Count; CatIdList++)
                            {
                                if (ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList].DeviceName == clsGlobalVariables.SelectedDeviceNameOfTreeView)
                                {
                                    NoOfPots = ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList].Micon175_PotDetail.Count;
                                    //AssignDataToFields(ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList], false);
                                    PotDetails.Clear();
                                    int cnt = 0;
                                    foreach (Micon175PotDetail item in ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList].Micon175_PotDetail)
                                    {
                                        cnt++;
                                        if (cnt == 1)                                        
                                            item.PotNumber = 1;
                                        else if (cnt == 2)
                                            item.PotNumber = 2;
                                        else if (cnt == 3)
                                            item.PotNumber = 3;
                                        else if(cnt == 4)
                                            item.PotNumber = 4;

                                        PotDetails.Add(item);
                                        //OriginalPotDetails.Add(item);
                                    }
                                }
                                else
                                {
                                    objSelected = null;
                                }

                            }
                            if (objSelected != null) { break; }
                        }
                        if (objSelected != null) { break; }
                    }

                    //FixedTiming = "0";
                }
                OnPropertyChanged("IsFixedTiming");
            }
        }
      
        private string _FixedTiming;

        public string FixedTiming
        {
            get { return _FixedTiming; }
            set
            {
                _FixedTiming = value;

                if (value != null &&  value != "")
                {
                    if (Convert.ToDouble(value) > 21474836 || Convert.ToDouble(value) < 0) // 2,147,483,647 / 200
                    {
                        _FixedTiming = "0";
                        ShowMessageBox("Timing range must be in between 0.1 to 2,14,74,836‬ !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    }
                }
                OnPropertyChanged("FixedTiming");
            }
        }
        

        private bool _IsFixedRange;

        public bool IsFixedRange
        {
            get { return _IsFixedRange; }
            set
            {
                _IsFixedRange = value;
               
                if (!value)
                {
                    if(!HexEdition)
                        IsRuntimeRangeEnabled = true;
                    FixedRange = 0;                   
                }
                else
                {
                    RunTime_RangeChange = false;
                    IsRuntimeRangeEnabled = false;
                    for (int cnt = 0; cnt < PotDetails.Count; cnt++)
                    {
                        if (PotDetails[cnt].PotName == "Range1")
                        {
                            PotDetails.RemoveAt(cnt);
                            NoOfPots--;
                        }
                        if (cnt < PotDetails.Count)
                        {
                            if (PotDetails[cnt].PotName == "Range2")
                            {
                                PotDetails.RemoveAt(cnt);
                                NoOfPots--;
                            }
                        }
                    }
                }
                OnPropertyChanged("IsFixedRange");
            }
        }
        

        private int _FixedRange;

        public int FixedRange
        {
            get { return _FixedRange; }
            set
            {
                _FixedRange = value;
                
                //if (value > 65500)
                //    _MentionNumber = 2,147,483,647 / 200;
                if (value > 21474836 || value < 0)
                {
                    _FixedRange = 0;
                    ShowMessageBox("Fixed range value must be between 1 to 2,14,74,836 !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                }
                OnPropertyChanged("FixedRange");
            }
        }

      
        private bool _IsFixedMode;

        public bool IsFixedMode
        {
            get { return _IsFixedMode; }
            set
            {
                _IsFixedMode = value;
              
                if (!value)
                {
                    if(!HexEdition)
                        IsRuntimeModeEnabled = true;
                    MentionMode = 0;
                }
                else
                {
                    RunTime_ModeChange = false;
                    IsRuntimeModeEnabled = false;
                    for (int cnt = 0; cnt < PotDetails.Count; cnt++)
                    {
                        if (PotDetails[cnt].PotName == "Mode")
                        {
                            PotDetails.RemoveAt(cnt);
                            NoOfPots--;
                        }
                    }
                    for (int Remainingpots = 0; Remainingpots < PotDetails.Count; Remainingpots++)
                    {
                        PotDetails[Remainingpots].PotNumber = Remainingpots + 1;
                    }
                }
                OnPropertyChanged("IsFixedMode");

            }
        }       

        private int _MentionMode;

        public int MentionMode
        {
            get { return _MentionMode; }
            set
            {
                _MentionMode = value;
               
                if (value > 10)
                    _MentionMode = 10;
                if (value > 10)
                {
                    _FixedRange = 0;
                    ShowMessageBox("Fixed Mode value must be between 0 to 10!", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                }
                OnPropertyChanged("MentionMode");
            }
        }

        private string _MotPath;

        public string MotPath
        {
            get { return _MotPath; }
            set { _MotPath = value; OnPropertyChanged("MotPath"); }
        }

        private string _RpjPath;

        public string RpjPath
        {
            get { return _RpjPath; }
            set { _RpjPath = value; OnPropertyChanged("RpjPath"); }
        }

        private string _RwsPath;

        public string RwsPath
        {
            get { return _RwsPath; }
            set { _RwsPath = value; OnPropertyChanged("RwsPath"); }
        }

        private string _ImgPath;

        public string ImgPath
        {
            get { return _ImgPath; }
            set { _ImgPath = value; OnPropertyChanged("ImgPath"); }
        }
        private string _SelectedImage;

        public string SelectedImage
        {
            get { return _SelectedImage; }
            set
            {
                _SelectedImage = value;
                ImgPath = clsGlobalVariables.SelectedImagePath + "\\" + _SelectedImage + "\\background.png";
                OnPropertyChanged("SelectedImage");
            }
        }


        private bool _IsNotEditable = false;

        public bool IsNotEditable
        {
            get { return _IsNotEditable; }
            set { _IsNotEditable = value; OnPropertyChanged("IsNotEditable"); }
        }

        private bool _IsDeviceTypeUneditable = true;

        public bool IsDeviceTypeUneditable
        {
            get { return _IsDeviceTypeUneditable; }
            set { _IsDeviceTypeUneditable = value; OnPropertyChanged("IsDeviceTypeUneditable"); }
        }

        private bool _IsDeviceNameUneditable = true;

        public bool IsDeviceNameUneditable
        {
            get { return _IsDeviceNameUneditable; }
            set { _IsDeviceNameUneditable = value; OnPropertyChanged("IsDeviceNameUneditable"); }
        }
        
        #region RuntimeEnabled
        private bool _IsRuntimeTimeEnabled = false;

        public bool IsRuntimeTimeEnabled
        {
            get { return _IsRuntimeTimeEnabled; }
            set { _IsRuntimeTimeEnabled = value; OnPropertyChanged("IsRuntimeTimeEnabled"); }
        }

        private bool _IsRuntimeRangeEnabled = false;

        public bool IsRuntimeRangeEnabled
        {
            get { return _IsRuntimeRangeEnabled; }
            set { _IsRuntimeRangeEnabled = value; OnPropertyChanged("IsRuntimeRangeEnabled"); }
        }

        private bool _IsRuntimeModeEnabled = false;

        public bool IsRuntimeModeEnabled
        {
            get { return _IsRuntimeModeEnabled; }
            set { _IsRuntimeModeEnabled = value; OnPropertyChanged("IsRuntimeModeEnabled"); }
        } 
        #endregion

        private bool _IsCheckBoxEnabled = false;

        public bool IsCheckBoxEnabled
        {
            get { return _IsCheckBoxEnabled; }
            set { _IsCheckBoxEnabled = value; OnPropertyChanged("IsCheckBoxEnabled"); }
        }

        private bool _IsFixedRangeEnabled;

        public bool IsFixedRangeEnabled
        {
            get { return _IsFixedRangeEnabled; }
            set { _IsFixedRangeEnabled = value; OnPropertyChanged("IsFixedRangeEnabled"); }
        }

        private bool _IsRangeOnOffmodeEnabled;

        public bool IsRangeOnOffmodeEnabled
        {
            get { return _IsRangeOnOffmodeEnabled; }
            set { _IsRangeOnOffmodeEnabled = value; OnPropertyChanged("IsRangeOnOffmodeEnabled"); }
        }
        

        private bool _IsG10;

        public bool IsG10
        {
            get { return _IsG10; }
            set { _IsG10 = value; OnPropertyChanged("IsG10"); }
        }
        
        private bool _IsSaveBtnVis = false;

        public bool IsSaveBtnVis
        {
            get { return _IsSaveBtnVis; }
            set { _IsSaveBtnVis = value; OnPropertyChanged("IsSaveBtnVis"); }
        }

        private bool _EditBtnVis = false;

        public bool EditBtnVis
        {
            get { return _EditBtnVis; }
            set { _EditBtnVis = value; OnPropertyChanged("EditBtnVis"); }
        }

        private bool _IsSaveDevicetypeBtnVis = false;

        public bool IsSaveDevicetypeBtnVis
        {
            get { return _IsSaveDevicetypeBtnVis; }
            set { _IsSaveDevicetypeBtnVis = value; OnPropertyChanged("IsSaveDevicetypeBtnVis"); }
        }

        private bool _IsSaveCatIdBtnVis = false;
        public bool IsSaveCatIdBtnVis
        {
            get { return _IsSaveCatIdBtnVis; }
            set { _IsSaveCatIdBtnVis = value;
                if(value == true && IsSaveBtnVis == true)
                {   }
                OnPropertyChanged("IsSaveCatIdBtnVis"); }
        }

        private bool _BrowseBtnVis = false;
        public bool BrowseBtnVis
        {
            get { return _BrowseBtnVis; }
            set { _BrowseBtnVis = value; OnPropertyChanged("BrowseBtnVis"); }
        }

        private bool _IsCatNew = false;
        public bool IsCatNew
        {
            get { return _IsCatNew; }
            set { _IsCatNew = value; OnPropertyChanged("IsCatNew"); }
        }
        
        private int _NoOfPots;
        public int NoOfPots
        {
            get { return _NoOfPots; }
            set
            {
                _NoOfPots = value;
                if (value > 5 && !IsFixedTiming)
                {                   
                    ShowMessageBox("Maximum number of pots are 5", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    _NoOfPots = 0;
                }
                else if(value > 1 && IsFixedTiming)
                {
                    ShowMessageBox("If Fixed Timing is enabled, only 1 pot allowed", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    _NoOfPots = 0;
                }
                
                if (PotDetails != null)
                {
                    if (IsFixedTiming)
                    {
                        if (NoOfPots > 0)
                        {
                            for (int cnt = 0; cnt < PotDetails.Count; cnt++)
                            {
                                if (PotDetails[cnt].PotName == "Timing1")
                                {
                                    PotDetails.RemoveAt(cnt);
                                }
                                if (PotDetails.Count > 0)
                                {
                                    if (PotDetails[cnt].PotName == "Range1")
                                    {
                                        PotDetails.RemoveAt(cnt);
                                    }
                                }

                            }
                            if (PotDetails.Count != 0)
                            {
                                _NoOfPots = PotDetails.Count;
                                if (_NoOfPots == 1 && PotDetails[0].PotName != "Mode")
                                {
                                    PotDetails.Clear();
                                    PotDetails.Add(new Micon175PotDetail() { PotNumber = 1 });
                                }
                                else
                                {
                                    _NoOfPots = PotDetails.Count;
                                    for (int Remainingpots = 0; Remainingpots < PotDetails.Count; Remainingpots++)
                                    {
                                        PotDetails[Remainingpots].PotNumber = Remainingpots + 1;
                                    }
                                }
                            }
                            else
                            {
                                _NoOfPots = 1;
                                // ShowMessageBox("Maximum number of pot is 1 while Fixed timing is checked.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                                PotDetails.Add(new Micon175PotDetail() { PotNumber = 1 });
                            }

                        }
                        else
                        {
                            _NoOfPots = 0;
                            // ShowMessageBox("Maximum number of pot is 1 while Fixed timing is checked.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                            //PotDetails.Add(new Micon175PotDetail() { PotNumber = 1 });
                            PotDetails.Clear();
                        }
                        
                        //PotDetails.Clear();
                    }
                    else
                    {
                        if (NoOfPots <= 5 && NoOfPots > 0)
                        {
                            if (PotDetails.Count > value)
                            {
                                PotDetails.Clear();
                                for (int i = 0; i < value; i++)
                                {
                                    PotDetails.Add(new Micon175PotDetail() { PotNumber = i + 1 });
                                }
                            }
                            else
                            {
                                for (int i = PotDetails.Count; i < value; i++)
                                {
                                    PotDetails.Add(new Micon175PotDetail() { PotNumber = i + 1 });
                                }
                            }
                        }
                        else
                        {
                            PotDetails.Clear();
                        }
                    }                    
                }
                OnPropertyChanged("NoOfPots");
            }
        }        

        private string _FirmwareVersion;
        public string FirmwareVersion
        {
            get { return _FirmwareVersion; }
            set
            {
                _FirmwareVersion = value;
                               
                if (value != null)
                {
                    string FwVer = "";
                    if (_FirmwareVersion.Length > 0)
                        FwVer = _FirmwareVersion.Substring(1, _FirmwareVersion.Length - 1);

                    if (FwVer != "" && FwVer != null)
                    {
                        if (IsDigitsOnly(FwVer))
                        {
                            if (Convert.ToInt32(FwVer) > 255)
                            {
                                ShowMessageBox("Firmware Version should be less than 255 !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                            }
                        }
                    }


                    if (value.Length > 4)
                    {
                        _FirmwareVersion = "0";
                        ShowMessageBox("Maximum firmware Version string length should be 4!", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    }
                }
                
                OnPropertyChanged("FirmwareVersion");

            }
        }
        private string _Description;
        public string Description
        {
            get { return _Description; }
            set
            {
                _Description = value;
                OnPropertyChanged("Description");

            }
        }

        private bool _RunTime_TimingChange = true;
        public bool RunTime_TimingChange
        {
            get { return _RunTime_TimingChange; }
            set
            {
                _RunTime_TimingChange = value;
                OnPropertyChanged("RunTime_TimingChange");

            }
        }
       
        private bool _RunTime_RangeChange = true;
        public bool RunTime_RangeChange
        {
            get { return _RunTime_RangeChange; }
            set
            {
                _RunTime_RangeChange = value;
                OnPropertyChanged("RunTime_RangeChange");
            }
        }
        private bool _RunTime_ModeChange = true;
        public bool RunTime_ModeChange
        {
            get { return _RunTime_ModeChange; }
            set
            {
                _RunTime_ModeChange = value;
                OnPropertyChanged("RunTime_ModeChange");

            }
        }
        private string _TimingChangeData;

        public string TimingChangeData
        {
            get { return _TimingChangeData; }
            set { _TimingChangeData = value; OnPropertyChanged("TimingChangeData"); }
        }


        private string _RangeChangeData;
        public string RangeChangeData
        {
            get { return _RangeChangeData; }
            set
            {
                _RangeChangeData = value;
                OnPropertyChanged("RangeChangeData");

            }
        }
                

        private string _ModeChangeData;
        public string ModeChangeData
        {
            get { return _ModeChangeData; }
            set
            {
                _ModeChangeData = value;
                OnPropertyChanged("ModeChangeData");

            }
        }

        private bool _HardwareCheck;
        public bool HardwareCheck
        {
            get { return _HardwareCheck; }
            set
            {
                _HardwareCheck = value;
                OnPropertyChanged("HardwareCheck");

            }
        }
        private string _VCCRange;
        public string VCCRange
        {
            get { return _VCCRange; }
            set
            {
                _VCCRange = value;
                OnPropertyChanged("VCCRange");

            }
        }

        private bool _VoltageCalibration;
        public bool VoltageCalibration
        {
            get { return _VoltageCalibration; }
            set
            {
                _VoltageCalibration = value;
                OnPropertyChanged("VoltageCalibration");

            }
        }

        private string _VoltageRange;
        public string VoltageRange
        {
            get { return _VoltageRange; }
            set
            {
                _VoltageRange = value;
                OnPropertyChanged("VoltageRange");

            }
        }

        private bool _PWMEnable;

        public bool PWMEnable
        {
            get { return _PWMEnable; }
            set { _PWMEnable = value; OnPropertyChanged("PWMEnable"); }
        }
        //RangeConstOnOffMode
        private bool _RangeConstOnOffMode;

        public bool RangeConstOnOffMode
        {
            get { return _RangeConstOnOffMode; }
            set { _RangeConstOnOffMode = value; OnPropertyChanged("RangeConstOnOffMode"); }
        }

        private int _RelayNumber;

        public int RelayNumber
        {
            get { return _RelayNumber; }
            set
            {
                _RelayNumber = value;

                if (value > 2 || value < 1)
                {
                    _RelayNumber = 1;
                    ShowMessageBox("Relay Number should 1 or 2", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                }

                OnPropertyChanged("RelayNumber");
            }
        }

        private int _Switchdata;

        public int Switchdata
        {
            get { return _Switchdata; }
            set
            {
                _Switchdata = value;

                if (IsSwitchPresent)
                {
                    if (value > 6 || value < 1)
                    {
                        _Switchdata = 1;
                        ShowMessageBox("Swtich present should be minimum 1 & maximum 6.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    }
                }

                OnPropertyChanged("Switchdata");
            }
        }


        private bool _RangePotRangeValidation;

        public bool RangePotRangeValidation
        {
            get { return _RangePotRangeValidation; }
            set { _RangePotRangeValidation = value; OnPropertyChanged("RangePotRangeValidation"); }
        }

        private bool _TimingPotRangeValidation;

        public bool TimingPotRangeValidation
        {
            get { return _TimingPotRangeValidation; }
            set { _TimingPotRangeValidation = value; OnPropertyChanged("TimingPotRangeValidation"); }
        }
        private bool _ModePotRangeValidation;

        public bool ModePotRangeValidation
        {
            get { return _ModePotRangeValidation; }
            set { _ModePotRangeValidation = value; OnPropertyChanged("ModePotRangeValidation"); }
        }



        #region Node
        private string[] _NodeVoltagesRange = new string[4];

        public string[] NodeVoltagesRange
        {
            get { return _NodeVoltagesRange; }
            set { _NodeVoltagesRange = value; OnPropertyChanged("NodeVoltagesRange"); }
        }

        private bool _CheckedNode1;

        public bool CheckedNode1
        {
            get { return _CheckedNode1; }
            set {
                _CheckedNode1 = value;
                Node1VtgRange = "0-0";
                OnPropertyChanged("CheckedNode1");
            }
        }

        private bool _CheckedNode2;

        public bool CheckedNode2
        {
            get { return _CheckedNode2; }
            set { _CheckedNode2 = value;
                Node2VtgRange = "0-0";
                OnPropertyChanged("CheckedNode2"); }
        }

        private bool _CheckedNode3;

        public bool CheckedNode3
        {
            get { return _CheckedNode3; }
            set { _CheckedNode3 = value;
                Node3VtgRange = "0-0";
                OnPropertyChanged("CheckedNode3"); }
        }
        private bool _CheckedNode4;

        public bool CheckedNode4
        {
            get { return _CheckedNode4; }
            set { _CheckedNode4 = value;
                Node4VtgRange = "0-0";
                OnPropertyChanged("CheckedNode4");
            }
        }

        private string _Node1VtgRange;

        public string Node1VtgRange
        {
            get { return _Node1VtgRange; }
            set
            {
                _Node1VtgRange = value;
               
                OnPropertyChanged("Node1VtgRange");
            }
        }

        private string _Node2VtgRange;

        public string Node2VtgRange
        {
            get { return _Node2VtgRange; }
            set
            {
                _Node2VtgRange = value;
                
                OnPropertyChanged("Node2VtgRange");
            }
        }

        private string _Node3VtgRange;

        public string Node3VtgRange
        {
            get { return _Node3VtgRange; }
            set
            {
                _Node3VtgRange = value;
                
                OnPropertyChanged("Node3VtgRange");
            }
        }

        private string _Node4VtgRange;

        public string Node4VtgRange
        {
            get { return _Node4VtgRange; }
            set
            {
                _Node4VtgRange = value;
               
                OnPropertyChanged("Node4VtgRange");
            }
        } 
        #endregion


        #endregion

        #region Message Related Properties
        private bool _IconMsgVis = true;

        public bool IconMsgVis
        {
            get { return _IconMsgVis; }
            set { _IconMsgVis = value; OnPropertyChanged("IconMsgVis"); }
        }

        private bool _IconErrorVis = false;

        public bool IconErrorVis
        {
            get { return _IconErrorVis; }
            set { _IconErrorVis = value; OnPropertyChanged("IconErrorVis"); }
        }

        private bool _IconQuestionVis;

        public bool IconQuestionVis
        {
            get { return _IconQuestionVis; }
            set { _IconQuestionVis = value; OnPropertyChanged("IconQuestionVis"); }
        }


        private string _Msg = "";
        public string Msg
        {
            get { return _Msg; }
            set { _Msg = value; OnPropertyChanged("Msg"); }
        }

        private bool _msgVis = true;

        public bool msgVis
        {
            get { return _msgVis; }
            set { _msgVis = value; OnPropertyChanged("msgVis"); }
        }

        private bool _PotEditVis = false;

        public bool PotEditVis
        {
            get { return _PotEditVis; }
            set { _PotEditVis = value; OnPropertyChanged("PotEditVis"); }
        }

        private bool _MessageWindowVis = false;

        public bool MessageWindowVis
        {
            get { return _MessageWindowVis; }
            set { _MessageWindowVis = value; OnPropertyChanged("MessageWindowVis"); }
        }

        private string _EventSender = "";

        public string EventSender
        {
            get { return _EventSender; }
            set { _EventSender = value; OnPropertyChanged("EventSender"); }
        }

        private string _EventParam = "";

        public string EventParam
        {
            get { return _EventParam; }
            set { _EventParam = value; OnPropertyChanged("EventParam"); }
        }

        private bool _ErrorMsgVis = false;

        public bool ErrorMsgVis
        {
            get { return _ErrorMsgVis; }
            set { _ErrorMsgVis = value; OnPropertyChanged("ErrorMsgVis"); }
        }

        private bool _MsgVis = true;

        public bool MsgVis
        {
            get { return _MsgVis; }
            set { _MsgVis = value; OnPropertyChanged("MsgVis"); }
        }

        private bool _IsZCDEnable;

        public bool IsZCDEnable
        {
            get { return _IsZCDEnable; }
            set
            {
                _IsZCDEnable = value;
                OnPropertyChanged("IsZCDEnable");
            }
        }

        private bool _IsSwitchPresent;

        public bool IsSwitchPresent
        {
            get { return _IsSwitchPresent; }
            set
            {
                _IsSwitchPresent = value;
                OnPropertyChanged("IsSwitchPresent");
            }
        }


        #endregion

        #region HexEdition Property
        /// <summary>
        /// Hexedition Get Set
        /// Check Checkbox
        /// </summary>
        private bool _HexEdition = true;
        public bool HexEdition
        {
            get { return _HexEdition; }
            set
            {
                _HexEdition = value;
                if(value == true)
                    IsG10 = false;
                else
                    IsG10 = true;
                OnPropertyChanged("HexEdition");

                object objSelected = new CatIDList();

                for (int CatId = 0; CatId < ModifiedCatId.Count; CatId++)
                {
                    for (int ConfigData = 0; ConfigData < ModifiedCatId[CatId].Micon175_ConfigData.Count; ConfigData++)
                    {
                        for (int CatIdList = 0; CatIdList < ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList.Count; CatIdList++)
                        {
                            if (ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList].DeviceName == clsGlobalVariables.SelectedDeviceNameOfTreeView)
                            {
                                if (!_HexEdition)
                                {
                                    DeviceIDHexLocation = "";
                                    HexLocationError = false;
                                    IsG10 = true;
                                    IsRangeOnOffmodeEnabled = true;
                                }
                                else
                                {
                                    IsG10 = false;
                                    IsRangeOnOffmodeEnabled = false;
                                    if (DeviceIDHexLocation == null || DeviceIDHexLocation == "")
                                        HexLocationError = true;
                                    else
                                        HexLocationError = false;

                                    objSelected = ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList];
                                    HexEditionChecked(ModifiedCatId[CatId].Micon175_ConfigData[ConfigData].CatIDList[CatIdList]);
                                    break;
                                }
                            }
                            else
                            {
                                objSelected = null;
                            }

                        }
                        if (objSelected != null) { break; }
                    }
                    if (objSelected != null) { break; }
                }

            }
        }

        private bool _DeviceIDHexLocationRead = false;

        public bool DeviceIDHexLocationRead
        {
            get { return _DeviceIDHexLocationRead; }
            set { _DeviceIDHexLocationRead = value; OnPropertyChanged("DeviceIDHexLocationRead"); }
        }

        #endregion

        #region Collections

        private ObservableCollection<string> _PottypeList = new ObservableCollection<string>() { "Smooth", "Detent" };

        public ObservableCollection<string> PottypeList
        {
            get { return _PottypeList; }
            set { _PottypeList = value; OnPropertyChanged("PottypeList"); }
        }
        
        private ObservableCollection<Micon175ConfigDataList> _CatId;

        public ObservableCollection<Micon175ConfigDataList> OriginalCatId
        {
            get { return _CatId; }
            set { _CatId = value; OnPropertyChanged("OriginalCatId"); }
        }

        private ObservableCollection<Micon175ConfigDataList> _ModifiedCatId;

        public ObservableCollection<Micon175ConfigDataList> ModifiedCatId
        {
            get { return _ModifiedCatId; }
            set { _ModifiedCatId = value; OnPropertyChanged("ModifiedCatId"); }
        }

        private ObservableCollection<string> _PotNameList = new ObservableCollection<string>() { "Timing1", "Range1","Mode","Timing2","Range2" };

        public ObservableCollection<string> PotNameList
        {
            get { return _PotNameList; }
            set { _PotNameList = value; OnPropertyChanged("PotNameList"); }
        }

        private ObservableCollection<Micon175PotDetail> _PotDetails = new ObservableCollection<Micon175PotDetail>();

        public ObservableCollection<Micon175PotDetail> PotDetails
        {
            get { return _PotDetails; }
            set { _PotDetails = value; OnPropertyChanged("PotDetails"); }
        }

        private ObservableCollection<Micon175PotDetail> _OriginalPotDetails;

        public ObservableCollection<Micon175PotDetail> OriginalPotDetails
        {
            get { return _OriginalPotDetails; }
            set { _OriginalPotDetails = value; OnPropertyChanged("OriginalPotDetails"); }
        }


        private ObservableCollection<string> _SupplyTypeLst = new ObservableCollection<string>();

        public ObservableCollection<string> SupplyTypeLst
        {
            get { return _SupplyTypeLst; }
            set
            {
                _SupplyTypeLst = value;
                OnPropertyChanged("SupplyTypeLst");
            }
        }
        private ObservableCollection<string> _VoltageLst = new ObservableCollection<string>();

        public ObservableCollection<string> VoltageLst
        {
            get { return _VoltageLst; }
            set
            {
                _VoltageLst = value;
                OnPropertyChanged("VoltageLst");
            }
        }

        private ObservableCollection<string> _ControllerTypeLst = new ObservableCollection<string>();

        public ObservableCollection<string> ControllerTypeLst
        {
            get { return _ControllerTypeLst; }
            set
            {
                _ControllerTypeLst = value;
                OnPropertyChanged("ControllerTypeLst");
            }
        }

        //private ObservableCollection<string> _ControllerTypeList = new ObservableCollection<string>() { "G10", "G13", "R8C" };

        //public ObservableCollection<string> ControllerTypeList
        //{
        //    get { return _ControllerTypeList; }
        //    set { _ControllerTypeList = value; OnPropertyChanged("ControllerTypeList"); }
        //}

        private ObservableCollection<string> _RFPVList = new ObservableCollection<string>() { "2.05"};

        public ObservableCollection<string> RFPVList
        {
            get { return _RFPVList; }
            set { _RFPVList = value; OnPropertyChanged("RFPVList"); }
        }

        private string JsonFileName = clsGlobalVariables.Micon175Jsonpath;
        private bool _IsDialogOpen = false;

        public ObservableCollection<string> cmbListOption { get; set; }
        public bool IsDialogOpen
        {
            get { return _IsDialogOpen; }
            set { _IsDialogOpen = value; OnPropertyChanged("IsDialogOpen"); }
        }

        //
        private ObservableCollection<string> _DeviceSupplyforCalLst = new ObservableCollection<string>();

        public ObservableCollection<string> DeviceSupplyforCalLst
        {
            get { return _DeviceSupplyforCalLst; }
            set { _DeviceSupplyforCalLst = value; OnPropertyChanged("DeviceSupplyforCalLst"); }
        }
         
        private ObservableCollection<string> _ImagesList = new ObservableCollection<string>(); 

        public ObservableCollection<string> ImagesList
        {
            get { return _ImagesList; }
            set { _ImagesList = value;  OnPropertyChanged("ImagesList"); }
        }


        #endregion

        #region RelayCommand
        private RelayCommand _BrowseCmd;

        public RelayCommand BrowseCmd
        {
            get { return _BrowseCmd; }
            set { _BrowseCmd = value; }
        }

        private RelayCommand _BrowseRpjCmd;

        public RelayCommand BrowseRpjCmd
        {
            get { return _BrowseRpjCmd; }
            set { _BrowseRpjCmd = value; }
        }
        private RelayCommand _BrowseRwsCmd;

        public RelayCommand BrowseRwsCmd
        {
            get { return _BrowseRwsCmd; }
            set { _BrowseRwsCmd = value; }
        }
        
        private RelayCommand _EditCatIdCmd;

        public RelayCommand EditCatIdCmd
        {
            get { return _EditCatIdCmd; }
            set { _EditCatIdCmd = value; }
        }

        private RelayCommand _DeleteCatIdCmd;

        public RelayCommand DeleteCatIdCmd
        {
            get { return _DeleteCatIdCmd; }
            set { _DeleteCatIdCmd = value; }
        }

        private RelayCommand _DeleteDeviceTypeCmd;

        public RelayCommand DeleteDeviceTypeCmd
        {
            get { return _DeleteDeviceTypeCmd; }
            set { _DeleteDeviceTypeCmd = value; }
        }


        private RelayCommand _AddCatIdCmd;

        public RelayCommand AddCatIdCmd
        {
            get { return _AddCatIdCmd; }
            set { _AddCatIdCmd = value; }
        }

        private RelayCommand _AddDeviceTypeCmd;

        public RelayCommand AddDeviceTypeCmd
        {
            get { return _AddDeviceTypeCmd; }
            set { _AddDeviceTypeCmd = value; }
        }

        private RelayCommand _SaveJsonCmd;

        public RelayCommand SaveJsonCmd
        {
            get { return _SaveJsonCmd; }
            set { _SaveJsonCmd = value; }
        }

        private RelayCommand _SaveNewDeviceTypeCmd;

        public RelayCommand SaveNewDeviceTypeCmd
        {
            get { return _SaveNewDeviceTypeCmd; }
            set { _SaveNewDeviceTypeCmd = value; }
        }

        private RelayCommand _SaveNewCatIdCmd;

        public RelayCommand SaveNewCatIdCmd
        {
            get { return _SaveNewCatIdCmd; }
            set { _SaveNewCatIdCmd = value; }
        }

        private RelayCommand _BtnYesCmd;

        public RelayCommand BtnYesCmd
        {
            get { return _BtnYesCmd; }
            set { _BtnYesCmd = value; }
        }

        private RelayCommand _BtnNoCmd;

        public RelayCommand BtnNoCmd
        {
            get { return _BtnNoCmd; }
            set { _BtnNoCmd = value; }
        }

        private RelayCommand _BtnDeletePotCmd;

        public RelayCommand BtnDeletePotCmd
        {
            get { return _BtnDeletePotCmd; }
            set { _BtnDeletePotCmd = value; }
        }


        private RelayCommand _BtnEditPotCmd;

        public RelayCommand BtnEditPotCmd
        {
            get { return _BtnEditPotCmd; }
            set { _BtnEditPotCmd = value; }
        }


        #endregion

        public System.Windows.Window currentWindow { get; set; }


        /// <summary>
        /// AssignDataToFields()
        /// This function is used to assign data to their respective fields on the UI.
        /// First this function receive 'obj', 'IsEditable' as parameters.
        /// Second this 'obj' is compared with object types, according to its type the data is extracted from it.
        /// Third all the respective data is assigned to their respective propertyies after doing validations wherever required.
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="IsEditable"></param>
        public void AssignDataToFields(object obj, bool IsEditable)
        {
            try
            {
                if (obj.GetType() == typeof(Micon175ConfigDataList))
                {
                    DeviceType = "";
                    DeviceName = "";
                    MotPath = "";
                    DeviceId = 0;
                    DeviceIDHexLocation = "";
                    DeviceSupplyforCal = "";
                    SupplyType = "";
                    NoOfPots = 1;
                    SelectedControllerType = "";
                    SelectedRFPV = "";
                    Voltage = "";
                    PotDetails.Clear();
                }
                else if (obj.GetType() == typeof(Micon175ConfigDataList))
                {
                    Micon175ConfigData objConfigData = new Micon175ConfigData();
                    objConfigData = (Micon175ConfigData)obj;
                    DeviceType = objConfigData.DeviceType;
                    DeviceName = "";
                    DeviceId = 0;
                    DeviceIDHexLocation = "";
                    DeviceSupplyforCal = "";
                    SupplyType = "";
                    NoOfPots = 1;
                    SelectedControllerType = "";
                    SelectedRFPV = "";
                    Voltage = "";
                    PotDetails.Clear();
                }
                else if (obj.GetType() == typeof(CatIDList))
                {
                    CatIDList _catList = new CatIDList();
                    _catList = (CatIDList)obj;
                    DeviceType = null;
                    PotDetails.Clear();
                    int CounterConfigData = 0;
                    while (CounterConfigData != -1)
                    {
                        int CounterDeviceType = 0;
                        while (CounterDeviceType != -1)
                        {
                            if (ModifiedCatId[0].Micon175_ConfigData[CounterConfigData].CatIDList[CounterDeviceType].DeviceName != _catList.DeviceName)
                            {
                                CounterDeviceType++;
                            }
                            else
                            {
                                DeviceType = ModifiedCatId[0].Micon175_ConfigData[CounterConfigData].DeviceType;
                                CounterDeviceType = -1;
                            }

                            if (CounterDeviceType == ModifiedCatId[0].Micon175_ConfigData[CounterConfigData].CatIDList.Count)
                            {
                                CounterDeviceType = -1;
                            }
                        }
                        if (CounterConfigData == ModifiedCatId[0].Micon175_ConfigData.Count)
                        {
                            CounterConfigData = -1;
                        }
                        else
                        {
                            if (DeviceType != null)
                            {
                                CounterConfigData = -1;
                            }
                            else
                            {
                                CounterConfigData++;
                            }
                        }
                    }
                    DeviceName = _catList.DeviceName;
                    DeviceId = _catList.DeviceId;
                    DeviceIDHexLocation = _catList.DeviceIdHexLocation;
                    MotPath = _catList.MotFilePath;
                    FirmwareVersion = _catList.FirmwareVersion;
                    Description = _catList.Description;
                    IsFixedTiming = _catList.IsFixedTiming;
                    FixedTiming = _catList.FixedTiming;
                    IsFixedRange = _catList.IsFixedRange;
                    FixedRange = _catList.MentionNumber;
                    IsFixedMode = _catList.IsFixedMode;
                    MentionMode = _catList.MentionMode;
                    HexEdition = _catList.HexEdition;
                    RunTime_TimingChange = _catList.RunTime_TimingChange;
                    RunTime_RangeChange = _catList.RunTime_RangeChange;
                    RunTime_ModeChange = _catList.RunTime_ModeChange;
                    TimingChangeData = _catList.TimingChangeData;
                    RangeChangeData = _catList.RangeChangeData;
                    ModeChangeData = _catList.ModeChangeData;
                    NoOfPots = _catList.Micon175_PotDetail.Count;                    
                    SelectedControllerType = _catList.ControllerType;
                    SelectedRFPV = _catList.RFPVersion;
                    PWMEnable = _catList.PWMEnable;
                    RangeConstOnOffMode = _catList.RangeConstOnOffMode;
                    RelayNumber = _catList.RelayNumber;
                    Switchdata = _catList.Switchdata;
                    RangePotRangeValidation = _catList.RangePotRangeValidation;
                    TimingPotRangeValidation = _catList.TimingPotRangeValidation;
                    ModePotRangeValidation = _catList.ModePotRangeValidation;
                    IsZCDEnable = _catList.IsZCDEnable;
                    IsSwitchPresent = _catList.IsSwitchPresent;
                    RwsPath = _catList.RwsFilePath;
                    RpjPath = _catList.RpjFilePath;
                    ImgPath = _catList.ImgPath;
                    if (ImgPath != null && ImgPath != "")
                    {
                        DirectoryInfo dir = new DirectoryInfo(ImgPath);
                        SelectedImage = dir.Parent.FullName.Split(new char[] { System.IO.Path.DirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries).Last();
                    }                        
                    
                    NodeVoltagesRange = _catList.NodeVoltagesRange;
                                        
                    if (NodeVoltagesRange[0] != null && NodeVoltagesRange[0] != "")
                    {
                        CheckedNode1 = true;
                        Node1VtgRange = NodeVoltagesRange[0];
                    }
                    else
                        CheckedNode1 = false;
                    if (NodeVoltagesRange[1] != null && NodeVoltagesRange[1] != "")
                    {
                        CheckedNode2 = true;
                        Node2VtgRange = NodeVoltagesRange[1];
                    }   
                    else
                        CheckedNode2 = false;
                    if (NodeVoltagesRange[2] != null && NodeVoltagesRange[2] != "")
                    {
                        CheckedNode3 = true;
                        Node3VtgRange = NodeVoltagesRange[2];
                    }
                    else
                        CheckedNode3 = false;
                    if (NodeVoltagesRange[3] != null && NodeVoltagesRange[3] != "")
                    {
                        CheckedNode4 = true;
                        Node4VtgRange = NodeVoltagesRange[3];
                    }
                    else
                        CheckedNode4 = false;

                    ControllerTypeLst.Clear();
                    //if (_catList.ControllerTypeList != null && _catList.ControllerTypeList != "")
                    //{
                    //    String[] strlist = _catList.ControllerTypeList.Split(',');
                    //    foreach (String str in strlist)
                    //    {
                    //        ControllerTypeLst.Add(str);
                    //    }
                    //}
                    ControllerTypeLst.Add("G10");
                    ControllerTypeLst.Add("G12");
                    ControllerTypeLst.Add("G13");
                    SelectedControllerType = _catList.ControllerType;
                    
                    //Fill objects
                    SupplyTypeLst.Clear();
                    
                    SupplyTypeLst.Add("AC");
                    SupplyTypeLst.Add("DC");                                  

                    SupplyType = _catList.SupplyType;

                    DeviceSupplyforCalLst.Clear();

                    //if (_catList.DeviceSupplyforCalList != null && _catList.DeviceSupplyforCalList != "")
                    //{
                    //    String[] strlist = _catList.DeviceSupplyforCalList.Split(',');
                    //    foreach (String str in strlist)
                    //    {
                    //        DeviceSupplyforCalLst.Add(str);
                    //    }
                    //}
                    DeviceSupplyforCalLst.Add("30");
                    DeviceSupplyforCalLst.Add("24");
                    DeviceSupplyforCalLst.Add("12");
                    DeviceSupplyforCalLst.Add("5");
                    DeviceSupplyforCalLst.Add("110");
                    DeviceSupplyforCalLst.Add("240");

                    DeviceSupplyforCal = _catList.DeviceSupplyforCal;
                    PotDetails.Clear();
                    //Runtime Enable/Disable Changes
                    RuntimeEnabled();

                    //Fill objects
                    VoltageLst.Clear();
                    if (_catList.RelayVoltageList != null && _catList.RelayVoltageList != "")
                    {
                        String[] strVoltage = _catList.RelayVoltageList.Split(',');
                        foreach (var vtg in strVoltage)
                        {
                            VoltageLst.Add(vtg);
                        }
                    }
                    Voltage = _catList.RelayVoltage;
                    
                    foreach (Micon175PotDetail item in _catList.Micon175_PotDetail)
                    {
                        PotDetails.Add(item);
                    }


                    if (IsEditable == true)
                    {
                        IsNotEditable = false;
                        IsDeviceTypeUneditable = true;
                        IsDeviceNameUneditable = true;
                        IsCheckBoxEnabled = true;

                        if (SelectedControllerType == "G10")
                        {
                            IsRuntimeTimeEnabled = false;
                            IsRuntimeRangeEnabled = false;
                            IsRuntimeModeEnabled = false;
                        }
                        else
                        {
                            RuntimeEnabled();
                        }

                        IsSaveBtnVis = true;
                        IsSaveCatIdBtnVis = false;
                        IsSaveDevicetypeBtnVis = false;
                        BrowseBtnVis = true;
                        EditBtnVis = true;
                    }
                    else
                    {
                        IsNotEditable = true;
                        IsRuntimeTimeEnabled = false;
                        IsRuntimeRangeEnabled = false;
                        IsRuntimeModeEnabled = false;
                        IsCheckBoxEnabled = false;
                        IsFixedRangeEnabled = false;
                        IsSaveBtnVis = false;
                        IsSaveCatIdBtnVis = false;
                        IsSaveDevicetypeBtnVis = false;
                        IsDeviceTypeUneditable = true;
                        IsDeviceNameUneditable = true;
                        BrowseBtnVis = false;
                        EditBtnVis = false;
                    }
                }
                else
                {
                    IsNotEditable = true;
                    IsSaveBtnVis = false;
                    IsCheckBoxEnabled = false;
                    IsFixedRangeEnabled = false;
                    BrowseBtnVis = false;
                    EditBtnVis = false;
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox("In AssignDataToFields " + ex.Message, false, "Error", "Error", clsGlobalVariables.MsgIcon.Error);
                MyLogWriterDLL.LogWriter.WriteLog("In AssignDataToFields"+ ex.ToString());
            }
        }


        /// <summary>
        /// IsDigitsOnly() 
        /// Check digit is string or numeric
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    return false;
            }

            return true;
        }


        /// <summary>
        /// Constructor
        /// All RelayCommands initialization 
        /// Read data from json file and add in global object
        /// </summary>
        public Micon175_CatalogueConfigVM()
        {
            try
            {
                _EditCatIdCmd = new RelayCommand(EditCatId);
                _DeleteCatIdCmd = new RelayCommand(DeleteCatId);
                _DeleteDeviceTypeCmd = new RelayCommand(DeleteDeviceType);
                _SaveJsonCmd = new RelayCommand(SaveJson);
                _SaveNewDeviceTypeCmd = new RelayCommand(SaveNewDeviceType);
                _SaveNewCatIdCmd = new RelayCommand(SaveNewCatId);
                _BrowseCmd = new RelayCommand(BrowseBtnClk);
                _BrowseRpjCmd = new RelayCommand(BrowseRpjClk);
                _BrowseRwsCmd = new RelayCommand(BrowseRwsClk);                
                _AddCatIdCmd = new RelayCommand(AddCatId);
                _AddDeviceTypeCmd = new RelayCommand(AddDeviceType);
                _BtnYesCmd = new RelayCommand(BtnYesClk);
                _BtnNoCmd = new RelayCommand(BtnNoClk);
                _BtnEditPotCmd = new RelayCommand(BtnEditPotClk);
                _BtnDeletePotCmd = new RelayCommand(BtnDeletePotClk);
                _ModifiedCatId = new ObservableCollection<Micon175ConfigDataList>();
                _CatId = new ObservableCollection<Micon175ConfigDataList>();
                _PotDetails = new ObservableCollection<Micon175PotDetail>();                
                cmbListOption = new ObservableCollection<string>() { "Reset", "Adjust" };

                Micon175ConfigDataList result = new Micon175ConfigDataList();
                using (StreamReader file = File.OpenText(JsonFileName))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                }
                OriginalCatId.Add(result);
                ModifiedCatId.Add(result);

                string[] subdirs = Directory.GetDirectories(clsGlobalVariables.SelectedImagePath);

                foreach (string subdirectory in subdirs)
                {
                    ImagesList.Add(subdirectory.Split(new char[] { System.IO.Path.DirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries).Last()); 
                }

            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("In Micon175_CatalogueConfigVM "+ex.ToString());
            }
        }

      
      
        /// <summary>
        /// BrowseRwsClk()
        /// This function is invoked when Browse RWS Path button is clicked.
        /// This function opens an open-file-dialog box to select RWS file.
        /// </summary>
        /// <param name="obj"></param>
        private void BrowseRwsClk(object obj)
        {
            OpenFileDialog od = new OpenFileDialog();
            // Set filter for file extension and default file extension
            od.DefaultExt = ".rws";
            od.Filter = "Text documents (.rws)|*.rws";

            var res = od.ShowDialog();

            if ( res != null && res != false)
            {
                RwsPath = od.FileName;
            }

        }


        /// <summary>
        /// BrowseRpjClk()
        /// This function is invoked when Browse RPJ Path button is clicked.
        /// This function opens an open-file-dialog box to select RPJ file.
        /// </summary>
        /// <param name="obj"></param>
        private void BrowseRpjClk(object obj)
        {
            OpenFileDialog dlg = new OpenFileDialog();

            // Set filter for file extension and default file extension
            dlg.DefaultExt = ".rpj";
            dlg.Filter = "Text documents (.rpj)|*.rpj";

            var res = dlg.ShowDialog();

            if (res != null && res != false)
            {
                RpjPath = dlg.FileName;
            }

        }

        /// <summary>
        /// BtnEditPotClk()
        /// This function is invoked when edit button of pot details is clicked.
        /// it calls another function "ShowPotEditWindow" to open a edit pot window.
        /// </summary>
        /// <param name="obj"></param>
        private void BtnEditPotClk(object obj)
        {
            potNumber = Convert.ToInt32(obj.ToString());

            clsPotEdit = new clsPotEdit();

            clsPotEdit.ParsePotDetails(PotDetails[potNumber-1]);
                        
            ShowPotEditWindow();            

        }


        /// <summary>
        /// BtnDeletePotClk()
        /// This function is invoked when delete button of pot details is clicked.
        /// it calls another function "ParsePotDetails" to get all details of the pot to delete.
        /// </summary>
        /// <param name="obj"></param>
        private void BtnDeletePotClk(object obj)
        {
            potNumber = Convert.ToInt32(obj.ToString());

            clsPotEdit = new clsPotEdit();

            clsPotEdit.ParsePotDetails(PotDetails[potNumber - 1]);

            ShowMessageBox("Do you want to delete selected pot ?", true, "DeletePot", "", clsGlobalVariables.MsgIcon.Question);            
        }


        /// <summary>
        /// HexEditionChecked()
        /// If Hexedition is checked, assign hexlocation bytes to their respective fields 
        /// </summary>
        /// <param name="catIDListObj"></param>
        private void HexEditionChecked(CatIDList catIDListObj)
        {
            DeviceIDHexLocation = catIDListObj.DeviceIdHexLocation;          
            
        }


        /// <summary>
        /// RuntimeEnabled()
        /// Runtime features are ebabled/disabled for fixed time, fixed range, fixed mode
        /// </summary>
        private void RuntimeEnabled()
        {
            if (!IsFixedTiming && !HexEdition)
            {
                IsRuntimeTimeEnabled = true;
            }
            else
            {
                RunTime_TimingChange = false;
                RunTime_RangeChange = false;
                IsRuntimeRangeEnabled = false;
                IsRuntimeTimeEnabled = false;
            }

            if (!IsFixedRange && !HexEdition)
                IsRuntimeRangeEnabled = true;
            else
            {
                IsRuntimeRangeEnabled = false;
                RunTime_RangeChange = false;
            }

            if (!IsFixedMode && !HexEdition)
                IsRuntimeModeEnabled = true;
            else
            {
                IsRuntimeModeEnabled = false;
                RunTime_ModeChange = false;
            }
                
        }


        /// <summary>
        /// AddCatId()
        /// This function is invoked when Add CATID button is clicked on the UI.
        /// This function is used to add new catalogue id to the list and 
        /// intialize all of its properties
        /// </summary>
        /// <param name="obj"></param>
        private void AddCatId(object obj)
        {            
            Console.Beep(1000, 100); 
            IsCatNew = true;
            EditBtnVis = true;
            DeviceType = obj.ToString();
            IsNotEditable = false;
            IsSaveBtnVis = false;
            IsCheckBoxEnabled = true;
            ControllerTypeLst.Clear();
            ControllerTypeLst.Add("G10");
            ControllerTypeLst.Add("G12");
            ControllerTypeLst.Add("G13");
            if (SelectedControllerType == "G10")
            {
                IsRuntimeTimeEnabled = false;
                IsRuntimeRangeEnabled = false;
                IsRuntimeModeEnabled = false;
            }
            else
            {
                RuntimeEnabled();
            }
            IsSaveCatIdBtnVis = true;
            IsSaveDevicetypeBtnVis = false;
            IsDeviceTypeUneditable = true;
            IsDeviceNameUneditable = false;
            DeviceId = 0;
            DeviceName = "";
            MotPath = "";
            DeviceSupplyforCal = "";
            DeviceSupplyforCalLst.Clear();
            DeviceSupplyforCalLst.Add("30");
            DeviceSupplyforCalLst.Add("24");
            DeviceSupplyforCalLst.Add("12");
            DeviceSupplyforCalLst.Add("5");
            DeviceSupplyforCalLst.Add("110");
            DeviceSupplyforCalLst.Add("240");
            IsFixedTiming = false;
            RunTime_TimingChange = false;
            RunTime_RangeChange = false;
            RunTime_ModeChange = false;
            FixedTiming = "0";
            IsFixedMode = false;
            MentionMode = 0;
            IsFixedRange = false;
            FixedRange = 0;
            NoOfPots = 1;
            RelayNumber = 1;
            Switchdata = 1 ; 
            Voltage = "";
            VoltageLst.Clear();            
            BrowseBtnVis = true;
            EditBtnVis = true;
        }


        /// <summary>
        /// AddDeviceType()
        /// This function is invoked when Add Device Type button is clicked on the UI.
        /// This function is used to add new device type to the list.
        /// </summary>
        /// <param name="obj"></param>
        private void AddDeviceType(object obj)
        {            
            Console.Beep(1000, 100); 
            IsNotEditable = true;
            IsSaveBtnVis = false;
            IsDeviceTypeUneditable = false;
            IsCheckBoxEnabled = false;
            IsRuntimeTimeEnabled = false;
            IsRuntimeRangeEnabled = false;
            IsRuntimeModeEnabled = false;
            IsDeviceNameUneditable = true;
            IsSaveCatIdBtnVis = false;
            IsSaveDevicetypeBtnVis = true;
            DeviceType = "";
            DeviceId = 0;
            DeviceName = "";
            MotPath = "";
            DeviceSupplyforCal = "";
            //SupplyType = "";
            //SupplyTypeLst.Clear();
            RunTime_TimingChange = false;
            RunTime_RangeChange = false;
            RunTime_ModeChange = false;
            IsFixedTiming = false;
            FixedTiming = "0";
            IsFixedMode = false;
            MentionMode = 0;
            IsFixedRange = false;
            FixedRange = 0;
            NoOfPots = 1;
            Voltage = "";
            VoltageLst.Clear();            
            DeviceSupplyforCalLst.Clear();
            BrowseBtnVis = false;
            EditBtnVis = false;
        }


        /// <summary>
        /// BrowseBtnClk()
        /// This function is invoked when Browse MOT file path button is clicked on the UI.
        /// This function is used to open an open-file-dialog box to select MOT/Hex file.
        /// </summary>
        /// <param name="obj"></param>
        private void BrowseBtnClk(object obj)
        {
            OpenFileDialog od = new OpenFileDialog();

            var res = od.ShowDialog();
            
            if ( res != null && res != false)
            {
                MotPath = od.FileName;
            }
        }


        /// <summary>
        /// SaveNewCatId()
        /// This function is invoked when Save CATID button is clicked on the UI.
        /// This function is used to open a confirm dialog box to save the data ino the file.
        /// </summary>
        /// <param name="obj"></param>
        private void SaveNewCatId(object obj)
        {
            if (!ValidationOnSave())
            {
                return;
            }           

            foreach (Micon175ConfigData item in ModifiedCatId[0].Micon175_ConfigData)
            {
                foreach (CatIDList cat in item.CatIDList)
                {
                    if (cat.DeviceName == DeviceName)
                    {
                        ShowMessageBox("Device Name Already exist!\nPlease use another device name.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);                        
                        return;
                    }
                }
            }
            if (DeviceName == null || DeviceName == "")
            {
                ShowMessageBox("Device Name can't be empty !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
            }
            else
            {
                ShowMessageBox("Do you want to save the changes?",true, "SaveNewCatId","", clsGlobalVariables.MsgIcon.Question);                
            }
        }

        private bool ValidationOnSave()
        {
            //Validation added for the G10 controller
            if (SelectedControllerType == "" || SelectedControllerType == null)
            {
                ShowMessageBox("Please select required Controller Type.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
            else if (SelectedControllerType == "G10")
            {
                if (DeviceIDHexLocation == "" || DeviceIDHexLocation == null)
                {
                    ShowMessageBox("Please enter correct DeviceID HexLocation for G10 controller.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    return false;
                }
                else if (DeviceIDHexLocation.Length != 4)
                {
                    ShowMessageBox("Please enter correct DeviceID HexLocation for G10 controller.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    return false;
                }
            }

            if (DeviceSupplyforCal == "" || DeviceSupplyforCal == null)
            {
                ShowMessageBox("Please select required Device Supply.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
            if (Voltage == "" || Voltage == null)
            {
                ShowMessageBox("Please enter required relay voltage", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
            if (FirmwareVersion == "" || FirmwareVersion == null)
            {
                ShowMessageBox("Please enter correct firmware version", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
            if (MotPath == "" || MotPath == null)
            {
                ShowMessageBox("Please select mot file path", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }

            if (Description == null || Description == "")
            {
                ShowMessageBox("Please enter description while adding or editing catid details", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }

            if (RwsPath == "" || RwsPath == null)
            {
                ShowMessageBox("Please select RWS file path", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
            if (RpjPath == "" || RpjPath == null)
            {
                ShowMessageBox("Please select RPJ file path", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                return false;
            }
            if (IsFixedTiming)
            {
                if (FixedTiming == "" || FixedTiming == "0")
                {
                    ShowMessageBox("Please enter required Fixed Timing.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    return false;
                }
            }
            if (IsFixedRange)
            {
                if (FixedRange == 0)
                {
                    ShowMessageBox("Please enter required Fixed range.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                    return false;
                }
            }

            if (PotDetails != null)
            {
                int ccn = NoOfPots;
                for (int potcnt = 0; potcnt < PotDetails.Count; potcnt++)
                {
                    if (PotDetails[potcnt].PotName == "" || PotDetails[potcnt].PotName == null)
                    {
                        ShowMessageBox("Please enter all required Pot details.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                        return false;
                    }
                    if (PotDetails[potcnt].NoOfPosition < 1)
                    {
                        ShowMessageBox("Please enter all required Pot details.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                        return false;
                    }
                }
            }

            if (IsSwitchPresent &&  Switchdata == 0)
            {
                ShowMessageBox("Please enter switch count between 1 to 6.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                Switchdata = 1;
                return false;
            }
            
            return true;
        }

        /// <summary>
        /// SaveNewCatId()
        /// This function is used to save the new CATID into the json file.
        /// First all the properties that user provided are validated.
        /// Second if all are valid then all the data is searialize and written into JSON file.
        /// </summary>
        private void SaveNewCatId()
        {
            try
            {
                SupplyTypeList = "";
                for (int i = 0; i < SupplyTypeLst.Count; i++)
                {
                    if (SupplyTypeLst.Count - 1 > i)
                        SupplyTypeList = SupplyTypeList + SupplyTypeLst[i] + ",";
                    else
                        SupplyTypeList = SupplyTypeList + SupplyTypeLst[i];
                }

                if (!VoltageLst.Contains(EditedVoltageValue))
                    VoltageLst.Add(EditedVoltageValue);
                VoltageList = "";
                for (int i = 0; i < VoltageLst.Count; i++)
                {
                    if (VoltageLst.Count - 1 > i)
                        VoltageList = VoltageList + VoltageLst[i] + ",";
                    else
                        VoltageList = VoltageList + VoltageLst[i];
                }
                if (!ControllerTypeLst.Contains(ControllerTypevalue))
                    ControllerTypeLst.Add(ControllerTypevalue);

                ControllertypeList = "";

                for (int i = 0; i < ControllerTypeLst.Count; i++)
                {
                    if (ControllerTypeLst.Count - 1 > i)
                        ControllertypeList = ControllertypeList + ControllerTypeLst[i] + ",";
                    else
                        ControllertypeList = ControllertypeList + ControllerTypeLst[i];
                }


                if (!DeviceSupplyforCalLst.Contains(DeviceSupplyforCalvalue))
                    DeviceSupplyforCalLst.Add(DeviceSupplyforCalvalue);
                DeviceSupplyforCalList = "";
                for (int i = 0; i < DeviceSupplyforCalLst.Count; i++)
                {
                    if (DeviceSupplyforCalLst.Count - 1 > i)
                        DeviceSupplyforCalList = DeviceSupplyforCalList + DeviceSupplyforCalLst[i] + ",";
                    else
                        DeviceSupplyforCalList = DeviceSupplyforCalList + DeviceSupplyforCalLst[i];
                }
                IsCheckBoxEnabled = false;
                
                //Node validation
                if (CheckedNode1)
                {
                    if (Node1VtgRange != null)
                        NodeVoltagesRange[0] = Node1VtgRange;
                    else
                    {
                        MessageBox.Show("Couldn't save catid info, please enter node1 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        CheckedNode1 = false;
                        //ShowMessageBox("Couldn't save catid info, please enter node1 voltage range", false, "", "", clsGlobalVariables.MsgIcon.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[0] = "";
                if (CheckedNode2)
                {
                    if (Node2VtgRange != null)
                        NodeVoltagesRange[1] = Node2VtgRange;
                    else
                    {
                        CheckedNode2 = false;
                        MessageBox.Show("Couldn't save catid info, please enter node2 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[1] = "";
                if (CheckedNode3)
                {
                    if (Node3VtgRange != null)
                        NodeVoltagesRange[2] = Node3VtgRange;
                    else
                    {
                        CheckedNode3 = false;
                        MessageBox.Show("Couldn't save catid info, please enter node3 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[2] = "";
                if (CheckedNode4)
                {
                    if (Node4VtgRange != null)
                        NodeVoltagesRange[3] = Node4VtgRange;
                    else
                    {
                        CheckedNode4 = false;
                        MessageBox.Show("Couldn't save catid info, please enter node4 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[3] = "";

                CatIDList NewCatList = new CatIDList()
                {
                    DeviceId = DeviceId,
                    DeviceName = DeviceName,
                    Description = Description,
                    DeviceSupplyforCal = DeviceSupplyforCalvalue,
                    DeviceSupplyforCalList = DeviceSupplyforCalList,
                    SupplyType = SupplyType,
                    SupplyTypeList = SupplyTypeList,
                    IsFixedTiming = IsFixedTiming,
                    FixedTiming = FixedTiming,
                    IsFixedMode = IsFixedMode,
                    MentionMode = MentionMode,
                    IsFixedRange = IsFixedRange,
                    MentionNumber = FixedRange,
                    RunTime_TimingChange = RunTime_TimingChange,
                    RunTime_RangeChange = RunTime_RangeChange,
                    RunTime_ModeChange = RunTime_ModeChange,
                    FirmwareVersion = FirmwareVersion,
                    HardwareCheck = HardwareCheck,
                    HexEdition = HexEdition,
                    ModeChangeData = ModeChangeData,
                    RangeChangeData = RangeChangeData,
                    TimingChangeData = TimingChangeData,
                    VCCRange = VCCRange,
                    VoltageCalibration = VoltageCalibration,
                    VoltageRange = VoltageRange,
                    DeviceIdHexLocation = DeviceIDHexLocation,
                    MotFilePath = MotPath,
                    Micon175_PotDetail = PotDetails,
                    ControllerType = ControllerTypevalue,
                    ControllerTypeList = ControllertypeList,
                    RFPVersion = SelectedRFPV,
                    RelayVoltage = Voltage,
                    RelayVoltageList = VoltageList,
                    PWMEnable = PWMEnable,
                    RangeConstOnOffMode = RangeConstOnOffMode,
                    RelayNumber = RelayNumber,
                    Switchdata = Switchdata,
                    RangePotRangeValidation = RangePotRangeValidation,
                    TimingPotRangeValidation = TimingPotRangeValidation,
                    ModePotRangeValidation = ModePotRangeValidation,
                    NodeVoltagesRange = NodeVoltagesRange,
                    RwsFilePath = RwsPath,
                    RpjFilePath = RpjPath,
                    ImgPath = ImgPath,
                    IsZCDEnable = IsZCDEnable,
                    IsSwitchPresent= IsSwitchPresent,
                };
                                
                int found = 0;
                for (int Countercatid = 0; Countercatid < ModifiedCatId.Count; Countercatid++)
                {
                    for (int CounterConfigData = 0; CounterConfigData < ModifiedCatId[Countercatid].Micon175_ConfigData.Count; CounterConfigData++)
                    {
                        if (ModifiedCatId[Countercatid].Micon175_ConfigData[CounterConfigData].DeviceType == DeviceType)
                        {
                            //ModifiedCatId[i].ConfigData[j].CatList.RemoveAt(z);
                            ModifiedCatId[Countercatid].Micon175_ConfigData[CounterConfigData].CatIDList.Add(NewCatList);
                            found = 1;
                            IsSaveBtnVis = false;
                            IsSaveCatIdBtnVis = false;
                            IsSaveDevicetypeBtnVis = false;
                            // serialize JSON directly to a file
                            string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                            System.IO.File.WriteAllText(JsonFileName, res);
                            ModifiedCatId.Clear();
                            Micon175ConfigDataList result = new Micon175ConfigDataList();
                            using (StreamReader file = File.OpenText(JsonFileName))
                            {
                                JsonSerializer serializer = new JsonSerializer();
                                result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                            }
                            ModifiedCatId.Add(result);
                            IsCatNew = false;
                            break;
                        }
                    }
                    if (found == 1) { break; }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In SaveNewCatId : " + ex.Message);
            }
        }


        /// <summary>
        /// DeleteCatID()
        /// This function is used to delete specified CATID from the JSON file.
        /// First the specified CATID is found in the JSON file.
        /// Second that CATID is then removed from the list.
        /// Third the updated list is serialized and written back into JSON file.
        /// </summary>
        /// <param name="DeviceName"></param>
        private void DeleteCatID(string DeviceName)
        {
            int found = 0;
            for (int Countercatid = 0; Countercatid < ModifiedCatId.Count; Countercatid++)
            {
                for (int CounterConfigData = 0; CounterConfigData < ModifiedCatId[Countercatid].Micon175_ConfigData.Count; CounterConfigData++)
                {
                    for (int CounterCatIdList = 0; CounterCatIdList < ModifiedCatId[Countercatid].Micon175_ConfigData[CounterConfigData].CatIDList.Count; CounterCatIdList++)
                    {
                        if (ModifiedCatId[Countercatid].Micon175_ConfigData[CounterConfigData].CatIDList[CounterCatIdList].DeviceName == DeviceName)
                        {
                            ModifiedCatId[Countercatid].Micon175_ConfigData[CounterConfigData].CatIDList.RemoveAt(CounterCatIdList);

                            found = 1;
                            // serialize JSON directly to a file
                            string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                            System.IO.File.WriteAllText(JsonFileName, res);
                            ModifiedCatId.Clear();
                            Micon175ConfigDataList result = new Micon175ConfigDataList();
                            using (StreamReader file = File.OpenText(JsonFileName))
                            {
                                JsonSerializer serializer = new JsonSerializer();
                                result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                            }
                            ModifiedCatId.Add(result);
                            break;
                        }

                    }
                    if (found == 1) { break; }
                }
                if (found == 1) { break; }
            }
        }


        /// <summary>
        /// DeleteCatId()
        /// This function is used to show confirmation message box
        /// user need to confirm , delete or cancel</summary>
        /// <param name="obj"></param>
        private void DeleteCatId(object obj)
        {
            
            Console.Beep(1000, 100); 
            BrowseBtnVis = false;
            EditBtnVis = false;

            ShowMessageBox("Do you want to delete Catalogue Id: " + obj.ToString() + " ?", true, "DeleteCatId", obj.ToString(), clsGlobalVariables.MsgIcon.Question);
            
        }


        /// <summary>
        /// SaveNewDeviceType()
        /// This function is used to show confirmation message box
        /// user need to confirm , Add or ignore</summary>
        /// <param name="obj"></param>
        private void SaveNewDeviceType(object obj)
        {
            
            BrowseBtnVis = false;
            EditBtnVis = false;
            foreach (Micon175ConfigData item in ModifiedCatId[0].Micon175_ConfigData)
            {
                if (item.DeviceType == DeviceType)
                {
                    ShowMessageBox("Device Type Already exist!\nPlease use another device type name.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);                    
                    return;
                }
            }
            if (DeviceType == null || DeviceType == "")
            {
                ShowMessageBox("Device Type can't be empty !", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
            }
            else
            {
                ShowMessageBox("Do you want to save the changes?",true, "SaveNewDeviceType","", clsGlobalVariables.MsgIcon.Question);
            }
        }

        /// <summary>
        /// SaveNewDeviceType()
        /// This function is used to save new Devicetype to the list.
        /// First the object containing all the properties of device is added to the list.
        /// Second the list is serialized and written to JSON file.
        /// </summary>
        private void SaveNewDeviceType()
        {
            try
            {
                Micon175ConfigData NewDeviceType = new Micon175ConfigData()
                {
                    DeviceType = DeviceType,
                    CatIDList = new ObservableCollection<CatIDList>()
                };
                ModifiedCatId[0].Micon175_ConfigData.Add(NewDeviceType);
                IsSaveBtnVis = false;
                IsSaveCatIdBtnVis = false;
                IsSaveDevicetypeBtnVis = false;
                string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                System.IO.File.WriteAllText(JsonFileName, res);
                ModifiedCatId.Clear();
                Micon175ConfigDataList result = new Micon175ConfigDataList();
                using (StreamReader file = File.OpenText(JsonFileName))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                }
                ModifiedCatId.Add(result);
            }
            catch (Exception ex)
            {
                MessageBox.Show("In SaveNewDeviceType : " + ex.Message);
            }
        }


        /// <summary>
        /// SaveJson()
        /// This function is invoked when Save button is clicked on the UI.
        /// It checks if deviceName is already in use or not.
        /// This function opens a confirm dialog box.
        /// </summary>
        /// <param name="obj"></param>
        private void SaveJson(object obj)
        {
            //Validation added for the G10 controller
            if (!ValidationOnSave())
            {
                return;
            }
            foreach (Micon175ConfigData item in ModifiedCatId[0].Micon175_ConfigData)
            {
                foreach (CatIDList cat in item.CatIDList)
                {
                    if (cat.DeviceName == DeviceName && IsDeviceNameUneditable == false)
                    {
                        ShowMessageBox("Device Name Already exist!\nPlease use another device name.", false, "Error", "", clsGlobalVariables.MsgIcon.Error);
                        
                        return;
                    }
                }
            }

            ShowMessageBox("Do you want to save the changes?",true, "SaveEditedJson","", clsGlobalVariables.MsgIcon.Question);
           
            //MessageBoxResult dialogResult = MessageBox.Show("Do you want to save the changes?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            //if (dialogResult != MessageBoxResult.Yes)
            //{
            //    return;
            //}
        }


        /// <summary>
        /// SaveEditiedJson()
        /// This function is used to save the whole modified catalouge list to JSON file.
        /// After click on save button , software shows confirmation message, 
        /// after confirm this function gets called to save edited data.
        /// </summary>
        private void SaveEditedJson()
        {
            try
            {
                SupplyTypeList = "";
                for (int i = 0; i < SupplyTypeLst.Count; i++)
                {
                    if (SupplyTypeLst.Count - 1 > i)
                        SupplyTypeList = SupplyTypeList + SupplyTypeLst[i] + ",";
                    else
                        SupplyTypeList = SupplyTypeList + SupplyTypeLst[i];
                }

                if (!VoltageLst.Contains(EditedVoltageValue))
                    VoltageLst.Add(EditedVoltageValue);
                VoltageList = "";
                for (int i = 0; i < VoltageLst.Count; i++)
                {
                    if (VoltageLst.Count - 1 > i)
                        VoltageList = VoltageList + VoltageLst[i] + ",";
                    else
                        VoltageList = VoltageList + VoltageLst[i];
                }

                if (!ControllerTypeLst.Contains(ControllerTypevalue))
                    ControllerTypeLst.Add(ControllerTypevalue);
                ControllertypeList = "";
                for (int i = 0; i < ControllerTypeLst.Count; i++)
                {
                    if (ControllerTypeLst.Count - 1 > i)
                        ControllertypeList = ControllertypeList + ControllerTypeLst[i] + ",";
                    else
                        ControllertypeList = ControllertypeList + ControllerTypeLst[i];
                }


                if (!DeviceSupplyforCalLst.Contains(DeviceSupplyforCalvalue))
                    DeviceSupplyforCalLst.Add(DeviceSupplyforCalvalue);
                DeviceSupplyforCalList = "";
                for (int i = 0; i < DeviceSupplyforCalLst.Count; i++)
                {
                    if (DeviceSupplyforCalLst.Count - 1 > i)
                        DeviceSupplyforCalList = DeviceSupplyforCalList + DeviceSupplyforCalLst[i] + ",";
                    else
                        DeviceSupplyforCalList = DeviceSupplyforCalList + DeviceSupplyforCalLst[i];
                }
                IsCheckBoxEnabled = false;

                //Node Validation
                #region Node Validation
                if (CheckedNode1)
                {
                    if (Node1VtgRange != null)
                        NodeVoltagesRange[0] = Node1VtgRange;
                    else
                    {
                        MessageBox.Show("Couldn't save catid info, please enter node1 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        CheckedNode1 = false;
                        //ShowMessageBox("Couldn't save catid info, please enter node1 voltage range", false, "", "", clsGlobalVariables.MsgIcon.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[0] = "";
                if (CheckedNode2)
                {
                    if (Node2VtgRange != null)
                        NodeVoltagesRange[1] = Node2VtgRange;
                    else
                    {
                        CheckedNode2 = false;
                        MessageBox.Show("Couldn't save catid info, please enter node2 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[1] = "";
                if (CheckedNode3)
                {
                    if (Node3VtgRange != null)
                        NodeVoltagesRange[2] = Node3VtgRange;
                    else
                    {
                        CheckedNode3 = false;
                        MessageBox.Show("Couldn't save catid info, please enter node3 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[2] = "";
                if (CheckedNode4)
                {
                    if (Node4VtgRange != null)
                        NodeVoltagesRange[3] = Node4VtgRange;
                    else
                    {
                        CheckedNode4 = false;
                        MessageBox.Show("Couldn't save catid info, please enter node4 voltage range", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
                else
                    NodeVoltagesRange[3] = "";
                #endregion

                CatIDList TempCatList = new CatIDList()
                {
                    DeviceId = DeviceId,
                    DeviceName = DeviceName,
                    Description = Description,
                    DeviceSupplyforCal = DeviceSupplyforCalvalue,
                    DeviceSupplyforCalList = DeviceSupplyforCalList,
                    SupplyType = SupplyType,
                    SupplyTypeList = SupplyTypeList,
                    IsFixedTiming = IsFixedTiming,
                    FixedTiming = FixedTiming,
                    IsFixedMode = IsFixedMode,
                    MentionMode = MentionMode,
                    IsFixedRange = IsFixedRange,
                    MentionNumber = FixedRange,
                    RunTime_TimingChange = RunTime_TimingChange,
                    RunTime_RangeChange = RunTime_RangeChange,
                    RunTime_ModeChange = RunTime_ModeChange,
                    FirmwareVersion = FirmwareVersion,
                    HardwareCheck = HardwareCheck,
                    HexEdition = HexEdition,
                    ModeChangeData = ModeChangeData,
                    RangeChangeData = RangeChangeData,
                    TimingChangeData = TimingChangeData,
                    VCCRange = VCCRange,
                    VoltageCalibration = VoltageCalibration,
                    VoltageRange = VoltageRange,
                    DeviceIdHexLocation = DeviceIDHexLocation,
                    MotFilePath = MotPath,
                    Micon175_PotDetail = PotDetails,   
                    ControllerType = ControllerTypevalue,
                    ControllerTypeList = ControllertypeList,
                    RFPVersion = SelectedRFPV,
                    RelayVoltage = Voltage,
                    RelayVoltageList = VoltageList,
                    PWMEnable = PWMEnable,
                    RangeConstOnOffMode = RangeConstOnOffMode,
                    RelayNumber = RelayNumber,
                    Switchdata = Switchdata,
                    RangePotRangeValidation = RangePotRangeValidation,
                    TimingPotRangeValidation = TimingPotRangeValidation,
                    ModePotRangeValidation = ModePotRangeValidation,
                    NodeVoltagesRange = NodeVoltagesRange,
                    RwsFilePath = RwsPath,
                    RpjFilePath = RpjPath,
                    ImgPath = ImgPath,
                    IsZCDEnable = IsZCDEnable,
                    IsSwitchPresent= IsSwitchPresent
                };
                
                int found = 0;
                for (int CounterCatId = 0; CounterCatId < ModifiedCatId.Count; CounterCatId++)
                {
                    for (int CounterConfigData = 0; CounterConfigData < ModifiedCatId[CounterCatId].Micon175_ConfigData.Count; CounterConfigData++)
                    {
                        for (int CounterCatIdList = 0; CounterCatIdList < ModifiedCatId[CounterCatId].Micon175_ConfigData[CounterConfigData].CatIDList.Count; CounterCatIdList++)
                        {
                            if (ModifiedCatId[CounterCatId].Micon175_ConfigData[CounterConfigData].CatIDList[CounterCatIdList].DeviceName == TempCatList.DeviceName)
                            {
                                //ModifiedCatId[i].ConfigData[j].CatList.RemoveAt(z);
                                ModifiedCatId[CounterCatId].Micon175_ConfigData[CounterConfigData].CatIDList[CounterCatIdList] = TempCatList;
                                IsNotEditable = true;
                                IsCheckBoxEnabled = false;
                                IsSaveBtnVis = false;
                                IsSaveCatIdBtnVis = false;
                                IsSaveDevicetypeBtnVis = false;
                                found = 1; 
                                // serialize JSON directly to a file
                                string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                                System.IO.File.WriteAllText(JsonFileName, res);
                                ModifiedCatId.Clear();
                                Micon175ConfigDataList result = new Micon175ConfigDataList();
                                using (StreamReader file = File.OpenText(JsonFileName))
                                {
                                    JsonSerializer serializer = new JsonSerializer();
                                    result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                                }
                                ModifiedCatId.Add(result);
                                break;
                            }
                        }
                        if (found == 1) { break; }
                    }
                    if (found == 1) { break; }
                }
            } 
            catch (Exception ex)
            {
                MessageBox.Show("In SaveEditedjson : " + ex.Message);
                MyLogWriterDLL.LogWriter.WriteLog("In SaveEditedJson" +ex.ToString());
            }
            
        }

        /// <summary>
        /// DeleteDeviceType()
        /// After click on delete button , software shows confirmation message, 
        /// after confirm this function gets called for delete catid
        /// </summary>
        private void DeleteDeviceType(object obj)
        {
            
            Console.Beep(1000, 100); 
            BrowseBtnVis = false;
            EditBtnVis = false;
            ShowMessageBox("Do you want to delete Devicetype: " + obj.ToString() + " ? ", true, "DeleteDeviceType", obj.ToString(), clsGlobalVariables.MsgIcon.Question);
                       
            //MessageBoxResult dialogResult = MessageBox.Show("Do you want to delete the Devicetype?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            //if (dialogResult != MessageBoxResult.Yes)
            //{
            //    return;
            //}

        }
        /// <summary>
        /// DeleteDeviceType()
        /// This function is used to delete device type from the file.
        /// After click on delete button , software shows confirmation message, 
        /// after confirm this function gets called to delete selected.
        /// </summary>
        private void DeleteDeviceType(string DeviceType)
        {
            try
            {
                int found = 0;
                for (int CounterDltCatId = 0; CounterDltCatId < ModifiedCatId.Count; CounterDltCatId++)
                {
                    for (int CounterConfigData = 0; CounterConfigData < ModifiedCatId[CounterDltCatId].Micon175_ConfigData.Count; CounterConfigData++)
                    {
                        if (ModifiedCatId[CounterDltCatId].Micon175_ConfigData[CounterConfigData].DeviceType == DeviceType)
                        {
                            ModifiedCatId[CounterDltCatId].Micon175_ConfigData.RemoveAt(CounterConfigData);

                            found = 1;
                            // serialize JSON directly to a file
                            string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                            System.IO.File.WriteAllText(JsonFileName, res);
                            ModifiedCatId.Clear();
                            Micon175ConfigDataList result = new Micon175ConfigDataList();
                            using (StreamReader file = File.OpenText(JsonFileName))
                            {
                                JsonSerializer serializer = new JsonSerializer();
                                result = (Micon175ConfigDataList)serializer.Deserialize(file, typeof(Micon175ConfigDataList));
                            }
                            ModifiedCatId.Add(result);
                            break;
                        }
                    }
                    if (found == 1) { break; }
                }
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("In DeleteDeviceType" +ex.ToString());
            }
        }

        /// <summary>
        /// User clicked on Edit the cat id details 
        /// Enabled all controls that user can edit the information, 
        /// </summary>
        /// <param name="obj"></param>
        private void EditCatId(object obj)
        {
            try
            {
                EditBtnVis = true;
                Console.Beep(1000, 100); 
                BrowseBtnVis = true;
                EditBtnVis = true;
                object objEdit = new object();

                for (int CounterEditCatId = 0; CounterEditCatId < ModifiedCatId.Count; CounterEditCatId++)
                {
                    for (int CounterConfigData = 0; CounterConfigData < ModifiedCatId[CounterEditCatId].Micon175_ConfigData.Count; CounterConfigData++)
                    {
                        for (int CounterCaTIdList = 0; CounterCaTIdList < ModifiedCatId[CounterEditCatId].Micon175_ConfigData[CounterConfigData].CatIDList.Count; CounterCaTIdList++)
                        {
                            if (ModifiedCatId[CounterEditCatId].Micon175_ConfigData[CounterConfigData].CatIDList[CounterCaTIdList].DeviceName == obj.ToString())
                            {
                                objEdit = ModifiedCatId[CounterEditCatId].Micon175_ConfigData[CounterConfigData].CatIDList[CounterCaTIdList];
                                AssignDataToFields(objEdit, true);
                                break;
                            }
                            else
                            {
                                objEdit = null;
                            }

                        }
                        if (objEdit != null) { break; }
                    }
                    if (objEdit != null) { break; }
                }
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("In Edited"+ ex.ToString());
            }

        }


        //Close the dialog after say no to the confirmation message
        private void BtnNoClk(object obj)
        {
            IsDialogOpen = false;
        }


        /// <summary>
        /// BtnYesClk()
        /// Confirmation message is common for all parameters like save catid, device type,Edit , Delete
        /// If user clicked on the yes , function gets called
        /// Which EventSender obj send by user , according to that action will taken by the software
        /// Validation messages also given
        /// </summary>
        /// <param name="obj"></param>
        private void BtnYesClk(object obj)
        {
            try
            {
                switch (EventSender)
                {
                    case "SaveNewCatId":
                        SaveNewCatId();
                        BrowseBtnVis = false;
                        EditBtnVis = false;
                        IsDialogOpen = false;
                        clsGlobalVariables.IsFileChanged = true;
                        break;

                    case "SaveNewDeviceType":
                        SaveNewDeviceType();
                        IsDialogOpen = false;
                        clsGlobalVariables.IsFileChanged = true;
                        break;

                    case "SaveEditedJson":
                        SaveEditedJson();
                        BrowseBtnVis = false;
                        EditBtnVis = false;
                        IsDialogOpen = false;
                        clsGlobalVariables.IsFileChanged = true;
                        break;

                    case "DeleteCatId":
                        DeleteCatID(EventParam);
                        EventParam = "";
                        IsDialogOpen = false;
                        clsGlobalVariables.IsFileChanged = true;
                        break;

                    case "DeleteDeviceType":
                        DeleteDeviceType(EventParam);
                        EventParam = "";
                        IsDialogOpen = false;
                        clsGlobalVariables.IsFileChanged = true;
                        break;

                    case "Error":
                        EventParam = "";
                        IsDialogOpen = false;
                        break;

                    case "EditPot":
                        var status = (int)EditPot.OK;
                        Micon175PotDetail micon175PotDetailobj = clsPotEdit.SavePotDetails(ref status);

                        if(status == (int)EditPot.OK)                        
                            PotDetails[potNumber - 1] = micon175PotDetailobj;                                                  
                        else if (status == (int)EditPot.timingExceeded)
                        {
                            ShowMessageBox("Time constants should be numeric and should be less than 240", false, "Error", "Error", clsGlobalVariables.MsgIcon.Error);
                            break;
                        }
                        else if (status == (int)EditPot.constNumeric)
                        {
                            ShowMessageBox("Time constants/Range constants should be numeric digits only", false, "Error", "Error", clsGlobalVariables.MsgIcon.Error);
                            break;
                        }
                        else if (status == (int)EditPot.minmaxrange)
                        {
                            ShowMessageBox("In range column min value should be less than max value ", false, "Error", "Error", clsGlobalVariables.MsgIcon.Error);
                            break;
                        }
                        else if (status == (int)EditPot.MinMaxRangeNumeric)
                        {
                            ShowMessageBox("In range column min value and max value should be numeric and format should be e.g. 10-20 ", false, "Error", "Error", clsGlobalVariables.MsgIcon.Error);
                            break;
                        }
                        else if (status == (int)EditPot.Differencenumeric)
                        {
                            ShowMessageBox("Difference values should be in numeric", false, "Error", "Error", clsGlobalVariables.MsgIcon.Error);
                            break;
                        }

                        if (PotDetails[potNumber - 1].PotName == null)
                        {
                            PotNameError = true;
                            IsDialogOpen = true;
                        }                           
                        else
                        {
                            PotNameError = false;
                            IsDialogOpen = false;
                        }                        
                        msgVis = true;                        
                        break;

                    case "DeletePot":
                        PotDetails[potNumber - 1] = clsPotEdit.RemovePotDetails();
                        PotDetails.RemoveAt(potNumber - 1);
                        int potStartPos = 1;

                        foreach (var item in PotDetails)
                        {
                            item.PotNumber = potStartPos;
                            potStartPos++;
                        }
                        NoOfPots = PotDetails.Count;
                        IsDialogOpen = false;
                        msgVis = true;
                        break;

                 
                    case "escBtn":
                        EventParam = "";
                        currentWindow.Close();
                        IsDialogOpen = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In BtnYesClk : "+ ex.Message);
            }       
        }

        /// <summary>
        /// Show messagsebox , function is common for all parameters Add, edit and delete.
        /// Which button need to show Ok or YesNo , send as a parameters pass as a function
         /// </summary>
        /// <param name="msg"></param>
        /// <param name="yesNo"></param>
        /// <param name="sender"></param>
        /// <param name="eventParam"></param>
        /// <param name="icon"></param>
        private void ShowMessageBox(string msg, bool yesNo, string sender, string eventParam, clsGlobalVariables.MsgIcon icon)
        {
            switch (icon)
            {
                case clsGlobalVariables.MsgIcon.Message:
                    IconMsgVis = true;
                    IconErrorVis = false;
                    IconQuestionVis = false;
                    break;
                case clsGlobalVariables.MsgIcon.Error:
                    IconMsgVis = false;
                    IconErrorVis = true;
                    IconQuestionVis = false;
                    break;
                case clsGlobalVariables.MsgIcon.Question:
                    IconMsgVis = false;
                    IconErrorVis = false;
                    IconQuestionVis = true;
                    break;
                default:
                    IconMsgVis = true;
                    IconErrorVis = false;
                    break;
            }

            Msg = msg;
            EventSender = sender;
            EventParam = eventParam;
            PotEditVis = false;
            MessageWindowVis = true;
            MsgVis = yesNo;            
            ErrorMsgVis = !yesNo;
            IsDialogOpen = true;
        }


        /// <summary>
        /// Show pot edit window
        /// </summary>
        private void ShowPotEditWindow()
        {
            Msg = "";
            EventSender = "EditPot";
            EventParam = "";
            PotEditVis = true;
            MessageWindowVis = false;
            MsgVis = true;
            ErrorMsgVis = false;
            IsDialogOpen = true;
        }


        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string PropertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }
    }
}
