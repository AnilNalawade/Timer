﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.model;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;

namespace GIC_Timer_Programming_and_Calibration.viewModel
{
    
    public class Micon225_CatalogueConfigVM : INotifyPropertyChanged
    {
        private string JsonFileName = clsGlobalVariables.Micon225Jsonpath;

        private ObservableCollection<Micon225ConfigDataList> _Micon225CatId;

        public ObservableCollection<Micon225ConfigDataList> Micon225CatId
        {
            get { return _Micon225CatId; }
            set { _Micon225CatId = value; OnPropertyChanged("Micon225CatId"); }
        }

        private ObservableCollection<Micon225ConfigDataList> _ModifiedCatId;

        public ObservableCollection<Micon225ConfigDataList> ModifiedCatId
        {
            get { return _ModifiedCatId; }
            set { _ModifiedCatId = value; OnPropertyChanged("ModifiedCatId"); }
        }

        private object _SelectedItem;

        public object SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged("SelectedItem");}
        }

        private string _DeviceType;

        public string DeviceType
        {
            get { return _DeviceType; }
            set { _DeviceType = value; OnPropertyChanged("DeviceType"); }
        }

        private string _DeviceName;

        public string DeviceName
        {
            get { return _DeviceName; }
            set { _DeviceName = value; OnPropertyChanged("DeviceName"); }
        }


        private int _DeviceId;

        public int DeviceId
        {
            get { return _DeviceId; }
            set { _DeviceId = value; OnPropertyChanged("DeviceId"); }
        }

        private string _MotPath;

        public string MotPath
        {
            get { return _MotPath; }
            set { _MotPath = value; OnPropertyChanged("MotPath"); }
        }

        private int _NoOfSwitches;

        public int NoOfSwitches
        {
            get { return _NoOfSwitches; }
            set { _NoOfSwitches = value; OnPropertyChanged("NoOfSwitches"); }
        }

        private int _NoOfPots;

        public int NoOfPots
        {
            get { return _NoOfPots; }
            set
            {
                _NoOfPots = value;
                OnPropertyChanged("NoOfPots");
               // if(IsCatNew == true)
                {
                    if(PotDetails != null)
                    {
                        if(NoOfPots <= 5 && NoOfPots > 0)
                        {
                            PotDetails.Clear();
                            for (int i = 0; i < NoOfPots; i++)
                            {
                                PotDetails.Add(new PotDetail() { PotNumber = i + 1 });
                            }
                        }
                        else
                        {
                            NoOfPots = 1;
                            Msg = "Number of Pots can be 1-5 !";
                            ErrorMsgVis = true;
                            MsgVis = false;
                            EventSender = "Error";
                            EventParam = "";
                            IsDialogOpen = true;
                        }
                        
                    }
                                     
                }
            }
        }

        private bool _IsPWMSupported;

        public bool IsPWMSupported
        {
            get { return _IsPWMSupported; }
            set { _IsPWMSupported = value; OnPropertyChanged("IsPWMSupported"); }
        }
        
        private bool _IsSwitchSupported;

        public bool IsSwitchSupported
        {
            get { return _IsSwitchSupported; }
            set { _IsSwitchSupported = value; OnPropertyChanged("IsSwitchSupported"); }
        }

        private ObservableCollection<PotDetail> _PotDetails ;

        public ObservableCollection<PotDetail> PotDetails
        {
            get { return _PotDetails; }
            set { _PotDetails = value; OnPropertyChanged("PotDetails"); }
        }

        private bool _IsNotEditable = false;

        public bool IsNotEditable
        {
            get { return _IsNotEditable; }
            set { _IsNotEditable = value; OnPropertyChanged("IsNotEditable"); }
        }

        private bool _IsDeviceTypeUneditable = true;

        public bool IsDeviceTypeUneditable
        {
            get { return _IsDeviceTypeUneditable; }
            set { _IsDeviceTypeUneditable = value; OnPropertyChanged("IsDeviceTypeUneditable"); }
        }

        private bool _IsDeviceNameUneditable = true;

        public bool IsDeviceNameUneditable
        {
            get { return _IsDeviceNameUneditable; }
            set { _IsDeviceNameUneditable = value; OnPropertyChanged("IsDeviceNameUneditable"); }
        }

        private bool _IsCheckBoxEnabled = false;

        public bool IsCheckBoxEnabled
        {
            get { return _IsCheckBoxEnabled; }
            set { _IsCheckBoxEnabled = value; OnPropertyChanged("IsCheckBoxEnabled"); }
        }

        private bool _IsSaveBtnVis = false;

        public bool IsSaveBtnVis
        {
            get { return _IsSaveBtnVis; }
            set { _IsSaveBtnVis = value; OnPropertyChanged("IsSaveBtnVis"); }
        }


        private bool _IsSaveDevicetypeBtnVis = false;

        public bool IsSaveDevicetypeBtnVis
        {
            get { return _IsSaveDevicetypeBtnVis; }
            set { _IsSaveDevicetypeBtnVis = value; OnPropertyChanged("IsSaveDevicetypeBtnVis"); }
        }

        private bool _IsSaveCatIdBtnVis = false;

        public bool IsSaveCatIdBtnVis
        {
            get { return _IsSaveCatIdBtnVis; }
            set { _IsSaveCatIdBtnVis = value; OnPropertyChanged("IsSaveCatIdBtnVis"); }
        }

        private bool _IsCatNew = false;

        public bool IsCatNew
        {
            get { return _IsCatNew; }
            set { _IsCatNew = value; OnPropertyChanged("IsCatNew"); }
        }

        private string _Msg = "";

        public string Msg
        {
            get { return _Msg; }
            set { _Msg = value; OnPropertyChanged("Msg"); }
        }

        private bool _IsDialogOpen = false;

        public bool IsDialogOpen
        {
            get { return _IsDialogOpen; }
            set { _IsDialogOpen = value; OnPropertyChanged("IsDialogOpen"); }
        }

        private string _EventSender = "";

        public string EventSender
        {
            get { return _EventSender; }
            set { _EventSender = value; OnPropertyChanged("EventSender"); }
        }

        private string _EventParam = "";

        public string EventParam
        {
            get { return _EventParam; }
            set { _EventParam = value; OnPropertyChanged("EventParam"); }
        }

        private bool _ErrorMsgVis = false;

        public bool ErrorMsgVis
        {
            get { return _ErrorMsgVis; }
            set { _ErrorMsgVis = value; OnPropertyChanged("ErrorMsgVis"); }
        }

        private bool _MsgVis = true;

        public bool MsgVis
        {
            get { return _MsgVis; }
            set { _MsgVis = value; OnPropertyChanged("MsgVis"); }
        }

        private bool _BrowseBtnVis = false;

        public bool BrowseBtnVis
        {
            get { return _BrowseBtnVis; }
            set { _BrowseBtnVis = value; OnPropertyChanged("BrowseBtnVis"); }
        }


        public Window  currentWindow{ get; set; }


        private RelayCommand _BrowseCmd;

        public RelayCommand BrowseCmd
        {
            get { return _BrowseCmd; }
            set { _BrowseCmd = value; }
        }


        private RelayCommand _EditCatIdCmd;

        public RelayCommand EditCatIdCmd
        {
            get { return _EditCatIdCmd; }
            set { _EditCatIdCmd = value; }
        }

        private RelayCommand _DeleteCatIdCmd;

        public RelayCommand DeleteCatIdCmd
        {
            get { return _DeleteCatIdCmd; }
            set { _DeleteCatIdCmd = value; }
        }

        private RelayCommand _DeleteDeviceTypeCmd;

        public RelayCommand DeleteDeviceTypeCmd
        {
            get { return _DeleteDeviceTypeCmd; }
            set { _DeleteDeviceTypeCmd = value; }
        }

        
        private RelayCommand _AddCatIdCmd;

        public RelayCommand AddCatIdCmd
        {
            get { return _AddCatIdCmd; }
            set { _AddCatIdCmd = value; }
        }

        private RelayCommand _AddDeviceTypeCmd;

        public RelayCommand AddDeviceTypeCmd
        {
            get { return _AddDeviceTypeCmd; }
            set { _AddDeviceTypeCmd = value; }
        }

        private RelayCommand _SaveJsonCmd;

        public RelayCommand SaveJsonCmd
        {
            get { return _SaveJsonCmd; }
            set { _SaveJsonCmd = value; }
        }

        private RelayCommand _SaveNewDeviceTypeCmd;

        public RelayCommand SaveNewDeviceTypeCmd
        {
            get { return _SaveNewDeviceTypeCmd; }
            set { _SaveNewDeviceTypeCmd = value; }
        }

        private RelayCommand _SaveNewCatIdCmd;

        public RelayCommand SaveNewCatIdCmd
        {
            get { return _SaveNewCatIdCmd; }
            set { _SaveNewCatIdCmd = value; }
        }

        private RelayCommand _BtnYesCmd;

        public RelayCommand BtnYesCmd
        {
            get { return _BtnYesCmd; }
            set { _BtnYesCmd = value; }
        }

        private RelayCommand _BtnNoCmd;

        public RelayCommand BtnNoCmd
        {
            get { return _BtnNoCmd; }
            set { _BtnNoCmd = value; }
        }


        public Micon225_CatalogueConfigVM()
        {
            _EditCatIdCmd = new RelayCommand(EditCatId);
            _DeleteCatIdCmd = new RelayCommand(DeleteCatId);            
            _DeleteDeviceTypeCmd = new RelayCommand(DeleteDeviceType);
            _SaveJsonCmd = new RelayCommand(SaveJson);
            _SaveNewDeviceTypeCmd = new RelayCommand(SaveNewDeviceType);
            _SaveNewCatIdCmd = new RelayCommand(SaveNewCatId);
            _BrowseCmd = new RelayCommand(BrowseBtnClk);
            _AddCatIdCmd = new RelayCommand(AddCatId);
            _AddDeviceTypeCmd = new RelayCommand(AddDeviceType);
            _BtnYesCmd = new RelayCommand(BtnYesClk);
            _BtnNoCmd = new RelayCommand(BtnNoClk);
            _ModifiedCatId = new ObservableCollection<Micon225ConfigDataList>();
            _Micon225CatId = new ObservableCollection<Micon225ConfigDataList>();
            _PotDetails = new ObservableCollection<PotDetail>();
            Micon225ConfigDataList result = new Micon225ConfigDataList();
            using (StreamReader file = File.OpenText(JsonFileName))
            {
                JsonSerializer serializer = new JsonSerializer();
                result = (Micon225ConfigDataList)serializer.Deserialize(file, typeof(Micon225ConfigDataList));
            }
            Micon225CatId.Add(result);
            ModifiedCatId.Add(result);
            IsSaveBtnVis = false;
            IsSaveCatIdBtnVis = false;
            IsSaveDevicetypeBtnVis = false;
        }

        private void BrowseBtnClk(object obj)
        {
            OpenFileDialog od = new OpenFileDialog();
            if(od.ShowDialog() != null)
            {
                MotPath = od.FileName;
            }
        }

        private void BtnNoClk(object obj)
        {
            IsDialogOpen = false;
        }

        private void BtnYesClk(object obj)
        {
            switch (EventSender)
            {
                case "SaveNewCatId":
                    SaveNewCatId();
                    BrowseBtnVis = false;
                    IsDialogOpen = false;
                    break;
                case "SaveNewDeviceType":
                    SaveNewDeviceType();
                    IsDialogOpen = false;
                    break;
                case "SaveEditedJson":
                    SaveEditedJson();
                    BrowseBtnVis = false;
                    IsDialogOpen = false;
                    break;
                case "DeleteCatId":
                    DeleteCatID(EventParam);
                    EventParam = "";
                    IsDialogOpen = false;
                    break;
                case "DeleteDeviceType":
                    DeleteDeviceType(EventParam);
                    EventParam = "";
                    IsDialogOpen = false;
                    break;
                case "Error":                    
                    EventParam = "";
                    IsDialogOpen = false;
                    break;
                case "escBtn":
                    EventParam = "";
                    currentWindow.Close();
                    IsDialogOpen = false;
                    break;
            }
        }

        private void SaveNewCatId(object obj)
        {
            foreach (Micon225ConfigData item in ModifiedCatId[0].Micon225ConfigData)
            {
                foreach (CatList cat in item.CatList)
                {
                    if (cat.DeviceName == DeviceName)
                    {
                        Msg = "Device Name Already exist!\nPlease use another device name.";
                        EventSender = "Error";
                        EventParam = "";
                        MsgVis = false;
                        ErrorMsgVis = true;
                        IsDialogOpen = true;
                        return;
                    }
                }
            }
            if (DeviceName == null || DeviceName == "")
            {
                Msg = "Device Name can't be empty !";
                EventSender = "Error";
                EventParam = "";
                MsgVis = false;
                ErrorMsgVis = true;
                IsDialogOpen = true;
            }
            else
            {
                Msg = "Do you want to save the changes?";
                EventSender = "SaveNewCatId";
                MsgVis = true;
                ErrorMsgVis = false;
                IsDialogOpen = true;
            }
            

        }

        private void SaveNewCatId()
        {
            CatList NewCatList = new CatList()
            {
                DeviceId = DeviceId,
                DeviceName = DeviceName,
                MotFilePath = MotPath,
                NoOfSwitches = NoOfSwitches,
                PotDetails = PotDetails,
                PWM_Supported = IsPWMSupported,
                Switch_Supported = IsSwitchSupported
            };
            int found = 0;            
            for (int i = 0; i < ModifiedCatId.Count; i++)
            {
                for (int j = 0; j < ModifiedCatId[i].Micon225ConfigData.Count; j++)
                {
                    if (ModifiedCatId[i].Micon225ConfigData[j].DeviceType == DeviceType)
                    {
                        //ModifiedCatId[i].ConfigData[j].CatList.RemoveAt(z);
                        ModifiedCatId[i].Micon225ConfigData[j].CatList.Add(NewCatList);
                        found = 1;
                        IsSaveBtnVis = false;
                        IsSaveCatIdBtnVis = false;
                        IsSaveDevicetypeBtnVis = false;
                        // serialize JSON directly to a file
                        string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                        System.IO.File.WriteAllText(JsonFileName, res);
                        ModifiedCatId.Clear();
                        Micon225ConfigDataList result = new Micon225ConfigDataList();
                        using (StreamReader file = File.OpenText(JsonFileName))
                        {
                            JsonSerializer serializer = new JsonSerializer();
                            result = (Micon225ConfigDataList)serializer.Deserialize(file, typeof(Micon225ConfigDataList));
                        }
                        ModifiedCatId.Add(result);
                        IsCatNew = false;
                        break;
                    }

                }
                if (found == 1) { break; }
            }
        }

        private void SaveNewDeviceType(object obj)
        {
            BrowseBtnVis = false;
            foreach (Micon225ConfigData item in ModifiedCatId[0].Micon225ConfigData)
            {
                if (item.DeviceType == DeviceType)
                {
                    Msg = "Device Type Already exist!\nPlease use another device type name.";
                    EventSender = "Error";
                    EventParam = "";
                    MsgVis = false;
                    ErrorMsgVis = true;
                    IsDialogOpen = true;
                    return;
                }
            }
            if(DeviceType == null || DeviceType == "")
            {
                Msg = "Device Type can't be empty !";
                EventSender = "Error";
                EventParam = "";
                MsgVis = false;
                ErrorMsgVis = true;
                IsDialogOpen = true;
            }
            else
            {
                Msg = "Do you want to save the changes?";
                EventSender = "SaveNewDeviceType";
                MsgVis = true;
                ErrorMsgVis = false;
                IsDialogOpen = true;
            }            
        }

        private void SaveNewDeviceType()
        {
            Micon225ConfigData NewDeviceType = new Micon225ConfigData()
            {
                DeviceType = DeviceType,
                CatList = new ObservableCollection<CatList>()
            };            
            ModifiedCatId[0].Micon225ConfigData.Add(NewDeviceType);
            IsSaveBtnVis = false;
            IsSaveCatIdBtnVis = false;
            IsSaveDevicetypeBtnVis = false;
            string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
            System.IO.File.WriteAllText(JsonFileName, res);
            ModifiedCatId.Clear();
            Micon225ConfigDataList result = new Micon225ConfigDataList();
            using (StreamReader file = File.OpenText(JsonFileName))
            {
                JsonSerializer serializer = new JsonSerializer();
                result = (Micon225ConfigDataList)serializer.Deserialize(file, typeof(Micon225ConfigDataList));
            }
            ModifiedCatId.Add(result);
        }

        private void SaveJson(object obj)
        {
            foreach (Micon225ConfigData item in ModifiedCatId[0].Micon225ConfigData)
            {
                foreach (CatList cat in item.CatList)
                {
                    if (cat.DeviceName == DeviceName && IsDeviceNameUneditable == false)
                    {
                        Msg = "Device Name Already exist!\nPlease use another device name.";
                        EventSender = "Error";
                        EventParam = "";
                        MsgVis = false;
                        ErrorMsgVis = true;
                        IsDialogOpen = true;
                        return;
                    }
                }
            }
            EventSender = "SaveEditedJson";
            Msg = "Do you want to save the changes?";
            MsgVis = true;
            ErrorMsgVis = false;
            IsDialogOpen = true;
            //MessageBoxResult dialogResult = MessageBox.Show("Do you want to save the changes?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            //if (dialogResult != MessageBoxResult.Yes)
            //{
            //    return;
            //}

        }
        public void SaveEditedJson()
        {
            CatList TempCatList = new CatList()
            {
                DeviceId = DeviceId,
                DeviceName = DeviceName,
                MotFilePath = MotPath,
                NoOfSwitches = NoOfSwitches,
                PotDetails = PotDetails,
                PWM_Supported = IsPWMSupported,
                Switch_Supported = IsSwitchSupported
            };
            int found = 0;            
            for (int i = 0; i < ModifiedCatId.Count; i++)
            {
                for (int j = 0; j < ModifiedCatId[i].Micon225ConfigData.Count; j++)
                {
                    for (int z = 0; z < ModifiedCatId[i].Micon225ConfigData[j].CatList.Count; z++)
                    {
                        if (ModifiedCatId[i].Micon225ConfigData[j].CatList[z].DeviceName == TempCatList.DeviceName)
                        {
                            //ModifiedCatId[i].ConfigData[j].CatList.RemoveAt(z);
                            ModifiedCatId[i].Micon225ConfigData[j].CatList[z] = TempCatList;
                            IsNotEditable = true;
                            IsCheckBoxEnabled = false;
                            IsSaveBtnVis = false;
                            IsSaveCatIdBtnVis = false;
                            IsSaveDevicetypeBtnVis = false;
                            found = 1;
                            // serialize JSON directly to a file
                            string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                            System.IO.File.WriteAllText(JsonFileName, res);
                            ModifiedCatId.Clear();
                            Micon225ConfigDataList result = new Micon225ConfigDataList();
                            using (StreamReader file = File.OpenText(JsonFileName))
                            {
                                JsonSerializer serializer = new JsonSerializer();
                                result = (Micon225ConfigDataList)serializer.Deserialize(file, typeof(Micon225ConfigDataList));
                            }
                            ModifiedCatId.Add(result);
                            break;
                        }

                    }
                    if (found == 1) { break; }
                }
                if (found == 1) { break; }
            }
        }

        private void DeleteCatId(object obj)
        {

            Console.Beep(1000, 100);         
            BrowseBtnVis = false;
            Msg = "Do you want to delete Catalogue Id: "+ obj.ToString() + " ?";
            EventParam = obj.ToString();
            EventSender = "DeleteCatId";
            MsgVis = true;
            ErrorMsgVis = false;
            IsDialogOpen = true;
            //MessageBoxResult dialogResult = 
            //if (MessageBox.Show("Do you want to delete the Catalogue Id?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            //{
            //    return;
            //}

        }       
        
        public void DeleteCatID(string DeviceName)
        {
            
            int found = 0;
            for (int i = 0; i < ModifiedCatId.Count; i++)
            {
                for (int j = 0; j < ModifiedCatId[i].Micon225ConfigData.Count; j++)
                {
                    for (int z = 0; z < ModifiedCatId[i].Micon225ConfigData[j].CatList.Count; z++)
                    {
                        if (ModifiedCatId[i].Micon225ConfigData[j].CatList[z].DeviceName == DeviceName)
                        {
                            ModifiedCatId[i].Micon225ConfigData[j].CatList.RemoveAt(z);

                            found = 1;
                            // serialize JSON directly to a file
                            string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                            System.IO.File.WriteAllText(JsonFileName, res);
                            ModifiedCatId.Clear();
                            Micon225ConfigDataList result = new Micon225ConfigDataList();
                            using (StreamReader file = File.OpenText(JsonFileName))
                            {
                                JsonSerializer serializer = new JsonSerializer();
                                result = (Micon225ConfigDataList)serializer.Deserialize(file, typeof(Micon225ConfigDataList));
                            }
                            ModifiedCatId.Add(result);
                            break;
                        }

                    }
                    if (found == 1) { break; }
                }
                if (found == 1) { break; }
            }
        }

        private void DeleteDeviceType(object obj)
        {
            Console.Beep(1000, 100);         
            BrowseBtnVis = false;
            Msg = "Do you want to delete Devicetype: "+ obj.ToString() +" ?";
            EventParam = obj.ToString();
            EventSender = "DeleteDeviceType";
            MsgVis = true;
            ErrorMsgVis = false;
            IsDialogOpen = true;
            //MessageBoxResult dialogResult = MessageBox.Show("Do you want to delete the Devicetype?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            //if (dialogResult != MessageBoxResult.Yes)
            //{
            //    return;
            //}

        }

        public void DeleteDeviceType(string DeviceType)
        {
            int found = 0;
            for (int i = 0; i < ModifiedCatId.Count; i++)
            {
                for (int j = 0; j < ModifiedCatId[i].Micon225ConfigData.Count; j++)
                {
                    if (ModifiedCatId[i].Micon225ConfigData[j].DeviceType == DeviceType)
                    {
                        ModifiedCatId[i].Micon225ConfigData.RemoveAt(j);

                        found = 1;
                        // serialize JSON directly to a file
                        string res = JsonConvert.SerializeObject(ModifiedCatId[0], Formatting.Indented);
                        System.IO.File.WriteAllText(JsonFileName, res);
                        ModifiedCatId.Clear();
                        Micon225ConfigDataList result = new Micon225ConfigDataList();
                        using (StreamReader file = File.OpenText(JsonFileName))
                        {
                            JsonSerializer serializer = new JsonSerializer();
                            result = (Micon225ConfigDataList)serializer.Deserialize(file, typeof(Micon225ConfigDataList));
                        }
                        ModifiedCatId.Add(result);
                        break;
                    }
                }
                if (found == 1) { break; }
            }
        }

        private void AddCatId(object obj)
        {
            Console.Beep(1000, 100);                
            IsCatNew = true;
            DeviceType = obj.ToString();
            IsNotEditable = false;            
            IsSaveBtnVis = false;
            IsCheckBoxEnabled = true;            
            IsSaveCatIdBtnVis = true;
            IsSaveDevicetypeBtnVis = false;
            IsDeviceTypeUneditable = true;
            IsDeviceNameUneditable = false;            
            DeviceId = 0;
            DeviceName = "";
            MotPath = "";
            NoOfPots = 1;
            NoOfSwitches = 0;
            IsPWMSupported = false;
            IsSwitchSupported = false;
            BrowseBtnVis = true;
        }

        private void AddDeviceType(object obj)
        {
            Console.Beep(1000, 100);         
            IsNotEditable = true;
            IsSaveBtnVis = false;
            IsDeviceTypeUneditable = false;
            IsCheckBoxEnabled = true;
            IsDeviceNameUneditable = true;
            IsSaveCatIdBtnVis = false;
            IsSaveDevicetypeBtnVis = true;
            DeviceType = "";
            DeviceId = 0;
            DeviceName = "";
            MotPath = "";
            NoOfPots = 1;
            NoOfSwitches = 0;
            IsPWMSupported = false;
            IsSwitchSupported = false;
            BrowseBtnVis = false;
        }

        private void EditCatId(object obj)
        {
            Console.Beep(1000, 100);         
            BrowseBtnVis = true;
            object objEdit = new object();

            for (int i = 0; i < ModifiedCatId.Count; i++)
            {
                for (int j = 0; j < ModifiedCatId[i].Micon225ConfigData.Count; j++)
                {
                    for (int z = 0; z < ModifiedCatId[i].Micon225ConfigData[j].CatList.Count; z++)
                    {
                        if (ModifiedCatId[i].Micon225ConfigData[j].CatList[z].DeviceName == obj.ToString())
                        {
                            objEdit = ModifiedCatId[i].Micon225ConfigData[j].CatList[z];                                                       
                            AssignDataToFields(objEdit, true);
                            break;
                        }
                        else
                        {
                            objEdit = null;
                        }

                    }
                    if (objEdit != null) { break; }
                }
                if (objEdit != null) { break; }
            }
            
        }
        
        public void AssignDataToFields(object obj,bool IsEditable)
        {

            if (obj.GetType() == typeof(Micon225ConfigDataList))
            {
                DeviceType = "";
                DeviceName = "";
                MotPath = "";
                DeviceId = 0;
                NoOfPots = 1;
                NoOfSwitches = 0;
                IsPWMSupported = false;
                IsSwitchSupported = false;
                PotDetails.Clear();
            }
            else if (obj.GetType() == typeof(Micon225ConfigData))
            {
                Micon225ConfigData objConfigData = new Micon225ConfigData();
                objConfigData = (Micon225ConfigData)obj;
                DeviceType = objConfigData.DeviceType;
                DeviceName = "";
                MotPath = "";
                DeviceId = 0;
                NoOfPots = 1;
                NoOfSwitches = 0;
                IsPWMSupported = false;
                IsSwitchSupported = false;
                PotDetails.Clear();
                
            }
            else if (obj.GetType() == typeof(CatList))
            {
                CatList _catList = new CatList();
                _catList = (CatList)obj;
                DeviceType = null;
                PotDetails.Clear();
                int i = 0;
                while (i != -1)
                {
                    int j = 0;
                    while (j != -1)
                    {
                        if (ModifiedCatId[0].Micon225ConfigData[i].CatList[j].DeviceName != _catList.DeviceName)
                        {
                            j++;
                        }
                        else
                        {
                            DeviceType = ModifiedCatId[0].Micon225ConfigData[i].DeviceType;
                            j = -1;
                        }

                        if (j == ModifiedCatId[0].Micon225ConfigData[i].CatList.Count)
                        {
                            j = -1;
                        }

                    }
                    if (i == ModifiedCatId[0].Micon225ConfigData.Count)
                    {
                        i = -1;
                    }
                    else
                    {
                        if (DeviceType != null)
                        {
                            i = -1;
                        }
                        else
                        {
                            i++;
                        }
                    }

                }
                DeviceName = _catList.DeviceName;
                MotPath = _catList.MotFilePath;
                DeviceId = _catList.DeviceId;
                NoOfPots = _catList.PotDetails.Count;
                NoOfSwitches = _catList.NoOfSwitches;
                IsPWMSupported = _catList.PWM_Supported;
                IsSwitchSupported = _catList.Switch_Supported;
                PotDetails.Clear();
                foreach (PotDetail item in _catList.PotDetails)
                {
                    PotDetails.Add(item);
                }
                if(IsEditable == true)
                {
                    IsNotEditable = false;
                    IsDeviceTypeUneditable = true;
                    IsDeviceNameUneditable = true;
                    IsCheckBoxEnabled = true;
                    IsSaveBtnVis = true;
                    IsSaveCatIdBtnVis = false;
                    IsSaveDevicetypeBtnVis = false;
                    BrowseBtnVis = true;
                }
                else
                {                    
                    IsNotEditable = true;
                    IsCheckBoxEnabled = false;
                    IsSaveBtnVis = false;
                    IsSaveCatIdBtnVis = false;
                    IsSaveDevicetypeBtnVis = false;
                    IsDeviceTypeUneditable = true;
                    IsDeviceNameUneditable = true;
                    BrowseBtnVis = false;
                }
                
            }




        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
