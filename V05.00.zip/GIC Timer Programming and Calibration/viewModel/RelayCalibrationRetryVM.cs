﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.model;
using GIC_Timer_Programming_and_Calibration.view;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;


namespace GIC_Timer_Programming_and_Calibration.viewModel
{
    public class RelayCalibrationRetryVM : INotifyPropertyChanged
    {
 
        public RelayCalibrationRetryVM()
        {
            try
            {
               //No operation 
               
            }
            catch (Exception ex)
            {
                MyLogWriterDLL.LogWriter.WriteLog("Exception while Relay Calibration Retry : " + ex.ToString());
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    
    }
}
