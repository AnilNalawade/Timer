﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GIC_Timer_Programming_and_Calibration.viewModel
{
    public class ShowMessageVM : INotifyPropertyChanged
    {
        MainWindowVM mainWindowVM = new MainWindowVM();
        private string _temptext = "";
        public RelayCommand RetryCmd { get; set; }
        public RelayCommand btnOkCalibrationCmd { get; set; }
        public string temptext
        {
            get { return _temptext; }
            set
            {
                _temptext = value;
                clsGlobalVariables.tempValue = value;
                OnPropertyChanged("temptext");
            }
        }


        private string _Colorchanged;

        public string Colorchanged
        {
            get
            {
                if(clsGlobalVariables.strMessageStatus == "Fail")
                {
                    _Colorchanged = "#c62828";
                }
                else
                    _Colorchanged = "#2e7d32";
                return _Colorchanged;
            }
            set
            {
                _Colorchanged = value;
                OnPropertyChanged("Colorchanged");
            }
        }

        private bool _IsEnableRetry;

        public bool IsEnableRetry
        {
            get { return _IsEnableRetry; }
            set { _IsEnableRetry = value; OnPropertyChanged("IsEnableRetry"); }
        }

        private bool _IsEnableOk;

        public bool IsEnableOk
        {
            get { return _IsEnableOk; }
            set { _IsEnableOk = value; OnPropertyChanged("IsEnableOk"); }
        }

        private string _CalibrationPotName;

        public string CalibrationPotName
        {
            get { return _CalibrationPotName; }
            set { _CalibrationPotName = value; OnPropertyChanged("CalibrationPotName"); }
        }


        private string _CalMsg;

        public string CalMsg
        {
            get { return _CalMsg; }
            set
            {
                _CalMsg = value;
                OnPropertyChanged("CalMsg");
            }
        }      
        public ShowMessageVM()
        {
            CalibrationPotName = clsGlobalVariables.strCalWindowNm;
            CalMsg = clsGlobalVariables.strMessage;            
            RetryCmd = new RelayCommand(BtnRetryCmd);
            btnOkCalibrationCmd = new RelayCommand(btnOkCalibration);
        }

        private void btnOkCalibration(object obj)
        {
            clsGlobalVariables.IsOkclicked = true;
        }

        private void BtnRetryCmd(object obj)
        {
            mainWindowVM.btnRetry("Retry");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
