﻿using GIC_Timer_Programming_and_Calibration.helperClasses;
using GIC_Timer_Programming_and_Calibration.model;
using GIC_Timer_Programming_and_Calibration.view;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace GIC_Timer_Programming_and_Calibration.viewModel
{
    public class SwitchCalibrationVM : INotifyPropertyChanged
    {

        private bool _Tglbtn1;

        public bool Tglbtn1
        {
            get { return _Tglbtn1; }
            set { _Tglbtn1 = value; OnPropertyChanged("Tglbtn1"); }
        }

        private bool _Tglbtn2;

        public bool Tglbtn2
        {
            get { return _Tglbtn2; }
            set { _Tglbtn2 = value; OnPropertyChanged("Tglbtn2"); }
        }

        private bool _Tglbtn3;

        public bool Tglbtn3
        {
            get { return _Tglbtn3; }
            set { _Tglbtn3 = value; OnPropertyChanged("Tglbtn3"); }
        }

        private bool _Tglbtn4;

        public bool Tglbtn4
        {
            get { return _Tglbtn4; }
            set { _Tglbtn4 = value; OnPropertyChanged("Tglbtn4"); }
        }

        private bool _Tglbtn5;

        public bool Tglbtn5
        {
            get { return _Tglbtn5; }
            set { _Tglbtn5 = value; OnPropertyChanged("Tglbtn5"); }
        }

        private bool _Tglbtn6;

        public bool Tglbtn6
        {
            get { return _Tglbtn6; }
            set { _Tglbtn6 = value; OnPropertyChanged("Tglbtn6"); }
        }


        private bool _Tgl1Vis;
        public bool Tgl1Vis
        {
            get { return _Tgl1Vis; }
            set { _Tgl1Vis = value; OnPropertyChanged("Tgl1Vis"); }
        }

        private bool _Tgl2Vis;

        public bool Tgl2Vis
        {
            get { return _Tgl2Vis; }
            set { _Tgl2Vis = value; OnPropertyChanged("Tgl2Vis"); }
        }

        private bool _Tgl3Vis;

        public bool Tgl3Vis
        {
            get { return _Tgl3Vis; }
            set { _Tgl3Vis = value; OnPropertyChanged("Tgl3Vis"); }
        }

        private bool _Tgl4Vis;

        public bool Tgl4Vis
        {
            get { return _Tgl4Vis; }
            set { _Tgl4Vis = value; OnPropertyChanged("Tgl4Vis"); }
        }

        private bool _Tgl5Vis;

        public bool Tgl5Vis
        {
            get { return _Tgl5Vis; }
            set { _Tgl5Vis = value; OnPropertyChanged("Tgl5Vis"); }
        }

        private bool _Tgl6Vis;

        public bool Tgl6Vis
        {
            get { return _Tgl6Vis; }
            set { _Tgl6Vis = value; OnPropertyChanged("Tgl6Vis"); }
        }



        private string _Switchimage;

        public string Switchimage
        {
            get { return _Switchimage; }
            set { _Switchimage = value; OnPropertyChanged("Switchimage"); }
        }


        private string _Switchmessage;

        public string Switchmessage
        {
            get { return _Switchmessage; }
            set { _Switchmessage = value; OnPropertyChanged("Switchmessage"); }
        }

        private RelayCommand _SwitchCalibration;

        public RelayCommand SwitchCalibration
        {
            get { return _SwitchCalibration; }
            set { _SwitchCalibration = value; OnPropertyChanged("SwitchCalibration"); }
        }

        
        public SwitchCalibrationVM()
        {
            try
            {
                _SwitchCalibration = new RelayCommand(StartSwitchCalibration);
             
                switch (clsGlobalVariables.SelectedCatIdObj.Switchdata)
                {
                    case 1 :
                        Tgl1Vis = true;
                        Tgl2Vis = false;
                        Tgl3Vis = false;
                        Tgl4Vis = false;
                        Tgl5Vis = false;
                        Tgl6Vis = false;
                        break;

                    case 2:
                        Tgl1Vis = true;
                        Tgl2Vis = true;
                        Tgl3Vis = false;
                        Tgl4Vis = false;
                        Tgl5Vis = false;
                        Tgl6Vis = false;
                        break;

                    case 3:
                        Tgl1Vis = true;
                        Tgl2Vis = true;
                        Tgl3Vis = true;
                        Tgl4Vis = false;
                        Tgl5Vis = false;
                        Tgl6Vis = false;
                        break;

                    case 4:
                        Tgl1Vis = true;
                        Tgl2Vis = true;
                        Tgl3Vis = true;
                        Tgl4Vis = true;
                        Tgl5Vis = false;
                        Tgl6Vis = false;
                        break;

                    case 5:
                        Tgl1Vis = true;
                        Tgl2Vis = true;
                        Tgl3Vis = true;
                        Tgl4Vis = true;
                        Tgl5Vis = true;
                        Tgl6Vis = false;
                        break;

                    case 6:
                        Tgl1Vis = true;
                        Tgl2Vis = true;
                        Tgl3Vis = true;
                        Tgl4Vis = true;
                        Tgl5Vis = true;
                        Tgl6Vis = true;
                        break;

                    default:
                        Tgl1Vis = false;
                        Tgl2Vis = false;
                        Tgl3Vis = false;
                        Tgl4Vis = false;
                        Tgl5Vis = false;
                        Tgl6Vis = false;
                        break;
                }

                Tglbtn1 = false;
                Tglbtn2 = false;
                Tglbtn3 = false;
                Tglbtn4 = false;
                Tglbtn5 = false;
                Tglbtn6 = false;

                clsGlobalVariables.strSwitchCalibStatus = (byte)EnmSwitchCalibrationstate.Stop;

            }
            catch (Exception ex)
            {               
                MyLogWriterDLL.LogWriter.WriteLog("Exception while  Switch Checking : " + ex.ToString());
            }
        }


        public void StartSwitchCalibration(object obj)
        {
            if (clsGlobalVariables.strSwitchCalibStatus == (byte)EnmSwitchCalibrationstate.SwitchCalibStarted)
            {
                byte deviceId = 0xF7;

                //Function to provide data parameters to make deviceinfo query        
                byte[] txBuff = clsGlobalVariables.ObjSerialComPort.MakeFrame(deviceId, (byte)clsEnumFunctionCode.Switch_Checking, (byte)clsEnumReadWriteCode.Readbyte, null);

                byte[] rxBuff = clsGlobalVariables.clsCalibrationModuleObj.ValidateResponse(txBuff, (byte)clsEnumFunctionCode.Switch_Checking, (byte)clsEnumReadWriteCode.Readbyte); // option parameter pass in this global function to keep port on only when ZCD calibration is in progress, because need to wait for 2nd response.

                if (rxBuff != null)
                {
                    if (rxBuff[1] == (byte)clsEnumFunctionCode.Switch_Checking)
                    {
                        int Cnt;

                        switch (clsGlobalVariables.switchcasevar)
                        {

                            case 0:
                                for (Cnt = 0; Cnt < clsGlobalVariables.strSwitchdata; Cnt++)
                                {
                                    if (rxBuff[4 + Cnt] != 0)
                                    {
                                        break;
                                    }
                                }

                                if (Cnt >= clsGlobalVariables.strSwitchdata)
                                {
                                    clsGlobalVariables.strSwitchcheckstate = 1;
                                    clsGlobalVariables.switchcasevar = 1;
                                }
                                break;

                            case 1:

                                for (Cnt = 0; Cnt < clsGlobalVariables.strSwitchdata; Cnt++)
                                {
                                    if (Cnt < clsGlobalVariables.switchtestvar)
                                    {
                                        if (rxBuff[4 + Cnt] != 1)
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        if (rxBuff[4 + Cnt] != 0)
                                        {
                                            break;
                                        }
                                    }
                                }

                                if (Cnt >= clsGlobalVariables.strSwitchdata)
                                {
                                    clsGlobalVariables.strSwitchcheckstate = 1;
                                    clsGlobalVariables.SwitchCnt++;

                                    if (clsGlobalVariables.SwitchCnt >= clsGlobalVariables.strSwitchdata)
                                    {
                                        clsGlobalVariables.switchcasevar = 3;
                                        clsGlobalVariables.switchtestvar = 6;
                                        clsGlobalVariables.SwitchCnt = 0;
                                    }
                                    else
                                    {
                                        if (clsGlobalVariables.SwitchCnt >= 5)
                                        {
                                            clsGlobalVariables.switchcasevar = 2;
                                            clsGlobalVariables.SwitchCnt = 0;
                                        }
                                    }      
                                  
                                }
                                break;

                            case 2:

                                for (Cnt = 0; Cnt < clsGlobalVariables.strSwitchdata; Cnt++)
                                {
                                    if (rxBuff[4 + Cnt] != 1)
                                    {
                                        break;
                                    }

                                }

                                if (Cnt >= clsGlobalVariables.strSwitchdata)
                                {
                                    clsGlobalVariables.strSwitchcheckstate = 1;
                                    clsGlobalVariables.switchcasevar = 3 ;
                                }
                                break;

                            case 3:
                                for (Cnt = 0; Cnt < clsGlobalVariables.strSwitchdata; Cnt++)
                                {
                                    if (rxBuff[4 + Cnt] != 0)
                                    {
                                        break;
                                    }
                                }

                                if (Cnt >= clsGlobalVariables.strSwitchdata)
                                {
                                    clsGlobalVariables.strSwitchcheckstate = 1;
                                    clsGlobalVariables.switchcasevar = 0;                             
                                }
                                break;

                            default:
                                break;

                        }

                        if (clsGlobalVariables.strSwitchcheckstate == 1)
                        {
                            clsGlobalVariables.IsSwitchCalibFailed = false;
                            clsGlobalVariables.strSwitchcheckstate = 0;
                          
                            if (clsGlobalVariables.switchtestvar < 7)
                            {
                                clsGlobalVariables.switchtestvar++;
                            }
                            else
                            {
                                clsGlobalVariables.switchtestvar = 0;
                                clsGlobalVariables.SwitchCnt = 0;
                                clsGlobalVariables.switchcasevar = 0;
                                clsGlobalVariables.strSwitchCalibStatus = (byte)EnmSwitchCalibrationstate.SwitchCalibCompleted;
                            }

                        }
                        else
                        {
                            clsGlobalVariables.IsSwitchCalibFailed = true;
                        }

                    }
                    else if (rxBuff[1] == (byte)(clsEnumFunctionCode.ZCD_SelfCalibration + 0x80))
                    {
                        //Failure
                        clsGlobalVariables.IsSwitchCalibFailed = true;
                    }
                }
                else 
                {
                    //Failure
                    clsGlobalVariables.IsSwitchCalibFailed = true;
                }

            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }
}
