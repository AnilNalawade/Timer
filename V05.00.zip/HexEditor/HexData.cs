﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HexEditor
{
    public class HexData : INotifyPropertyChanged
    {
        private string _NoOfBytes;

        public string NoOfBytes
        {
            get { return _NoOfBytes; }
            set { _NoOfBytes = value; OnPropertyChanged("NoOfBytes"); }
        }



        private string _Address;

        public string Address
        {
            get { return _Address; }
            set { _Address = value; OnPropertyChanged("Address"); }
        }

       



        private string _RecordType;

        public string RecordType
        {
            get { return _RecordType; }
            set { _RecordType = value; OnPropertyChanged("RecordType"); }
        }

       



        private string _DataBytes;

        public string Databytes
        {
            get { return _DataBytes; }
            set { _DataBytes = value; OnPropertyChanged("DataBytes"); }
        }

        

        private string _Checksum;

        public string  Checksum
        {
            get { return _Checksum; }
            set { _Checksum = value; OnPropertyChanged("Checksum"); }
        }

       







        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if(PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
