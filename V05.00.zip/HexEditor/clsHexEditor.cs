﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Text;

namespace HexEditor
{
    public class clsHexEditor : INotifyPropertyChanged
    {

        private string _StartAddress;

        public string StartAddress
        {
            get { return _StartAddress; }
            set { _StartAddress = value; OnPropertyChanged("StartAddress"); }
        }


        private string _DataBytes;

        public string DataBytes
        {
            get { return _DataBytes; }
            set { _DataBytes = value; OnPropertyChanged("DataBytes"); }
        }

        private string _Status;

        public string Status
        {
            get { return _Status; }
            set { _Status = value; OnPropertyChanged("Status"); }
        }


        private string _FilePath;

        public string FilePath
        {
            get { return _FilePath; }
            set { _FilePath = value; OnPropertyChanged("FilePath"); }
        }


        private ObservableCollection<HexData> _HexDataList = new ObservableCollection<HexData>();

        public ObservableCollection<HexData> HexDataList
        {
            get { return _HexDataList; }
            set { _HexDataList = value; OnPropertyChanged("HexDataList"); }
        }

        private List<HexData> _HexModifiedDataList = new List<HexData>();

        public List<HexData> HexModifiedDataList
        {
            get { return _HexModifiedDataList; }
            set { _HexModifiedDataList = value; OnPropertyChanged("HexModifiedDataList"); }
        }
        
        public clsHexEditor()
        {

        }

        public bool EditHexFile(string _StartAddress, string _DataBytes)
        {
            StartAddress = _StartAddress;
            DataBytes = _DataBytes;

            if(StartAddress != null && DataBytes != null)
            {
                HexModifiedDataList = new List<HexData>();
                for (int i = 0; i < HexDataList.Count; i++)
                {
                    HexModifiedDataList.Add(HexDataList[i]);
                }

                int addressLineIndex = 0;
                int StartAddressInt = int.Parse(StartAddress, NumberStyles.HexNumber);
                bool doneEditing = false;
                for (addressLineIndex = 0; addressLineIndex < HexModifiedDataList.Count; addressLineIndex++)
                {
                    if (doneEditing == false)
                    {
                        if (StartAddressInt <= int.Parse(HexModifiedDataList[addressLineIndex].Address, NumberStyles.HexNumber))
                        {
                            if (HexModifiedDataList[addressLineIndex].RecordType == "01")
                            {
                                doneEditing = false;
                                return false;
                            }
                            else if (HexModifiedDataList[addressLineIndex].RecordType != "00")
                            {
                                doneEditing = false;
                                return false;
                            }
                            else
                            {
                                if (int.Parse(HexModifiedDataList[addressLineIndex - 1].Address, NumberStyles.HexNumber) == 0000)
                                {
                                    addressLineIndex--;
                                }
                                int offset = StartAddressInt - int.Parse(HexModifiedDataList[addressLineIndex - 1].Address, NumberStyles.HexNumber);
                                int noOfbytes = int.Parse(HexModifiedDataList[addressLineIndex - 1].NoOfBytes, NumberStyles.HexNumber);
                                int lengthofDataBytes = DataBytes.Length / 2;
                                byte[] oldData = storeDataInBytes(HexModifiedDataList[addressLineIndex - 1].Databytes);
                                byte[] newData = storeDataInBytes(DataBytes);
                                int newDataCounter = 0;
                                for (int j = offset; j < noOfbytes; j++)
                                {
                                    oldData[j] = newData[newDataCounter];
                                    newDataCounter++;
                                    if (newDataCounter == (DataBytes.Length / 2))
                                    {
                                        break;
                                    }
                                }

                                HexModifiedDataList[addressLineIndex - 1].Databytes = ByteArrayToString(oldData);
                                HexModifiedDataList[addressLineIndex - 1].Checksum = calculateCheckSum(storeDataInBytes(String.Format("{0}{1}{2}{3}", HexModifiedDataList[addressLineIndex - 1].NoOfBytes, HexModifiedDataList[addressLineIndex - 1].Address, HexModifiedDataList[addressLineIndex - 1].RecordType, HexModifiedDataList[addressLineIndex - 1].Databytes)));
                                while (newDataCounter < DataBytes.Length / 2)
                                {
                                    if (HexModifiedDataList[addressLineIndex].RecordType == "01")
                                    {
                                        doneEditing = false;
                                        return false;
                                    }
                                    else if (HexModifiedDataList[addressLineIndex].RecordType != "00")
                                    {
                                        addressLineIndex++;
                                    }
                                    else
                                    {
                                        oldData = storeDataInBytes(HexModifiedDataList[addressLineIndex].Databytes);
                                        offset = 0;
                                        noOfbytes = int.Parse(HexModifiedDataList[addressLineIndex].NoOfBytes, NumberStyles.HexNumber);
                                        for (int j = offset; j < noOfbytes; j++)
                                        {
                                            oldData[j] = newData[newDataCounter];
                                            newDataCounter++;
                                            if (newDataCounter == (DataBytes.Length / 2))
                                            {
                                                break;
                                            }
                                        }
                                        HexModifiedDataList[addressLineIndex].Databytes = ByteArrayToString(oldData);
                                        HexModifiedDataList[addressLineIndex].Checksum = calculateCheckSum(storeDataInBytes(String.Format("{0}{1}{2}{3}", HexModifiedDataList[addressLineIndex].NoOfBytes, HexModifiedDataList[addressLineIndex].Address, HexModifiedDataList[addressLineIndex].RecordType, HexModifiedDataList[addressLineIndex].Databytes)));
                                        addressLineIndex++;
                                    }

                                }

                                doneEditing = true;
                            }

                        }
                        else if (StartAddressInt == int.Parse(HexModifiedDataList[addressLineIndex].Address, NumberStyles.HexNumber))
                        {
                            if (HexModifiedDataList[addressLineIndex].RecordType == "01")
                            {
                                doneEditing = false;
                                return false;
                            }
                            else if (HexModifiedDataList[addressLineIndex].RecordType != "00")
                            {
                                doneEditing = false;
                                return false;
                            }
                            else
                            {
                                int offset = StartAddressInt - int.Parse(HexModifiedDataList[addressLineIndex].Address, NumberStyles.HexNumber);
                                int noOfbytes = int.Parse(HexModifiedDataList[addressLineIndex].NoOfBytes, NumberStyles.HexNumber);
                                int lengthofDataBytes = DataBytes.Length / 2;
                                byte[] oldData = storeDataInBytes(HexModifiedDataList[addressLineIndex].Databytes);
                                byte[] newData = storeDataInBytes(DataBytes);
                                int newDataCounter = 0;
                                for (int j = offset; j < noOfbytes; j++)
                                {
                                    oldData[j] = newData[newDataCounter];
                                    newDataCounter++;
                                    if (newDataCounter == (DataBytes.Length / 2))
                                    {
                                        break;
                                    }
                                }

                                HexModifiedDataList[addressLineIndex].Databytes = ByteArrayToString(oldData);
                                HexModifiedDataList[addressLineIndex].Checksum = calculateCheckSum(storeDataInBytes(String.Format("{0}{1}{2}{3}", HexModifiedDataList[addressLineIndex].NoOfBytes, HexModifiedDataList[addressLineIndex].Address, HexModifiedDataList[addressLineIndex].RecordType, HexModifiedDataList[addressLineIndex].Databytes)));
                                while (newDataCounter < DataBytes.Length / 2)
                                {
                                    if (HexModifiedDataList[addressLineIndex].RecordType == "01")
                                    {
                                        doneEditing = false;
                                        return false;
                                    }
                                    else if (HexModifiedDataList[addressLineIndex].RecordType != "00")
                                    {
                                        addressLineIndex++;
                                    }
                                    else
                                    {
                                        addressLineIndex++;
                                        oldData = storeDataInBytes(HexModifiedDataList[addressLineIndex].Databytes);
                                        offset = 0;
                                        noOfbytes = int.Parse(HexModifiedDataList[addressLineIndex].NoOfBytes, NumberStyles.HexNumber);
                                        for (int j = offset; j < noOfbytes; j++)
                                        {
                                            oldData[j] = newData[newDataCounter];
                                            newDataCounter++;
                                            if (newDataCounter == (DataBytes.Length / 2))
                                            {
                                                break;
                                            }
                                        }
                                        HexModifiedDataList[addressLineIndex].Databytes = ByteArrayToString(oldData);
                                        HexModifiedDataList[addressLineIndex].Checksum = calculateCheckSum(storeDataInBytes(String.Format("{0}{1}{2}{3}", HexModifiedDataList[addressLineIndex].NoOfBytes, HexModifiedDataList[addressLineIndex].Address, HexModifiedDataList[addressLineIndex].RecordType, HexModifiedDataList[addressLineIndex].Databytes)));


                                    }

                                }
                                doneEditing = true;
                            }

                        }
                        else
                        {
                            if (addressLineIndex == (HexModifiedDataList.Count - 1))
                            {
                                int noBytes = int.Parse(HexModifiedDataList[addressLineIndex - 1].NoOfBytes, NumberStyles.HexNumber);
                                int Address = int.Parse(HexModifiedDataList[addressLineIndex - 1].Address, NumberStyles.HexNumber);
                                int startAddress = int.Parse(StartAddress, NumberStyles.HexNumber);
                                if ((noBytes + Address) > startAddress)
                                {
                                    addressLineIndex--;
                                    int offset = StartAddressInt - int.Parse(HexModifiedDataList[addressLineIndex].Address, NumberStyles.HexNumber);
                                    int noOfbytes = int.Parse(HexModifiedDataList[addressLineIndex].NoOfBytes, NumberStyles.HexNumber);
                                    int lengthofDataBytes = DataBytes.Length / 2;
                                    byte[] oldData = storeDataInBytes(HexModifiedDataList[addressLineIndex].Databytes);
                                    byte[] newData = storeDataInBytes(DataBytes);
                                    int newDataCounter = 0;
                                    for (int j = offset; j < noOfbytes; j++)
                                    {
                                        oldData[j] = newData[newDataCounter];
                                        newDataCounter++;
                                        if (newDataCounter == (DataBytes.Length / 2))
                                        {
                                            break;
                                        }
                                    }

                                    HexModifiedDataList[addressLineIndex].Databytes = ByteArrayToString(oldData);
                                    HexModifiedDataList[addressLineIndex].Checksum = calculateCheckSum(storeDataInBytes(String.Format("{0}{1}{2}{3}", HexModifiedDataList[addressLineIndex].NoOfBytes, HexModifiedDataList[addressLineIndex].Address, HexModifiedDataList[addressLineIndex].RecordType, HexModifiedDataList[addressLineIndex].Databytes)));
                                    while (newDataCounter < DataBytes.Length / 2)
                                    {
                                        if (HexModifiedDataList[addressLineIndex].RecordType == "01")
                                        {
                                            doneEditing = false;
                                            return false;
                                        }
                                        else if (HexModifiedDataList[addressLineIndex].RecordType != "00")
                                        {
                                            addressLineIndex++;
                                        }
                                        else
                                        {
                                            addressLineIndex++;
                                            oldData = storeDataInBytes(HexModifiedDataList[addressLineIndex].Databytes);
                                            offset = 0;
                                            noOfbytes = int.Parse(HexModifiedDataList[addressLineIndex].NoOfBytes, NumberStyles.HexNumber);
                                            for (int j = offset; j < noOfbytes; j++)
                                            {
                                                oldData[j] = newData[newDataCounter];
                                                newDataCounter++;
                                                if (newDataCounter == (DataBytes.Length / 2))
                                                {
                                                    break;
                                                }
                                            }
                                            HexModifiedDataList[addressLineIndex].Databytes = ByteArrayToString(oldData);
                                            HexModifiedDataList[addressLineIndex].Checksum = calculateCheckSum(storeDataInBytes(String.Format("{0}{1}{2}{3}", HexModifiedDataList[addressLineIndex].NoOfBytes, HexModifiedDataList[addressLineIndex].Address, HexModifiedDataList[addressLineIndex].RecordType, HexModifiedDataList[addressLineIndex].Databytes)));


                                        }

                                    }
                                    doneEditing = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        break;
                    }


                }
                if (doneEditing == true)
                {                    
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            return false;
        }
        

        private static string calculateCheckSum(byte[] byteData)
        {
            int sum = 0;

            for (int i = 0; i < byteData.Length; i++)
            {
                sum += byteData[i];
            }

            sum = ~sum;
            sum = sum + 1;

            string v = Convert.ToString(sum, 16);

            return v.Substring(6, 2).ToUpper();
        }

        public static string ByteArrayToString(byte[] ba)
        {
            return BitConverter.ToString(ba).Replace("-", "");
        }

        public string createNewFile()
        {
            string buff = "";
            //string path = FilePath.Remove(FilePath.Length - 4, 4);
            string path = Directory.GetCurrentDirectory() + @"\ModifiedHexFile\Modified.hex";
            // path += "_" + DateTime.Now.ToString("dd_MM_yyyy_HH_mm") + ".hex";
            //path += "_" + "Modified" + ".hex";

            if (File.Exists(path))
            {
                File.Delete(path);
            }

            StreamWriter sr = new StreamWriter(File.OpenWrite(path));
            foreach (HexData item in HexModifiedDataList)
            {
                buff = string.Format(":{0}{1}{2}{3}{4}", item.NoOfBytes, item.Address, item.RecordType, item.Databytes, item.Checksum);
                sr.WriteLine(buff);
                buff = "";
            }
            sr.Close();
            FilePath = path;
            Status = "A new copy of modified hex file is saved at:  " + path;
            return FilePath;
        }
        

        public void getData(string _FilePath)
        {
            HexDataList.Clear();
            BinaryReader br = new BinaryReader(File.OpenRead(_FilePath));
            FilePath = "";
            FilePath = Path.GetFullPath(_FilePath);
            while (br.BaseStream.Position != br.BaseStream.Length)
            {
                if (br.ReadByte() == 0x3a)
                {
                    HexData MyHexData = new HexData();
                    byte[] noOfBytesData = br.ReadBytes(2);
                    MyHexData.NoOfBytes = Encoding.ASCII.GetString(noOfBytesData);

                    byte[] AddressData = br.ReadBytes(4);
                    MyHexData.Address = Encoding.ASCII.GetString(AddressData);

                    byte[] RecordTypeData = br.ReadBytes(2);
                    MyHexData.RecordType = Encoding.ASCII.GetString(RecordTypeData);

                    byte[] DataBytesData = br.ReadBytes(int.Parse(MyHexData.NoOfBytes, System.Globalization.NumberStyles.HexNumber) * 2);
                    MyHexData.Databytes = Encoding.ASCII.GetString(DataBytesData);

                    byte[] ChecksumData = br.ReadBytes(2);
                    MyHexData.Checksum = Encoding.ASCII.GetString(ChecksumData);

                    br.ReadBytes(2);
                    HexDataList.Add(MyHexData);
                    MyHexData = null;
                }

            }
            br.Close();
        }

        private byte[] storeDataInBytes(string hexString)
        {
            byte[] bb = new byte[hexString.Length / 2];
            int j = 0;
            for (int i = 0; i < hexString.Length; i = i + 2)
            {
                bb[j] = byte.Parse(hexString.Substring(i, 2), NumberStyles.HexNumber);
                j++;
            }
            return bb;
        }



        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
