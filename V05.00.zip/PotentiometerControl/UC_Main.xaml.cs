﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PotentiometerControl
{
    /// <summary>
    /// Interaction logic for UC_Main.xaml
    /// </summary>
    public partial class UC_Main : UserControl
    {

        int points;
        public List<Line> LineMarking = new List<Line>();
        public List<Ellipse> DotMarking = new List<Ellipse>();
        public List<double> AngleList = new List<double>();
        public List<double> AngleDotList = new List<double>();
        public List<double> AngleDotListAll = new List<double>();
        List<TextBlock> lblList = new List<TextBlock>();
        List<TextBlock> lblList_old = new List<TextBlock>();

        public UC_Main()
        {
            InitializeComponent();
            NumberOfPoints = 1;
            StartAngle = -45.0;
            EndAngle = 225.0;
            StepAngle = 0.0;
            Update = 0;
            AngleList.Add(StartAngle);
            AngleDotList.Add(StartAngle);
            AngleDotListAll.Add(StartAngle);
            lblList.Add(new TextBlock() { });
            SelectedIndex = 0;
            Resize();

        }

        
        public int SelectedIndex
        {
            get { return (int)GetValue(SelectedIndexProperty); }
            set { SetValue(SelectedIndexProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedIndex.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedIndexProperty =
            DependencyProperty.Register("SelectedIndex", typeof(int), typeof(UC_Main), new PropertyMetadata(0, new PropertyChangedCallback(OnSelectedIndexChanged)));

        private static void OnSelectedIndexChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnSelectedIndexChanged(e);
        }

        private void OnSelectedIndexChanged(DependencyPropertyChangedEventArgs e)
        {
            if (SelectedIndex == -1)
            {
                SelectedIndex = 0;
            }
            else
            {

                if (MiddleDotCalibration == true)
                {
                    if(NumberOfPoints > 1)
                    {
                        if (SelectedIndex > AngleDotList.Count - 2)
                        {
                            if (AngleDotList.Count > 0) SelectedIndex = AngleDotList.Count - 2;
                        }
                        this.Line.Angle = AngleDotList[SelectedIndex];
                        Angle = AngleDotList[SelectedIndex];
                    }
                    else
                    {
                        this.Line.Angle = AngleDotList[0];
                        Angle = AngleDotList[0];
                    }
                    
                }
                else
                {
                    if (SelectedIndex > NumberOfPoints - 1)
                    {
                        SelectedIndex = NumberOfPoints - 1;
                    }
                    this.Line.Angle = AngleList[SelectedIndex];
                    Angle = AngleList[SelectedIndex];
                }

            }

        }





        public string Lables
        {
            get { return (string)GetValue(LablesProperty); }
            set { SetValue(LablesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Lables.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LablesProperty =
            DependencyProperty.Register("Lables", typeof(string), typeof(UC_Main), new PropertyMetadata("", new PropertyChangedCallback(OnLablesChanged)));

        private static void OnLablesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnLablesChanged(e);
        }

        private void OnLablesChanged(DependencyPropertyChangedEventArgs e)
        {

            if (e.NewValue != null)
            {
                if (e.NewValue.ToString() != null && e.NewValue.ToString() != "")
                {
                    lblList.Clear();
                    var lbls = e.NewValue.ToString().Split(',');
                    foreach (string item in lbls)
                    {
                        lblList.Add(new TextBlock() { Text = item, Foreground = Brushes.Black, FontSize = 10 });
                    }
                }
            }
        }

        public double Angle
        {
            get { return (double)GetValue(AngleProperty); }
            set { SetValue(AngleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Angle.  This enables animation, styling, binding, etc...
        public static DependencyProperty AngleProperty =
            DependencyProperty.Register("Angle", typeof(double), typeof(UC_Main), new
            PropertyMetadata(0.0, new PropertyChangedCallback(OnAngleChanged)));

        private static void OnAngleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnAngleChanged(e);
        }

        private void OnAngleChanged(DependencyPropertyChangedEventArgs e)
        {
            double newangle = Convert.ToDouble(string.Format("{0:F4}", e.NewValue));
            if (newangle > EndAngle)
            {
                this.Line.Angle = EndAngle;
                Angle = EndAngle;
                // SelectedIndex = AngleList.IndexOf(EndAngle);
            }
            else if (newangle < StartAngle)
            {
                this.Line.Angle = StartAngle;
                Angle = StartAngle;
                // SelectedIndex = AngleList.IndexOf(StartAngle);
            }
            else
            {
                this.Line.Angle = newangle;
                // SelectedIndex = AngleList.IndexOf(newangle);
            }

        }

        public double StepAngle
        {
            get { return (double)GetValue(StepAngleProperty); }
            set { SetValue(StepAngleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for StepAngle.  This enables animation, styling, binding, etc...
        public static DependencyProperty StepAngleProperty =
            DependencyProperty.Register("StepAngle", typeof(double), typeof(UC_Main), new
            PropertyMetadata(0.0, new PropertyChangedCallback(OnStepAngleChanged)));

        private static void OnStepAngleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnStepAngleChanged(e);
        }

        private void OnStepAngleChanged(DependencyPropertyChangedEventArgs e)
        {
            //
        }

        public double StartAngle
        {
            get { return (double)GetValue(StartAngleProperty); }
            set { SetValue(StartAngleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for StartAngle.  This enables animation, styling, binding, etc...
        public static DependencyProperty StartAngleProperty =
            DependencyProperty.Register("StartAngle", typeof(double), typeof(UC_Main), new PropertyMetadata(-45.0));




        public int Update
        {
            get { return (int)GetValue(UpdateProperty); }
            set { SetValue(UpdateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ClearOrDraw.  This enables animation, styling, binding, etc...
        public static DependencyProperty UpdateProperty =
            DependencyProperty.Register("Update", typeof(int), typeof(UC_Main), new
            PropertyMetadata(0, new PropertyChangedCallback(OnUpdateChanged)));

        private static void OnUpdateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnUpdateChanged(e);
        }

        private void OnUpdateChanged(DependencyPropertyChangedEventArgs e)
        {
            if (Convert.ToInt32(e.NewValue) == 1)
            {
                ClearPot();
            }
            else if (Convert.ToInt32(e.NewValue) == 2)
            {
                //ClearPot();
            }
        }

        public double EndAngle
        {
            get { return (double)GetValue(EndAngleProperty); }
            set { SetValue(EndAngleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EndAngle.  This enables animation, styling, binding, etc...
        public static DependencyProperty EndAngleProperty =
            DependencyProperty.Register("EndAngle", typeof(double), typeof(UC_Main), new PropertyMetadata(225.0));





        public double height
        {
            get { return (double)GetValue(heightProperty); }
            set { SetValue(heightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for height.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty heightProperty =
            DependencyProperty.Register("height", typeof(double), typeof(UC_Main), new PropertyMetadata(0.0, new PropertyChangedCallback(OnHeightChanged)));

        private static void OnHeightChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnHeightChanged(e);
        }

        private void OnHeightChanged(DependencyPropertyChangedEventArgs e)
        {
            height = (double)e.NewValue;
            Resize();
        }

        public double width
        {
            get { return (double)GetValue(widthProperty); }
            set { SetValue(widthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for width.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty widthProperty =
            DependencyProperty.Register("width", typeof(double), typeof(UC_Main), new PropertyMetadata(0.0, new PropertyChangedCallback(OnWidthChanged)));

        private static void OnWidthChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnWidthChanged(e);
        }

        private void OnWidthChanged(DependencyPropertyChangedEventArgs e)
        {
            width = (double)e.NewValue;
            Resize();
        }

        public int NumberOfPoints
        {
            get { return (int)GetValue(NumberOfPointsProperty); }
            set { SetValue(NumberOfPointsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Sections.  This enables animation, styling, binding, etc...
        public static DependencyProperty NumberOfPointsProperty =
            DependencyProperty.Register("NumberOfPoints", typeof(int), typeof(UC_Main), new
            PropertyMetadata(1, new PropertyChangedCallback(OnNumberOfPointsChanged)));

        private static void OnNumberOfPointsChanged(DependencyObject d,
          DependencyPropertyChangedEventArgs e)
        {
            UC_Main main = d as UC_Main;
            main.OnSetTextChanged(e);
        }

        private void OnSetTextChanged(DependencyPropertyChangedEventArgs e)
        {
            //
        }




        public bool MiddleDotCalibration
        {
            get { return (bool)GetValue(MiddleDotCalibrationProperty); }
            set { SetValue(MiddleDotCalibrationProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MiddleDotCalibration.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MiddleDotCalibrationProperty =
            DependencyProperty.Register("MiddleDotCalibration", typeof(bool), typeof(UC_Main), new PropertyMetadata(true));




        public void ClearPot()
        {
            for (int i = 0; i <= points; i++)
            {
                if (LineMarking.Count > 0) canvas.Children.Remove(LineMarking[i]);
                if (lblList_old.Count > 0) canvas.Children.Remove(lblList_old[i]);
            }
            
                for (int i = 0; i <= points - 1; i++)
                {
                    if (DotMarking.Count > 0) canvas.Children.Remove(DotMarking[i]);
                }
            
            
            SelectedIndex = 0;
            AngleList.Clear();
            LineMarking.Clear();
            DotMarking.Clear();
            lblList_old.Clear();
            EndAngle = 225;
            Update = 0;
            DrawPot();
        }

        public void Resize()
        {


            canvas.Width = width;
            canvas.Height = height;
            blackCircle.Width = width * 0.8;
            blackCircle.Height = height * 0.8;
            tealCircle.Width = width * 0.544;
            tealCircle.Height = height * 0.544;

            Sweeper.X2 = width / 2;
            Sweeper.Y2 = height / 2;

            Sweeper.X1 = (width / 2) - (width * 0.4);
            Sweeper.Y1 = height / 2;

            Line.CenterX = width / 2;
            Line.CenterY = height / 2;

            redCircle.Width = width * 0.15;
            redCircle.Height = height * 0.15;

            borderCircle.Width = width * 0.8;
            borderCircle.Height = height * 0.8;

            Canvas.SetLeft(blackCircle, width * 0.1);
            Canvas.SetTop(blackCircle, height * 0.1);
            Canvas.SetLeft(borderCircle, width * 0.1);
            Canvas.SetTop(borderCircle, height * 0.1);

            Canvas.SetLeft(tealCircle, width * 0.23);
            Canvas.SetTop(tealCircle, height * 0.23);

            Canvas.SetLeft(redCircle, width * 0.425);
            Canvas.SetTop(redCircle, height * 0.425);
            Canvas.SetZIndex(redCircle, 50);
        }

        public void DrawPot()
        {
            Angle = StartAngle;
            StepAngle = Convert.ToDouble(String.Format("{0:F4}", ((EndAngle - StartAngle) / (NumberOfPoints - 1))));
            points = NumberOfPoints - 1;
            double angle = StartAngle;

            for (int i = 0; i <= points; i++)
            {
                LineMarking.Add(
                           new Line()
                           {
                               X1 = 0,
                               Y1 = height / 2,
                               X2 = 8,
                               Y2 = height / 2,
                               Stroke = Brushes.Red,
                               StrokeThickness = 3,
                               RenderTransform = new RotateTransform() { CenterX = width / 2, CenterY = height / 2, Angle = angle },
                               Margin = new Thickness(0),
                           }
                         );



                if (angle == StartAngle)
                {
                    AngleList.Clear();
                    AngleDotList.Clear();
                    AngleDotListAll.Clear();
                }
                AngleList.Add(Convert.ToDouble(String.Format("{0:F4}", angle)));
                AngleDotListAll.Add(Convert.ToDouble(String.Format("{0:F4}", angle)));
                DotMarking.Add(new Ellipse()
                {
                    Fill = Brushes.Blue,
                    Height = 3,
                    Width = 3,
                    StrokeThickness = 0,
                    Margin = new Thickness(0),
                });
                AngleDotList.Add(Convert.ToDouble(String.Format("{0:F4}", (angle) + (StepAngle / 2))));
                AngleDotListAll.Add(Convert.ToDouble(String.Format("{0:F4}", (angle) + (StepAngle / 2))));
                angle = angle + StepAngle;
            }


            for (int i = 0; i <= points; i++)
            {
                canvas.Children.Add(LineMarking[i]);
                canvas.Children.Add(lblList[i]);
                lblList_old.Add(lblList[i]);
                Canvas.SetTop(lblList[i], (height / 2 + height * 0.7 * Math.Sin((AngleList[i] + 180) * (Math.PI / 180))));
                Canvas.SetLeft(lblList[i], (width / 2 + width * 0.7 * Math.Cos((AngleList[i] + 180) * (Math.PI / 180))));
            }
            if(MiddleDotCalibration == true)
            {
                for (int i = 0; i <= points - 1; i++)
                {

                    canvas.Children.Add(DotMarking[i]);
                    Canvas.SetTop(DotMarking[i], (height / 2 + height * 0.5 * Math.Sin((AngleDotList[i] + 180) * (Math.PI / 180))));
                    Canvas.SetLeft(DotMarking[i], (width / 2 + width * 0.5 * Math.Cos((AngleDotList[i] + 180) * (Math.PI / 180))));
                }
            }
            

            EndAngle = Convert.ToDouble(String.Format("{0:F4}", angle - StepAngle));
            SelectedIndex = 1;
            SelectedIndex = 0;
        }
    }


}
