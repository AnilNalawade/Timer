
Project: Timer Programming And Calibaration Software
Version: V04.00
Date: 30-03-2021
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Protocol for timer having two timing pots and two range pots(forward reverse timer)
2. Calibration with 0 value, issue solved.
3. Delay between two counts reduced to 40ms.
4. Added ensure message while selection of catalog id. 
5. Short cut key 'M' added for start the programming and calibration.
6. Added range validation in database.
7. Changed beep sound in failure case.
8. Changed json file path on nas.
------------------------------------------------------------------------------------------------------------------------------

Project: Timer Programming And Calibaration Software
Version: V04.00
Date: 18-02-2021
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Protocol for timer having two timing pots and two range pots(forward reverse timer)
2. Calibration with 0 value, issue solved.
3. Delay between two counts reduced to 40ms.
4. Added ensure message while selection of catalog id. 
5. Short cut key 'M' added for start the programming and calibration.
------------------------------------------------------------------------------------------------------------------------------

Project: Timer Programming And Calibaration Software
Version: V03.00
Date: 11-02-2021
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Node voltages calculations changed to change voltage data type.
2. Jsonfilepath text file changed, added valid nas path. 
-------------------------------------------------------------------------------------------------------------------------------------------------------------


Project: Timer Programming And Calibaration Software
Version: V02.00
Date: 21-12-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Resolved issue of retry clicked.
2. Resolved issue of disable window if json path is invalid.
3. Resolved issue of programming verification.
4. Resolved issue of clear firmware version window.
5. Default Json file path has changed. 
-------------------------------------------------------------------------------------------------------------------------------------------------------------

Project: Timer Programming And Calibaration Software
Version: V01.00
Date: 29-10-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Passwordd window added before open catalogue config window.
2. Solve increased width of starting dialog box.
-------------------------------------------------------------------------------------------------------------------------------------------------------------

Project: Timer Programming And Calibaration Software
Version: V01.00
Date: 28-10-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Modified fixed range variable in database,renamed "mentionnumber" to "FixedRange".
2. Changed location of modified hex file to store in local application folder named as "ModifiedHexFile".
3. Node voltage invalid input string issue resolved.
-------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: V01.00
Date: 06-10-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:
1. Staircase product's features added in software.
2. Solved Issue while writing additional features.
3. PWM constant calculations, zcd calibration added.
4. Database validation points added on save button.
5. Beep sound added.
-------------------------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: V01.00
Date: 19-08-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software:

1.For each cat id image path added in software.
2.Log enable menu added.
3.Log of all calibrated pot stored in csv file.
4.Path of image for all catid saved in DB.  
5.Code commeting in details.
-------------------------------------------------------------------------------------------------------------------------------------------------

Project: Timer Programming And Calibaration Software
Version: V01.00
Date: 24-07-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software as per discussed with prod. engg.:

1.Device voltage for calibration, controller type for programming
2.Selection of cat id, message issue
3.Run as admin by default, after start the software
4.Remove unnecessory code while select device type
5.Refresh port list while changing communication settings.

-------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: V00.02
Date: 13-07-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points are added in Software as per discussed with prod. engg.:

1st= Need Path for RPJ &RWS file for every CAT ID. (Must change )

2nd= All parameter which are fix in software setup need in drop list(eg. Voltage info )in JSN fiile .

3rd=In (AC/DC/ACDC tab) no need of this block all this info should come in Voltage selection tab under drop list. 

4rth=Communication setting tab need name as DUT Communication setting .

-------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: V00.04
Date: 01-07-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points for Software need to be done:
1. On, Off mode and its validation added for the range constants.
2. Timeout Delay changed.
 
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: V00.03
Date: 23-06-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points for Software need to be done:
1. Node voltages implementation and validation
2. GUI Validation
 
-----------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v00.03
Date: 11-06-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points for Software need to be done:
1. Implement difference between previous and current pot reading.
2. Changes in PWM selection for G10 ,G13.
3. Making Setup, Setup testing.
4. Process of Programming and Calibration will be done with single button press.
5. PLC regarding queries will be implemented as per Inputs given by Chetan.
6. Total time for Programming and Calibration need to be displayed.
7. Show Final status after Programming and Calibration.
8. Option for Restoring the Default Communication settings will be given.
9. PWM added in protocol in runtime features.
10.Calibration allowed setting add for range pot.
11.Add Allow ranges checkbox in database and validation
12.Database tooltip Added for need properties.
13.Database fixed timing, fixed range limits/ validation / messages.
14.Give shortcut keys and tooltip for restart, retry and OK buttons.
15.Beep sound for success and fail cases while calibration and programming. 
16.G13 all new implementation testing.
17.PLC auto port detection
18.If range pot calibration not applicable, On UI range pot should not display.
19.PLC relay On/Off queries are implemented.
20.PLC analog voltage reading.

21.Change json file via GUI as per new implementation of 2 new properties. 
22.Log Implementation for range pot 
23.Product type, productName, user displaying at below statusbar at runtime.
24.Changes in Programming thread to show user that programming is going on.

25.Testing PLC relay On/Off queries.
26.Testing G13 all new implementation.

27.PLC analog voltage reading.
28.Node queries implementation.

29. Timing constant Enable in GUI, and added in protocol. 
30. All Catid's selection in same combobox.
 
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v00.02
Date: 10-06-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following points for Software need to be done:
1. Implement difference between previous and current pot reading.
2. Changes in PWM selection for G10 ,G13.
3. Making Setup, Setup testing.
4. Process of Programming and Calibration will be done with single button press.
5. PLC regarding queries will be implemented as per Inputs given by Chetan.
6. Total time for Programming and Calibration need to be displayed.
7. Show Final status after Programming and Calibration.
8. Option for Restoring the Default Communication settings will be given.
9. PWM added in protocol in runtime features.
10.Calibration allowed setting add for range pot.
11.Add Allow ranges checkbox in database and validation
12.Database tooltip Added for need properties.
13.Database fixed timing, fixed range limits/ validation / messages.
14.Give shortcut keys and tooltip for restart, retry and OK buttons.
15.Beep sound for success and fail cases while calibration and programming. 
16.G13 all new implementation testing.
--------------------------------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 14-03-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1. User authentication module is implemented.
2. "users.db" database file is added to store user credentials.
3. UI of MessageBox dialog is improved.
4. Data fields validation is implemented for Catalogue Config window.
5. UI of MessageBox dialog of Catalogue Config window is improved.
--------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 17-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1. Flash programming Implementation done (testing).
2. Added two options in UI to select Flash programmer version and In json files.
3. Added validation messages for programming section.
4. Solved one issue in Pot control.
5. Changes in main UI.
--------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 15,16-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.Added json file config data as per the discussion in meeting.
2.Pot drawing and integrate.
3.Create batch file RWS,RPJ,RSC files for programming.   
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 13,14-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.Relay Details added to new json as well as UI part.
2.Pot user control project updated.
3.Validation for UI hide, enabled added.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 08,09,10-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.Study New Timer 
2.Make new JSON file and accordingly class structure
3.Retreive, Add, delete data from new JSON file for One M StarDelta timer.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 06-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.Default window is removed and custom window is implemented.
2.Added some confirmation messsages before changing device from menu.
3.Added HexEditor Dll Project.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 03-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.UI is connected with backend, potdetails get updated after we select CatId.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 02-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.Changed the UI of Homescreen
2.Added Pot usercontrol.
3.Added "IsActive" property to Pot UserControl.
4.Added beep functionality.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Project: Timer Programming And Calibaration Software
Version: v1.0
Date: 01-01-2020
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
Following Changes are done:
1.Expand treeview.
2.Added confirmation message box for Save and Delete.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
